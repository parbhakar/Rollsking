<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
 


    <main class="theia-exception">
        <div id="results">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                       <h4>Payment</h4>
                    </div>
                    <div class="col-md-6">
                       
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /results -->
<div class="container margin_60" style="transform: none;">
      <div class="row" style="transform: none;">
        <div class="col-xl-12 col-lg-12">
        <p>Your Payment Successfully !! <br>
        	<a href="<?php echo base_url();?>">Continue To Home Page</a>
        </p>
        </div>
        
        <!-- /asdide -->
      </div>
      <!-- /row -->
    </div>
        <!-- /container -->
    </main>
    <!-- /main -->
<style>
    i.icon-money.success-bg {
color: #116fff;
}
.success-main {
padding: 70px 0;
}
.success-main h2 {
color: #116fff;
font-weight: 600;
font-style: normal;
}
</style>

    </div>

  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>
