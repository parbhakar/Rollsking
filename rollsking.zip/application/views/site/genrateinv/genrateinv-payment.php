<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

	<?php 
	//$txnid = time();
	//$surl = $surl;
	//$furl = $furl;        
	//$key_id = "rzp_test_qaRCnhkxjPx5IR";
	$key_id = "rzp_live_iw3yFT0yjG50li";

	$invid = $this->uri->segment(3);
	$username = $username;
	$useremail = $useremail;
	$userphone = $userphone;
	$bill_amont = $bill_amont;
	$currency_code = $currency_code; 
	$name = "The Rollsking";
	//$return_url = $return_url;
	?>



    <main class="theia-exception">
        <div id="results">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                       <h4>Payment</h4>
                    </div>
                    <div class="col-md-6">
                       
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /results -->
<div class="container margin_60" style="transform: none;">
      <div class="row" style="transform: none;">
        <div class="col-xl-12 col-lg-12">
        <div class="success-main" style="text-align: center;">
            <i class="icon-money success-bg"></i>
            <h2>Total Payment: <i class="pricing-b">₹ <?php echo $bill_amont; ?></i></h2>
            <!--<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</p>-->
          <form name="razorpay-form" id="razorpay-form" action="<?php echo base_url('Website/genrateinvPayment');?>" method="POST">
          <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id" />
          <input type="hidden" name="invid" id="invid" value="<?php echo $invid; ?>"/>
          <input type="hidden" name="username" id="username" value="<?php echo $username; ?>"/>
          <input type="hidden" name="useremail" id="useremail" value="<?php echo $useremail; ?>"/>
          <input type="hidden" name="userphone" id="userphone" value="<?php echo $userphone; ?>"/>
          <!-- <input type="hidden" name="txnid" id="txnid" value="<?php echo $txnid; ?>"/>
          <input type="hidden" name="surl" id="surl" value="<?php echo $surl; ?>"/>
          <input type="hidden" name="furl" id="furl" value="<?php echo $furl; ?>"/> -->
          <input type="hidden" name="bill_amont" id="bill_amont" value="<?php echo $bill_amont; ?>"/>
        </form>
         <input  id="submit-pay" type="submit" onclick="invrazorpaySubmit(this);" value="Pay Now" class="btn btn-primary" />
        </div>
        </div>
        
        <!-- /asdide -->
      </div>
      <!-- /row -->
    </div>
        <!-- /container -->
    </main>
    <!-- /main -->
<style>
    i.icon-money.success-bg {
color: #116fff;
}
.success-main {
padding: 70px 0;
}
.success-main h2 {
color: #116fff;
font-weight: 600;
font-style: normal;
}
</style>

    </div>

  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
  var razorpay_options = {
    key: "<?php echo $key_id; ?>",
    amount: "<?php echo ($bill_amont * 100); ?>",
    name: "Rollsking",
    description: "Genrate INV # <?php echo $invid; ?>",
    netbanking: true,
    currency: "<?php echo $currency_code; ?>",
    prefill: {
      name:"<?php echo $username; ?>",
      email: "<?php echo $useremail; ?>",
      contact: "<?php echo $userphone; ?>"
    },
    notes: {
      soolegal_order_id: "<?php echo $invid; ?>",
    },
    handler: function (transaction) {
        document.getElementById('razorpay_payment_id').value = transaction.razorpay_payment_id;
        document.getElementById('razorpay-form').submit();
    },
    "modal": {
        "ondismiss": function(){
            location.reload()
        }
    }
  };
  var razorpay_submit_btn, razorpay_instance;

  function invrazorpaySubmit(el){
  	//alert('test');
    if(typeof Razorpay == 'undefined'){
      setTimeout(razorpaySubmit, 200);
      if(!razorpay_submit_btn && el){
        razorpay_submit_btn = el;
        el.disabled = true;
        el.value = 'Please wait...';  
      }
    } else {
      if(!razorpay_instance){
        razorpay_instance = new Razorpay(razorpay_options);
        if(razorpay_submit_btn){
          razorpay_submit_btn.disabled = false;
          razorpay_submit_btn.value = "Pay Now";
        }
      }
      razorpay_instance.open();
    }
  }  
</script>