<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <!--  <section class="content-header">
      <h1>
        All Products
        <small>Control panel</small>
      </h1>
      
    </section> -->

    <!-- Main content -->
 <style>
 	.shopping-cart .title li{
 	    width: 16%;
 	}
 	.shopping-cart ul li{
 		    width: 16.6%;
 	}
 	.shopping-cart .title li {
    height: 40px;
    line-height: 12px;
    font-weight: 600;
    font-size: 12px;
    padding: 0px;
    padding-top: 11px !important;
    text-align: center;
    text-transform: uppercase;
    color: #212121;
    letter-spacing: 1px;
    /* border-right: 1px solid #ececec; */
    width: 118.7px !important;
}
 </style>
    
<section class="cart-section section-big-py-space bg-light" style="height: 577px;">
    <div class="container">
        <div class="row">
        	<div class="col-md-8">
        	<div class="col-md-12" style=" text-align: center; margin-bottom: 13px; position: absolute; z-index: 9999;">
        		 <?php echo @$this->session->userdata('message');$this->session->unset_userdata('message'); ?>
        	</div>
           
			     <div class="shopping-cart">

			        <!-- New Shopping Cart -->
			  
			        <ul class="title title-desktop clearfix">
			            <li class="second">IMAGE</li>
			            <li>PRODUCT NAME</li>
			            <li>PRICE</li>
			            <li>QUANTITY</li>
			            <li>GST Amount</li>
			    
			            <li class="last">TOTAL</li>
			        </ul>


					<?php 
				  $i = 1; 
                  $total=0; 
				  //$userid=$this->session->userdata('activeUserId');	
				  $data = $this->Site_Model->getCartItem();
				  if(!empty($data)){
				  // print_r($data);
				   foreach($data as $getcart){
					//print_r($getcart->cart_id);
				   
					$getProduct=$this->Site_Model->getProductDataForCart($getcart->product_id);
					//print_r($getProduct);
					 
						//print_r($cart); ?>
                    <form method="post" action="<?php echo base_url('update-cart.html'); ?>">
	                   <ul class="clearfix detail-1" id="">
	                    	
	                        <li class="second">
	                            <span class="title-responsive">IMAGE</span>
	                            <a href="#">
	                            <?php if (!empty($getProduct->product_img)) { ?>
                                  <img style="width: 80px;height: 80px;margin-top: 0px; object-fit: cover;" src="<?php echo base_url('uploads/product/'); ?><?php echo $getProduct->product_img; ?>" alt="<?php echo $getProduct->product_img; ?>"   class="">
                                <?php  } else { ?>
                                    <img style="width: 100px;" src="<?php echo base_url(); ?>admin_assets/img/no-image-icon.png" class="lazy" src="<?php echo base_url();?>assets/loding.gif" alt="cart"  >
                                <?php } ?>

	                            </a>
	                        </li>
	                        
	                        <li>
	                            <span class="title-responsive">PRODUCT NAME</span>
	                            <p style="font-size: 14px;"> <?php echo $getProduct->product_name; ?></p>
	                            
	                        </li>
                            <input type="hidden" name="product_id" value="<?php echo $getcart->product_id; ?>">
                                                    
	                        <li>
	                            <span class="title-responsive">PRICE</span>
	                            <p>₹ <?php echo $this->cart->format_number($getcart->one_price,2); ?></p>
	                       </li>
	                       
	                       
	                        <li>
	                        	<input type="hidden" name="rowid" value="<?php echo $getcart->cart_id; ?>">
	                            <span class="title-responsive">QUANTITY </span>
								<p style="font-size: 14px;"> <?php echo $getcart->qty; ?></p>
	                           
	                        </li>
	                        <li>
	                            <span class="title-responsive">GST Amount</span>
	                            <a href="javascript:;">
	                            	<?php $productGSTAmt = ($getProduct->slab / 100) * $getcart->one_price; ?>
	                               <?php  $totalGST=$productGSTAmt * $getcart->qty; ?>
	                               <p>₹ <?php echo $this->cart->format_number($totalGST,2)?></p>
	                               
	                           </a>
	                        </li>

	                         <li>
	                            <span class="title-responsive">TOTAL</span>
	                            <p class="td-color">₹  <?php echo $this->cart->format_number($totalGST + $getcart->one_price * $getcart->qty, 2); ?></p>
	                            <?php //$total += $totalGST + $getcart->price * $getcart->qty ?>
	                             <?php  $total = $total+$getcart->amountwithgst ;?>
	                       </li>
	                        
	                       
	                       
	                       
	                    </ul>
	                </form>
					 
				<?php } ?>
</div>


           
        </div>
        <div class="col-md-4">
        <div class="cart-buttons">
        	

        	

        		 <div class="cart-total-style">

                                <h3>Payment</h3>
                                
                                <ul class="treatments checkout clearfix">

                                    <li>Total Amount to Pay : <strong class="price"> Rs. <?php echo $this->cart->format_number($total); ?>/-</strong></li>
                            </ul>
                   

        	
                                    <form id="p-form" method="post" action="<?php echo base_url('payment.html');?>">
                                    <p>How would you like to Pay:</p>
                                    <div class="text-left-1">
                                    <div class="row">
                                        <div class="col-md-12 col-12">
                                                    
                                        	<?php
                                        		$userid = $this->session->userdata('activeUserId');		
                                        	    $cod = $this->Site_Model->getSiteLoginAdmin($userid);
                                        	    if($cod->ch_payment_status==1){?>
                                        	    <input type="radio" name="payment_type" value="1" checked=""> Cash On Delivery (COD) <br>
		                                            <!--<input type="radio" name="payment_type" value="2"> Razorpay Online
		                                            <br> -->
		                                        
		                                             <input type="radio" name="payment_type" value="3"> Paytm Online
		                                            <br>
                                        	    <?php }else{ ?>
                                        	    	<!-- <input type="radio" name="payment_type" value="2" checked=""> Razorpay Online
                                           			 <br> -->
                                           			  <input type="radio" name="payment_type" value="3"> Paytm Online
		                                            <br>
                                        	   <?php } ?>
                                             
                                           
                                        </div>
                                    </div>
                                    </div>
                                    <hr>
                                    <input type="hidden" name="firstname" value="<?php echo @$this->session->userdata('firstname'); ?>">
                                      <input type="hidden" name="email" value="<?php echo @$this->session->userdata('email'); ?>">
                                      <input type="hidden" name="phone" value="<?php echo @$this->session->userdata('phone'); ?>">
                                      <input type="hidden" name="state" value="<?php echo @$this->session->userdata('state'); ?>">
                                      <input type="hidden" name="city" value="<?php echo @$this->session->userdata('city'); ?>">
                                      <input type="hidden" name="zipcode" value="<?php echo @$this->session->userdata('zipcode'); ?>">
                                      <input type="hidden" name="address" value="<?php echo @$this->session->userdata('address'); ?>">
                                       <input type="hidden" name="usergstno" value="<?php echo @$this->session->userdata('user_gst'); ?>">
                                        <input type="hidden" name="useraddressid" value="<?php echo @$this->session->userdata('useraddressid'); ?>">
                                     
                                      <input type="hidden" name="totalAmount" value="<?php echo $total ?>">
                        
                                      <input type="submit" id="b-submit" class="btn-normal btn checkout-btn" name="submit" value="Confirm For Payment">
                                                        </form>
                </div>
        </div>
		<?php }else{ ?>
				<h3 class="text-center">Cart Empty</h3>
				<p class="text-center"><a href="<?php echo base_url(); ?>" class="text-center btn btn-primary">Continue Shoping</a></p>
				<?php } ?>
    </div>
</div>
</div>
</section>

<!--section end-->


  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>