<style>
/*the container must be positioned relative:*/
.autocomplete {
  position: relative;
  display: inline-block;
}

input {
  border: 1px solid transparent;
  background-color: #f1f1f1;
  padding: 10px;
  font-size: 16px;
}

input[type=text] {
  background-color: #f1f1f1;
  width: 100%;
}

input[type=submit] {
  background-color: DodgerBlue;
  color: #fff;
  cursor: pointer;
}

.autocomplete-items {
  position: absolute;
  border: 1px solid #d4d4d4;
  border-bottom: none;
  border-top: none;
  z-index: 99;
  /*position the autocomplete items to be the same width as the container:*/
  top: 100%;
  left: 0;
  right: 0;
}

.autocomplete-items div {
  padding: 10px;
  cursor: pointer;
  background-color: #fff; 
  border-bottom: 1px solid #d4d4d4; 
}

/*when hovering an item:*/
.autocomplete-items div:hover {
  background-color: #e9e9e9; 
}

/*when navigating through the items using the arrow keys:*/
.autocomplete-active {
  background-color: DodgerBlue !important; 
  color: #ffffff; 
}
a.dropdown-toggle.top-btn {
    background: #696969 !important;
    padding: 10px 18px;
    margin-top:7px;
    font-size: 16px;
    border-radius: 5px;
    text-transform: capitalize;
    margin-bottom: 0px;
}
   ul.dropdown-menu li {
    height: auto !important;
    padding: 0px 0px !important;
}

ul.dropdown-menu li a {
    font-size: 14px !important;
    color: #fff !important;
    padding: 10px 5px !important;
    font-weight: 500;
  }
.dropdown-menu>li>a:hover {
    background-color: #ffffff;
    color: #000 !important;
}
.navbar-custom-menu ul li:nth-child(2) {
    padding: 0px 10px;
}
ul.dropdown-menu.user-side-bar li:nth-child(4) {
   border-bottom: none !important;
}

.navbar-custom-menu ul li:nth-child(1) {
    padding: 0px 20px;
}
ul.dropdown-menu.user-side-bar {
    width: 160px !important;
    left: 10px !important;
    /* background: linear-gradient(180deg, dimgrey, #f39c12); */
    border: none;
    background: #797979;
    padding: 4px 0px !important;
    top: 46px;
}
ul.dropdown-menu.user-side-bar li {
    border-bottom: 1px solid #eee !important;
    padding-left: 8px !important;
} 
ul.dropdown-menu.user-side-bar li:hover {
    background: #fff;
}
</style>


  <header class="main-header">
    <!-- Logo -->
    <a href="<?php echo base_url();?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>R</b>K</span>
      <!-- logo for regular state and mobile devices -->
      <!-- <span class="logo-lg"><b>Rollsking</b></span> -->
      <img src="<?php echo base_url(); ?>assets/img/logo/logo_.png" height="40px" class="user-image" alt="User Image">
    </a>
    <!-- Header Navbar: style can be found in header.less -->



    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
         <li>
            <form autocomplete="off" action="<?php echo base_url('search.html'); ?>" class="serach-box" method="get">
              <div class="autocomplete" style="width:300px;">
                <input id="myInput" type="text" name="product_name" placeholder="Search" class="form-control" value="<?php echo @$_GET['product_name']; ?>">
              </div>
              <button type="submit" class="bt-serach"><i class="fa fa-search"></i></button>
            </form>
          </li>
         
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
          <?php  $userid=$this->session->userdata('activeUserId'); ?>
          <?php $userdataForWallet= $this->Site_Model->getWalletAmount($userid); ?>
            <a href="#" class="dropdown-toggle top-btn" data-toggle="dropdown">
              <!-- <img src="<?php echo base_url(); ?>assets/img/logo/logo.jpg" class="user-image" alt="User Image"> -->
              <span class="hidden-xs"><?php echo @$userdataForWallet->user_name; ?> &nbsp; <i class="fa fa-arrow-down" aria-hidden="true"></i></span>

            </a>

            <ul class="dropdown-menu user-side-bar">
              <!-- User image -->
              
              <li class="">
               
                  <a href="<?php echo base_url('user-profile.html');?>" class="">Profile</a>
                
              </li>
              <li>  
                 
                  <a href="<?php echo base_url('order-history.html');?>" class="">Order History</a>
                 
              </li>
               <li>  
                 
                  <a href="<?php echo base_url('change-password.html'); ?>" class="">Change Password</a>
                 
              </li>
              <li>  
                 
                  <a href="<?php echo base_url('logout.html'); ?>" class="">Sign out</a>
                 
              </li>
            </ul>
          </li>

          <li>
             <?php  
             $userid=$this->session->userdata('activeUserId');
             $cartdata=$this->Site_Model->getCartList($userid);
                    $cartCountData= count($cartdata)." Item in cart";
             ?>
             <div id="addtocartRefdesk">
                <!--<a href="<?php echo base_url('shopping-cart.html'); ?>">My Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span><?php echo count($this->cart->contents());  ?></span></a>-->
                <?php
                if(!empty($cartdata)){ ?>
                <a href="<?php echo base_url('shopping-cart.html'); ?>">My Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span><?php echo count($cartdata);  ?></span></a>
                <?php }else{ ?> 
                  <a href="javascript:;">My Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>0</span></a>
                <?php } ?>
             </div>
           
            
          </li>
          
        </ul>
      </div>
    </nav>
  </header>

