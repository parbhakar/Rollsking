<?php $this->load->view('site/components/header'); ?>
  <!-- ***** BANNER ***** -->
  <div class="top-header item7 overlay">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-12">
          <div class="wrapper">
          <h3 class="heading"><b>Payment Fail</b></h3>
           </div>
          </div>
        </div>
      </div>
    </div>
  <section class="sec-service wow animated fadeInUp fast">
    <div class="cd-filter">
        <div class="container">
          <div class="services-box">
             <div class="row">
                  <div class="col-md-12">
              
                    <h1>Sorry Your Payment is Failed, Please try again.</h1>
                    <div><a href="<?php echo base_url('shoping-cart.html'); ?>" class="red-button" >Go to Shopping Cart</a></div>
                          
                  </div>
              </div>
          </div>
      </div>
    </div>
  </section>
<?php $this->load->view('site/components/footer'); ?>