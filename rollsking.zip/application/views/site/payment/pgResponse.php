
<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
  <style>
.content-wrapper.page-reponse {
    padding-left: 50px;
    padding-top: 100px !important;
    text-align: center;
    width: 100%;
    /* margin: 0 auto; */
    margin: 0px 50px;
}
b.matched {
    font-size: 18px !important;
    font-weight: 600;
}
.content-wrapper.page-reponse b.red {
    /* padding-top: 10px !important; */
    margin-top: 12px !important;
    display: block;
}
.content-wrapper.page-reponse b {
    font-size: 20px !important;
    font-weight: 600;
}

.bg-payment {
    background: #fff;
    text-align: center;
    width: 500px;
    padding: 20px;
    display: inline-block;
    height: 214px;
}
b.red span {
    color: #f39c12;
}
.content-wrapper.page-reponse b.matched {
    font-size: 26px !important;
    color: #f39c12;
}
.bg-payment a {
    background: #f39c12;
    /* margin: 0; */
    color: #fff;
    padding: 6px 18px;
    display: inline-block;
    line-height: 21px;
    border-radius: 4px;
    margin-top: 14px;
    font-size: 16px;
    text-transform: uppercase;
}
  </style>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper page-reponse">
      
  <div class="bg-payment">  

<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// following files need to be included
// following files need to be included
define('PAYTM_ENVIRONMENT', 'TEST'); // change value PROD for production

 define('PAYTM_MERCHANT_KEY', 'Pih0ckV0mvk_SjFX');
 define('PAYTM_MERCHANT_MID', 'PVGByn41763726350300');

// define('PAYTM_MERCHANT_KEY', 'eEIWp_J4zd&OhoCs');
// define('PAYTM_MERCHANT_MID', 'YUGBIT86450645116329');


define('PAYTM_MERCHANT_WEBSITE', 'WEBSTAGING');

$PAYTM_STATUS_QUERY_NEW_URL='https://securegw-stage.paytm.in/merchant-status/getTxnStatus';
$PAYTM_TXN_URL='https://securegw-stage.paytm.in/theia/processTransaction';
if (PAYTM_ENVIRONMENT == 'PROD') {
	$PAYTM_STATUS_QUERY_NEW_URL='https://securegw.paytm.in/merchant-status/getTxnStatus';
	$PAYTM_TXN_URL='https://securegw.paytm.in/theia/processTransaction';
}
define('PAYTM_REFUND_URL', '');
define('PAYTM_STATUS_QUERY_URL', $PAYTM_STATUS_QUERY_NEW_URL);
define('PAYTM_STATUS_QUERY_NEW_URL', $PAYTM_STATUS_QUERY_NEW_URL);
define('PAYTM_TXN_URL', $PAYTM_TXN_URL);


function encrypt_e($input, $ky) {
	$key   = html_entity_decode($ky);
	$iv = "@@@@&&&&####$$$$";
	$data = openssl_encrypt ( $input , "AES-128-CBC" , $key, 0, $iv );
	return $data;
}

function decrypt_e($crypt, $ky) {
	$key   = html_entity_decode($ky);
	$iv = "@@@@&&&&####$$$$";
	$data = openssl_decrypt ( $crypt , "AES-128-CBC" , $key, 0, $iv );
	return $data;
}

function generateSalt_e($length) {
	$random = "";
	srand((double) microtime() * 1000000);

	$data = "AbcDE123IJKLMN67QRSTUVWXYZ";
	$data .= "aBCdefghijklmn123opq45rs67tuv89wxyz";
	$data .= "0FGH45OP89";

	for ($i = 0; $i < $length; $i++) {
		$random .= substr($data, (rand() % (strlen($data))), 1);
	}

	return $random;
}

function checkString_e($value) {
	if ($value == 'null')
		$value = '';
	return $value;
}

function getChecksumFromArray($arrayList, $key, $sort=1) {
	if ($sort != 0) {
		ksort($arrayList);
	}
	$str = getArray2Str($arrayList);
	$salt = generateSalt_e(4);
	$finalString = $str . "|" . $salt;
	$hash = hash("sha256", $finalString);
	$hashString = $hash . $salt;
	$checksum = encrypt_e($hashString, $key);
	return $checksum;
}
function getChecksumFromString($str, $key) {
	
	$salt = generateSalt_e(4);
	$finalString = $str . "|" . $salt;
	$hash = hash("sha256", $finalString);
	$hashString = $hash . $salt;
	$checksum = encrypt_e($hashString, $key);
	return $checksum;
}

function verifychecksum_e($arrayList, $key, $checksumvalue) {
	$arrayList = removeCheckSumParam($arrayList);
	ksort($arrayList);
	$str = getArray2StrForVerify($arrayList);
	$paytm_hash = decrypt_e($checksumvalue, $key);
	$salt = substr($paytm_hash, -4);

	$finalString = $str . "|" . $salt;

	$website_hash = hash("sha256", $finalString);
	$website_hash .= $salt;

	$validFlag = "FALSE";
	if ($website_hash == $paytm_hash) {
		$validFlag = "TRUE";
	} else {
		$validFlag = "FALSE";
	}
	return $validFlag;
}

function verifychecksum_eFromStr($str, $key, $checksumvalue) {
	$paytm_hash = decrypt_e($checksumvalue, $key);
	$salt = substr($paytm_hash, -4);

	$finalString = $str . "|" . $salt;

	$website_hash = hash("sha256", $finalString);
	$website_hash .= $salt;

	$validFlag = "FALSE";
	if ($website_hash == $paytm_hash) {
		$validFlag = "TRUE";
	} else {
		$validFlag = "FALSE";
	}
	return $validFlag;
}

function getArray2Str($arrayList) {
	$findme   = 'REFUND';
	$findmepipe = '|';
	$paramStr = "";
	$flag = 1;	
	foreach ($arrayList as $key => $value) {
		$pos = strpos($value, $findme);
		$pospipe = strpos($value, $findmepipe);
		if ($pos !== false || $pospipe !== false) 
		{
			continue;
		}
		
		if ($flag) {
			$paramStr .= checkString_e($value);
			$flag = 0;
		} else {
			$paramStr .= "|" . checkString_e($value);
		}
	}
	return $paramStr;
}

function getArray2StrForVerify($arrayList) {
	$paramStr = "";
	$flag = 1;
	foreach ($arrayList as $key => $value) {
		if ($flag) {
			$paramStr .= checkString_e($value);
			$flag = 0;
		} else {
			$paramStr .= "|" . checkString_e($value);
		}
	}
	return $paramStr;
}

function redirect2PG($paramList, $key) {
	$hashString = getchecksumFromArray($paramList);
	$checksum = encrypt_e($hashString, $key);
}

function removeCheckSumParam($arrayList) {
	if (isset($arrayList["CHECKSUMHASH"])) {
		unset($arrayList["CHECKSUMHASH"]);
	}
	return $arrayList;
}

function getTxnStatus($requestParamList) {
	return callAPI(PAYTM_STATUS_QUERY_URL, $requestParamList);
}

function getTxnStatusNew($requestParamList) {
	return callNewAPI(PAYTM_STATUS_QUERY_NEW_URL, $requestParamList);
}

function initiateTxnRefund($requestParamList) {
	$CHECKSUM = getRefundChecksumFromArray($requestParamList,PAYTM_MERCHANT_KEY,0);
	$requestParamList["CHECKSUM"] = $CHECKSUM;
	return callAPI(PAYTM_REFUND_URL, $requestParamList);
}

function callAPI($apiURL, $requestParamList) {
	$jsonResponse = "";
	$responseParamList = array();
	$JsonData =json_encode($requestParamList);
	$postData = 'JsonData='.urlencode($JsonData);
	$ch = curl_init($apiURL);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);                                                                  
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                         
	'Content-Type: application/json', 
	'Content-Length: ' . strlen($postData))                                                                       
	);  
	$jsonResponse = curl_exec($ch);   
	$responseParamList = json_decode($jsonResponse,true);
	return $responseParamList;
}

function callNewAPI($apiURL, $requestParamList) {
	$jsonResponse = "";
	$responseParamList = array();
	$JsonData =json_encode($requestParamList);
	$postData = 'JsonData='.urlencode($JsonData);
	$ch = curl_init($apiURL);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);                                                                  
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                         
	'Content-Type: application/json', 
	'Content-Length: ' . strlen($postData))                                                                       
	);  
	$jsonResponse = curl_exec($ch);   
	$responseParamList = json_decode($jsonResponse,true);
	return $responseParamList;
}
function getRefundChecksumFromArray($arrayList, $key, $sort=1) {
	if ($sort != 0) {
		ksort($arrayList);
	}
	$str = getRefundArray2Str($arrayList);
	$salt = generateSalt_e(4);
	$finalString = $str . "|" . $salt;
	$hash = hash("sha256", $finalString);
	$hashString = $hash . $salt;
	$checksum = encrypt_e($hashString, $key);
	return $checksum;
}
function getRefundArray2Str($arrayList) {	
	$findmepipe = '|';
	$paramStr = "";
	$flag = 1;	
	foreach ($arrayList as $key => $value) {		
		$pospipe = strpos($value, $findmepipe);
		if ($pospipe !== false) 
		{
			continue;
		}
		
		if ($flag) {
			$paramStr .= checkString_e($value);
			$flag = 0;
		} else {
			$paramStr .= "|" . checkString_e($value);
		}
	}
	return $paramStr;
}
function callRefundAPI($refundApiURL, $requestParamList) {
	$jsonResponse = "";
	$responseParamList = array();
	$JsonData =json_encode($requestParamList);
	$postData = 'JsonData='.urlencode($JsonData);
	$ch = curl_init($apiURL);	
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_URL, $refundApiURL);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);  
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	$headers = array();
	$headers[] = 'Content-Type: application/json';
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);  
	$jsonResponse = curl_exec($ch);   
	$responseParamList = json_decode($jsonResponse,true);
	return $responseParamList;
}


$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

//Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application�s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); //will return TRUE or FALSE string.


if($isValidChecksum == "TRUE") {
	
    $randorderid=$this->db->select('*')->where('id',$_POST['ORDERID'])->get('kh_ptym_orderid')->row();
	if ($_POST["STATUS"] == "TXN_SUCCESS") {
	    echo "<b class='matched'>Payment Successful</b>" . "<br/>";
	    //echo "<b style='color: green'>Transaction status is success</b>" . "<br/>";
	    echo "<b class='red'>Congratulation! Order Placed Successfully with Order ID <span>".$randorderid->order_uid."</span> Thank You For Shopping With Us</b>";
	    echo "<br>";
		echo "<p><a href='".base_url('order-history.html')."'>View Orders</a></p>";
		
// 		    $orderid=$_POST['merchant_order_id'];
// 			$this->Site_Model->insertPayment();
// 			$data['getOrderData']=$this->Site_Model->getOrderData($orderid);
// 			$data['itemList']=$this->Site_Model->getOrderItemFromCheckout($orderid);
// 			$mailBox = $this->load->view('template/checkoutinvoice',$data,true);

// 			$email=$data['getOrderData']->order_email;
// 			$amount=$data['getOrderData']->order_amount;
// 			$orderuniquecode=$data['getOrderData']->order_unique_code;
// 			$name=$data['getOrderData']->order_firstname;
// 			$mobileNum=$data['getOrderData']->order_phone;
// 			//$testdate=$data['getOrderData']->test_date;


// 			$this->cart->destroy();
// 			$data['order_id']=$data['getOrderData']->order_unique_code;
// 		 	$this->load->view('site/payment/pgResponse',$data);
		//Process your transaction here as success transaction.
		//Verify amount & order id received from Payment gateway with your application's order id and amount.
	}
	else {
	    
	// print_r($_POST);
//     	$this->db->where('order_unique_code',$_POST['ORDERID']);
//     	$this->db->set("order_payment_status",0);
//     	$this->db->set("order_status",0);
//     	$this->db->update("kh_order_tb");
    	
// 		$this->db->set('orderid',$_POST['ORDERID']);
// 		$this->db->set('mid',$_POST['MID']);
// 		$this->db->set('txid',$_POST['TXNID']);
// 		$this->db->set('txn_amount',$_POST['TXNAMOUNT']);
// 		// $this->db->set('payment_mode',$_POST['PAYMENTMODE']);
// 		$this->db->set('curency',$_POST['CURRENCY']);
// 		// $this->db->set('txn_date',$_POST['TXNDATE']);
// 		$this->db->set('status',$_POST['STATUS']);
// 		$this->db->set('bank_txnid',$_POST['BANKTXNID']);
// 		// $this->db->set('bankname',$_POST['BANKNAME']);
// 		$this->db->set('chksume',$_POST['CHECKSUMHASH']);
// 		$this->db->set('resocode',$_POST['RESPCODE']);
// 		$this->db->set('respmsg',$_POST['RESPMSG']);
// 		$this->db->insert('kh_order_payment_paytm');

		echo "<b style='color: red'>Payment Failed</b>" . "<br/>";
		echo "<p><a href='".base_url()."'>Continue To Home Page</a></p>";
	}

	if (isset($_POST) && count($_POST)>0 )
	{ 
		foreach($_POST as $paramName => $paramValue) {
				//echo "<br/>" . $paramName . " = " . $paramValue;
			                     $paramName . " = " . $paramValue;
		}
	}
	

}
else {
	echo "<b>Checksum mismatched.</b>";
	//Process transaction as suspicious.
}

?>
<br><br>
<!--<a href="<?php echo base_url()?>">Return Home </a> | <a href="<?php echo base_url()?>Website/paytmTxnStatus"> Check Status </a>-->


    </div>
    </div> 

  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>