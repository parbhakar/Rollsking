
<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

  	<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");

?>


<?php




$productinfo = $productinfo;
$txnid = time();
$surl = $surl;
$furl = $furl;        
// $key_id = "eEIWp_J4zd&OhoCs";
$key_id = "Pih0ckV0mvk_SjFX";//Test
$currency_code = $currency_code;            
$total = ($order_amount_with_tax * 100);
$amount = $order_amount_with_tax;
$merchant_order_id = $order_id;
$card_holder_name = $order_firstname;
$email = $order_email;
$phone = $order_phone;
$name = "The Rollsking";
$return_url = $return_url;
?>



    <main class="theia-exception">
        <div id="results">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                       <h4>Rev + Makt Payment</h4>
                    </div>
                    <div class="col-md-6">
                       
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /results -->
		<div class="container margin_60" style="transform: none;">
		  <div class="row" style="transform: none;">
		    <div class="col-md-4 col-md-offset-4">
			    <div class="success-main" style="text-align: center;">
			        <i class="icon-money success-bg"></i>
			        <h2>Total Payment: <i class="pricing-b">₹ <?php echo $amount; ?></i></h2>
			   
				<form method="post" action="<?php echo $return_url;?>" id="paytm_forms" class="form-horizontal text-center">
				    <div class="form-group hidden">
				      	<label class="control-label col-sm-4" for="ORDER_ID">Order Id :</label>
				      	<div class="col-sm-8">
							<input id="ORDER_ID" tabindex="1" maxlength="20" size="20" name="ORDER_ID" class="form-control" autocomplete="off" value="<?php echo $productinfo;?>">
				      	</div>
				    </div>

				    <div class="form-group hidden">
				      	<label class="control-label col-sm-4" for="CUST_ID">Customer Id :</label>
				      	<div class="col-sm-8">
							<input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" class="form-control" autocomplete="off" value="<?php echo $merchant_order_id;?>">
				      	</div>
				    </div>

				    <div class="form-group hidden">
				      	<label class="control-label col-sm-4" for="INDUSTRY_TYPE_ID">Industry Type Id :</label>
				      	<div class="col-sm-8">
							<input id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" class="form-control" autocomplete="off" value="Rollsking">
				      	</div>
				    </div>

				    <div class="form-group hidden">
				      	<label class="control-label col-sm-4" for="CHANNEL_ID">Channel :</label>
				      	<div class="col-sm-8">
							<input id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" class="form-control" value="WEB">
				      	</div>
				    </div>

				    <div class="form-group hidden">
				      	<label class="control-label col-sm-4" for="CHANNEL_ID">Txn Amount :</label>
				      	<div class="col-sm-8">
							<input title="TXN_AMOUNT" tabindex="10" class="form-control" type="text" name="TXN_AMOUNT" value="<?php echo round($amount, 2);?>">
				      	</div>
				    </div>

				    <button type="submit" class="btn btn-primary form-control">PAY NOW</button>
				</form>
				 
			   
			    </div>
		    </div>
		    
		    <!-- /asdide -->
		  </div>
		  <!-- /row -->
		</div>
		    <!-- /container -->
		</main>
    <!-- /main -->
		<style>
		    i.icon-money.success-bg {
		color: #116fff;
		}
		.success-main {
		padding: 70px 0;
		}
		.success-main h2 {
		color: #116fff;
		font-weight: 600;
		font-style: normal;
		}
		</style>

    </div>

  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>
