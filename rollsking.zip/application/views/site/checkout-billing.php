<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <!--  <section class="content-header">
      <h1>
        All Products
        <small>Control panel</small>
      </h1>
      
    </section> -->

    <!-- Main content -->
 <style>
 	
 </style>
    
<section class="Content bg-grey" style="">
    <div class="container">
       <div class="row">
          <div class="col-md-12" style="text-align: center; margin-bottom: 16px;">
            <?php echo @$this->session->userdata('message');$this->session->unset_userdata('message'); ?>
          </div>
              <div class="col-md-12">
                <div class="change-password-style billing-style">


           <h2 class="main-title">SAVED ADDRESS  (GO YOUR PROFILE AND ADD ADDRESS)</h2>
            <p class="bottom-border"></p>
					<?php 
					 $userDataforedit->user_id;
						$saveaddress = $this->Site_Model->getsave_More_address_chk_biling($userDataforedit->user_id);
						//print_r($saveaddress);
					if (!empty($saveaddress)) { ?>
     
                    <div class="row">
                      <?php foreach ($saveaddress as $key => $ae) { ?>
                      <div class="col-md-4">
                        <div class="select-add-style">
                        <p><b>User Name :-</b> <?php echo $ae->user_name; ?></p>
                        <p><b>User Mobile :-</b> <?php echo $ae->user_mobile; ?></p>
                        <p><b>User Email :-</b> <?php echo $ae->user_email; ?></p>
                        <p><b>User State :-</b> <?php echo $ae->user_state; ?></p>
                        <p><b>User City :-</b> <?php echo $ae->user_city; ?></p>
                        <p><b>User Address :-</b> <?php echo $ae->user_address; ?></p>
                        <p><b>User Zip :-</b> <?php echo $ae->pin_code; ?></p>
                        <p><b>User GST :-</b> <?php echo $ae->user_gst; ?></p>
                        <br>
                        <a class="btn-success btn-sm" href="<?php echo base_url(); ?>Website/billing_checkout/<?php echo $ae->id; ?>">Use Address</a>
                     
                        </div>
                      </div>
                      
                       <?php } ?>
                    </div>
            <?php }else{ ?>
                <h5 class="text-center">SAVED ADDRESS NOT FOUND PLEASE ADD NEW BILLING DETAILS</h5>
            <?php } ?>
            </section>

            </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>