<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php');  ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

  


<style type="text/css">
.dashboard-18 {
    width: 16.5%;
    float: left;
    margin-top: 4%;
}
.theiaStickySidebar ul {
    list-style-type: none;
}
.theiaStickySidebar ul li {
    line-height: 40px;
}
.theiaStickySidebar ul li a {
    color: #fff;
    font-size: 17px;
}
.content-wrapper {
    width: 83.5%;
    overflow: hidden;
}
.class-for-list{
  text-align: center;
  color: #fff;
}
.class-for-list > a{
  text-align: center;
  color: #fff;
}
.change-password-style {
    background: #fff;
    box-shadow: 0px 0px 11px -11px #000;
    padding: 25px;
    border: 1px solid #e4e4e4;
    border-radius: 5px;
}
h5.dashboard-head {
    /* background: #fbfbfb; */
    padding: 0 0 15px 0;
    margin: 0 0 10px 0;
    color: #444;
    border-bottom: 1px solid #f68f32;
    font-size: 20px;
    font-family: "Gotham", sans-serif;
}
.form-group {
    margin-bottom: 1rem;
}
ul.user-profile li {
    width: 50%;
    float: left;
    padding: 9px 0;
    border-bottom: 1px solid #efefef;
    display: block;
}
ul.user-profile li b {
    width: 100px;
    color: #444;
    text-transform: capitalize;
    /* float: left; */
    /* font-family: "Gotham", sans-serif; */
    font-size: 17px;
    font-weight: 500;
}
.btn-normal {
    font-size: 14px !important;
    padding: 15px 30px !important;
    font-weight: 600;
    color: #fff !important;
    background-color: #f68f32 !important;
    position: relative;
    -webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s;
    display: inline-block;
    line-height: 1;
    border-radius: 2px;
    letter-spacing: 0.7px;
}
.form-group.ed-btn {
    margin-top: 21px !important;
    display: inline-block;
    /* position: relative; */
    /* left: 0; */
    width: 100%;
  
}

</style>
     <section class="bg-grey product ptb-40">
                <div class="container addtocart_count ">
                     <div class="row">
                      <div class="col-md-6">
                          <h2 style="padding: 0px 13px;" class="main-title"> User Profile</h2>
                      </div>
                      <div class="col-md-6">
                         <a href="<?php echo base_url('Website/show_add_sub_address');?>" class="btn btn-flat margin pull-right" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle"></span> Add Addres </a> 
                      </div>
                      
                      
          <div class="col-md-12">
        		<div class="MESSAGE" style=" text-align: center; margin-bottom: 13px; width: 30%; z-index: 9999;">
  				 <p style="color: red; text-align: left;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-center' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
        	</div>
        	</div>
                    </div>
      <!-- Small boxes (Stat box) -->
      <div class="row">
          <div class="col-md-12">
               <div class="change-password-style">
                      
                                  <!--   <h5 class="dashboard-head user_profile_top">User Profile</h5> -->
                                     <div class="form-group">
                                        <!--<p style="text-align: center;"><?php //echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></p>-->
                                        <ul class="user-profile">
                                          <input type="hidden" name="user_id" value="<?php echo $userDataforedit->user_id;?>">
                                             <li><b>Name :</b><span>   <?php echo $userDataforedit->user_name; ?></span></li>
              
                
               <!--  <li><b>Gender</b><span>  <?php  if ($userDataforedit->user_gender == 1) { 
                          echo "Male";
                }elseif ($userDataforedit->user_gender == 2) {
                  echo "Female";
                }else{
                  echo "Please Select Gender";
                } ?></span></li> -->

                <li><b>Email :</b><span>  <?php echo $userDataforedit->user_email; ?></span></li>
                <li><b>Mobile :</b><span>  <?php echo $userDataforedit->user_mobile; ?></span></li>
                <li><b>Outlet Name :</b><span>  <?php echo $userDataforedit->user_outlet; ?></span></li>
                <li><b>GST Number :</b><span>  <?php echo $userDataforedit->user_gst; ?></span></li>
                <li><b>State :</b><span>  <?php echo $userDataforedit->user_state; ?></span></li>
                <li><b>City :</b><span>   <?php echo $userDataforedit->user_city; ?></span></li>
                <li><b>Zipcode :</b><span><?php echo $userDataforedit->user_zipcode; ?></span></li>
                <li><b>Adress :</b><span> <?php echo $userDataforedit->user_address; ?></span></li>
                                        </ul>
                                    </div>

                                    <div class="form-group ed-btn">
                                        <a class="btn btn-normal" href="<?php echo base_url('edit-profile.html');?>">Edit Profile</a>
                                    </div>
                                 
                    </div>
          </div>
      </div>

      <br>
      <br>
       <div class="row">
          <div class="col-md-12">
            <h3>Billing Address  </h3>

               
                       <table class="table table-striped table-bordered bootstrap-datatable table-data-main datatable" style="font-size: 12px;">
                    <thead class="th-hidden">
                    <tr>
                        <th>Sr.No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Outlet</th>
                        <th>GST</th>
                        <th>State</th>
                        <th>City</th>
                        <th>Pincode</th>
                         <th>Address</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <?php
                    $a = 1;
                    $userDataforedit->user_id;
                    $saveaddres = $this->Site_Model->getsave_More_address($userDataforedit->user_id);
                     
                    foreach($saveaddres as $saveaddress){
                      //print_r($saveaddress->status);
                      $a;

                    ?>
                         <tr>
                           <td><?php echo $a++;?></td>
                            <td><?php echo $saveaddress->user_name; ?></td>
                            <td><?php echo $saveaddress->user_email; ?></td>
                            <td><?php echo $saveaddress->user_mobile; ?></td>
                            <td><?php echo $saveaddress->user_shop; ?></td>
                            <td><?php echo $saveaddress->user_gst; ?></td>
                            <td>

                                <?php
                                 $state = $this->Admin_Model->getStateName($saveaddress->user_state);
                                  
                                 echo @$state->state_name; 
                                 ?>
                                
                            </td>
                            <td><?php echo $saveaddress->user_city; ?></td>
                            <td><?php echo $saveaddress->pin_code; ?></td>
                             <td><?php echo $saveaddress->user_address; ?></td>
                          <td>
                            <?php
                            if($saveaddress->status==2){ ?>
                                    <p>Approved</p>

                           <?php }else{ ?>

                            <?php
                             if($saveaddress->status==1){

                                echo "Pending";
                            }elseif($saveaddress->status==2){
                                echo "Approved";
                            }else{
                                echo "Reject";
                            }

                             ?>

                             <br>
                            <a href="<?php echo base_url('Website/show_multi_address_edit/'.$saveaddress->id);?>" class="btn btn-info"><i class="glyphicon glyphicon-edit icon-white"></i></a>

                            <a href="<?php echo base_url('Website/deletesaveaddress/'.$saveaddress->id);?>" class="btn btn-danger" onclick="return confirm('Do you really want to delete this Address')"><i class="glyphicon glyphicon-trash icon-white"></i></a>
                           <?php }
                            ?>
                           

                          </td>
                          </tr>
                        <?php } ?>
                    <tbody>

                    </tbody>
                    </table>
          </div>
      </div>
    </section>
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>