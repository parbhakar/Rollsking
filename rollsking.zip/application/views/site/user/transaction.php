<?php $this->load->view('site/components/header');?>


   <section class="float-left dashboard-100">
                <div class="dashboard-18">
                    <?php $this->load->view('site/components/sidebar'); ?>

                </div>
                <div class="dashboard-82">

                    <div class="change-password-style">
                        <h5 class="dashboard-head">Amount Transaction (Last 10 Transaction)</h5>
<p style="text-align: center;"><?php echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></p>
     <table id="example" class="table-transaction table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No</th>
        <th>Date & Time</th>
        <th>Transaction No</th>
        <th>Transaction Source</th>
        <th>Credit</th>
        <th>Debit</th>
        <th>Total Amount</th>
     
    </tr>
    </thead>
    <tbody>
  <?php
   $kk=1;
  if(count($amount_transaction_list)>0)
  {
    foreach($amount_transaction_list as $ae) {
  ?>
    <tr>
        <td><span class="title-responsive"> S.No</span> <?php echo $kk; ?></td>
        <td><span class="title-responsive"> Date & Time</span> <?php echo date('d, M Y',strtotime($ae->transaction_created)); ?></td>
        <td><span class="title-responsive"> Transaction No</span> <?php echo $ae->transaction_number; ?></td>
        <td><span class="title-responsive"> Transaction Source</span> <?php echo $ae->transaction_from; ?></td>
        <td><span class="title-responsive"> Credit</span> <?php if($ae->transaction_credit_amount != 0){echo $ae->transaction_credit_amount;}else{ }; ?></td>
        <td><span class="title-responsive"> Debit</span> <?php if($ae->transaction_debit_amount != 0){echo $ae->transaction_debit_amount;}else{ }; ?></td>
        <td><span class="title-responsive"> Total Amount</span> Rs.<?php echo $ae->transaction_available_amount; ?>/-</td>
        </td>
    </tr>
  <?php $kk++; } } ?>
    </tbody>
    </table>
                    </div>

                </div>

            </section>
 <?php $this->load->view('site/components/footer');?>