<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php');  ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

  


<style type="text/css">
.dashboard-18 {
    width: 16.5%;
    float: left;
    margin-top: 4%;
}
.theiaStickySidebar ul {
    list-style-type: none;
}
.theiaStickySidebar ul li {
    line-height: 40px;
}
.theiaStickySidebar ul li a {
    color: #fff;
    font-size: 17px;
}
.content-wrapper {
    width: 83.5%;
    overflow: hidden;
}
.class-for-list{
  text-align: center;
  color: #fff;
}
.class-for-list > a{
  text-align: center;
  color: #fff;
}
.change-password-style {
    background: #fff;
    box-shadow: 0px 0px 11px -11px #000;
    padding: 25px;
    border: 1px solid #e4e4e4;
    border-radius: 5px;
}
h5.dashboard-head {
    /* background: #fbfbfb; */
    padding: 0 0 15px 0;
    margin: 0 0 10px 0;
    color: #444;
    border-bottom: 1px solid #f68f32;
    font-size: 20px;
    font-family: "Gotham", sans-serif;
}
.form-group {
    margin-bottom: 1rem;
}
ul.user-profile li {
    width: 50%;
    float: left;
    padding: 9px 0;
    border-bottom: 1px solid #efefef;
    display: block;
}
ul.user-profile li b {
    width: 100px;
    color: #444;
    text-transform: capitalize;
    /* float: left; */
    /* font-family: "Gotham", sans-serif; */
    font-size: 17px;
    font-weight: 500;
}
.btn-normal {
    font-size: 14px !important;
    padding: 15px 30px !important;
    font-weight: 600;
    color: #fff !important;
    background-color: #f68f32 !important;
    position: relative;
    -webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s;
    display: inline-block;
    line-height: 1;
    border-radius: 2px;
    letter-spacing: 0.7px;
}
.form-group.ed-btn {
    margin-top: 21px !important;
    display: inline-block;
    /* position: relative; */
    /* left: 0; */
    width: 100%;
    margin-left: 40px;
}

</style>
     <section class="bg-grey product ptb-40">
                <div class="container addtocart_count ">
                     <div class="row">
                      <div class="change-password-style">
              <h5 class="dashboard-head">Personal Information</h5>
             
                  <form  method="post" action="<?php echo base_url('Website/editSubmitProfile'); ?>">
        <div class="row">
        <div class="form-group col-md-6">
            <label>First Name <span>*</span></label>
            <input name="name" placeholder="Your Name" class="form-control" type="text" value="<?php echo $userDataforedit->user_name; ?>">
            <?php echo form_error('name'); ?>
        </div>

        <div class="form-group col-md-6">
            <label>E-Mail <span>*</span></label>
            <input placeholder="Your Email" disabled name="email" class="form-control" type="text" value="<?php echo $userDataforedit->user_email; ?>">
             <?php //echo form_error('email'); ?>
        </div>


 
        <!-- <div class="form-group col-md-6">
            <label>Gender<span>*</span></label>
            <select name="gender" class="form-control">
                <option  value="">Select Gender</option>
                <option value="1" <?php if($userDataforedit->user_gender == 1){ echo "selected";} ?>>Male</option>
                <option value="2" <?php if($userDataforedit->user_gender == 2){ echo "selected";} ?>>Female</option> 
            </select>
             <?php //echo form_error('gender'); ?>
        </div> -->

        
        <div class="form-group col-md-6">
            <label>Phone <span>*</span></label>
            <input placeholder="Your Phone" name="phone" class="form-control" type="text" value="<?php echo $userDataforedit->user_mobile; ?>">
            <?php echo form_error('phone'); ?>
        </div>
        <div class="form-group col-md-6">
            <label>State</label>
            <input placeholder="State" type="text" class="form-control" name="state" value="<?php echo $userDataforedit->user_state; ?>">
            <?php echo form_error('state'); ?>
        </div>
        <div class="form-group col-md-6">
            <label>City</label>
            <input placeholder="City" type="text" class="form-control" name="city" value="<?php echo $userDataforedit->user_city; ?>">
            <?php echo form_error('city'); ?>
        </div>
        <div class="form-group col-md-6">
            <label>Zipcode</label>
            <input placeholder="Zip Code" type="text" class="form-control" name="zipcode" value="<?php echo $userDataforedit->user_zipcode; ?>">
            <?php echo form_error('zipcode'); ?>
        </div>
        <div class="form-group col-md-12">
            <label>Address</label>
            <textarea placeholder="Your Address" class="form-control" rows="3" cols="80" name="address"><?php echo $userDataforedit->user_address; ?></textarea>
            <?php echo form_error('address'); ?>
        </div>
        <div class="form-group col-md-12">
            <input type="submit" name="submit" value="Update Profile" class="btn btn-normal">
        </div>

    </div>
</form>
            </div>
          </div>
      </div>
    </section>
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>