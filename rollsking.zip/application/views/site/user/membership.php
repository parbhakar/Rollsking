<?php $this->load->view('site/components/header');?>
 

<section class="float-left dashboard-100">
                    <div class="dashboard-18">
                            <?php $this->load->view('site/components/sidebar'); ?>
                        </div>
                        <div class="dashboard-82">
	<style>
          					    ul.user-profile li b {
                                    width: 165px;
          					    }
          					</style>
                       	
                       		<?php 
                          $memberStatus=$this->Site_Model->getMemberShipStatus(); 
                          if (!empty($memberStatus)) {  ?>
          										
          										<?php //print_r($memberStatus); ?>
          								
          								
          									
          						<div class="change-password-style" style="position: absolute;">
                                    <h5 class="dashboard-head">Membership </h5>
                               
                                        <p style="text-align: center;">Congratulations, you are a member of Daily Kirane Wala. You will get exciting offers and free deliveries as applicable. To know more  visit our website www.thekiranewala.com/membership.html</p>
                                        <ul class="user-profile">
                                             <li><b>Packages Name</b><span>   <?php echo $memberStatus->pack_name; ?></span></li>
                                            <li><b>Packages Price</b><span>   Rs.<?php echo $memberStatus->pack_price; ?>/-</span></li>
                                            <li><b>Purchase Date</b><span>   <?php echo   date("d M Y", strtotime($memberStatus->purchase_data)); ?></span></li>
                                            <li><b>Expiry Date</b><span>   <?php echo  date("d M Y", strtotime($memberStatus->expiry_date)); ?></span></li>
                                        </ul>
                  
                                    </div>
                            
          									
                       		<?php }else{ ?>    
                             	<?php $this->load->view('site/components/membership-components'); ?>
                       		<?php } ?>

                        </div>

                   
             </section>
 <?php $this->load->view('site/components/footer');?>