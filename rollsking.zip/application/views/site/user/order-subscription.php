<?php $this->load->view('site/components/header');?>


            <section class="float-left dashboard-100">
                <div class="dashboard-18">
                   <?php $this->load->view('site/components/sidebar'); ?>

                </div>
                <div class="dashboard-82">
                    <div class="change-password-style">
                        <h5 class="dashboard-head">Subscription Order List</h5>
 
                       <table class="table table-striped table-bordered bootstrap-datatable table-data-main datatable" style="font-size: 12px;">
                    <thead class="th-hidden">
                    <tr>
                        <th>Sr.No</th>
                        <th>Order</th>
                        <th>Delivery</th>
                        <th>Payment Amount</th>
                        <th>Order Date</th>
                        <th>Payment Type</th>
                        <th>Payment</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                    <?php @$orderData=$this->Site_Model->orderSubscriptionDatas(); $i=0;?>
                      <tbody>
                        <?php if (!empty($orderData)) : foreach($orderData as $order): $i++;?>
                        <tr class="main-tr">
                          <td><span class="title-responsive">Sr.No</span> <?php echo $i; ?></td>
                          <td><span class="title-responsive">Order</span>
                            <b>Order ID :-</b> <?php echo $order->order_unique_code; ?><br>
                            <b>User Name :-</b> <?php echo $order->order_firstname; ?>
                          </td>                         
                          <td><span class="title-responsive">Delivery</span> Rs.<?php echo $order->order_delivery; ?>/-</td>
                          <td><span class="title-responsive">Payment Amount</span> Rs. <?php echo $order->order_amount; ?>/-</td>
                          <td><span class="title-responsive">Order Date </span> <?php echo $order->order_created; ?> </td>
                          <td><span class="title-responsive">Payment Type</span>
                            <?php  if($order->payment_type==1){?>
                            <span>Cash</span> 
                            <?php } else if($order->payment_type==2) { ?>  
                            <span>Online</span>
                            <?php }else{
                              echo "";
                            } ?>
                          </td>
                          <td><span class="title-responsive">Payment</span>
                            <?php  if($order->order_payment_status==1){?>
                            <span>Paid</span> 
                            <?php } else if($order->order_payment_status==0) { ?>  
                            <span>Pending</span>
                            <?php }else{
                              echo "";
                            } ?>
                          </td>
                          <td><span class="title-responsive">Action</span>
                          
                          <?php 
                           if ($order->order_status == 0) { ?>

                             <a href="" ><span class="btn btn-default btn-sm" style="background-color: #f10808 !important;  color: #fff;">Canceled By You</span></a>

                           <?php } elseif ($order->order_status == 1) { ?>
                             <a href="#" class="btn btn-success btn-sm mb-1">Order Process</a>
                             <br>
                              <a href="<?php echo base_url('Website/subcancleOrder/'.$order->order_id.'/0/'); ?>" onclick="return confirm('Do you really want to cancel this order ?')" class="btn btn-sm btn-danger"> Cancel Order </a>

                           <?php }elseif ($order->order_status == 2) { ?>
                             
                             <a href="#" class="btn btn-success btn-sm">Order Packed</a>
                              
                           <?php }elseif ($order->order_status == 3) { ?>

                              <a href="#" class="btn btn-success btn-sm">Order Shipped</a>
                              
                           <?php }elseif ($order->order_status == 4) { ?>

                            <a href="#" class="btn btn-success btn-sm"> Order Delivered</a>
                      
                           <?php }elseif ($order->order_status == 5) { ?>
                            <a href="#" class="btn btn-success btn-sm"> Order Done</a>
                           <?php }else{ ?>
                             <a href="" ><span class="btn btn-primary btn-sm" style="background-color: #f10808 !important;  color: #fff;">Canceled By Admin</span></a>

                           <?php }?>






                             <button  class="btn btn-primary btn-sm" onclick="myFunction<?php echo $order->order_id; ?>()">Show Product</button>
                           
                          </td>
                        </tr>
                        
                        <script>
                            function myFunction<?php echo $order->order_id; ?>() {
                              var x = document.getElementById("myDIV_<?php echo $order->order_id; ?>");
                              if (x.style.display === "none") {
                                x.style.display = "contents";
                              } else {
                                x.style.display = "none";
                              }
                            }
                        </script>
                        
                        <tr id="myDIV_<?php echo $order->order_id; ?>" style="display: none;">
                          <td colspan="8" class="inner-td">
                            <table class="table table-striped table-bordered bootstrap-datatable responsive datatable">
                            <thead class="th-hidden">
                            <tr>
                                <th>Sr.No</th>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Product Code</th>
                                <th>Delivery Date</th>
                                <th>Subtotal</th>
                            </tr>
                            </thead>
                            <tbody class="table-inner-table">
                            <?php $orderSersvice=$this->Site_Model->getSubscriptionOrderServces($order->order_id); ?>
                            <?php $k=0; if (!empty($orderSersvice)): foreach ($orderSersvice as $service): $k++;?>
                              <tr>
                                <td><span class="title-responsive">Sr.No</span> <?php echo $k; ?></td>
                                <td><span class="title-responsive">Product Image</span> <?php $productimg= $this->Site_Model->GetProductImages($service->product_id); ?>
                                    
                                  
            
                                    <?php if (!empty($productimg->product_img)) { ?>
                                      <img data-src="<?php echo base_url('uploads/product/thumbnail/'); ?><?php echo $productimg->product_img; ?>" src="<?php echo base_url();?>assets/loding.gif" class="lazy" style="width: 25px;" alt="<?php echo $productimg->product_img; ?>">
                                    <?php  } else { ?>
                                        <img data-src="<?php echo base_url(); ?>admin_assets/img/no-image-icon.png" class="lazy" src="<?php echo base_url();?>assets/loding.gif" style="width: 25px;" alt="product">
                                    <?php } ?>




                                </td>

                                <td><span class="title-responsive">Product Name</span> <?php echo $service->name; ?></td>
                                <td><span class="title-responsive">Product Code</span> <?php echo $service->code; ?></td>
                                <td><span class="title-responsive">Delivery Date</span> <?php echo date('d, M Y', strtotime($service->date)); ?></td>
                                <td><span class="title-responsive">Subtotal</span> Rs.<?php echo $service->price; ?>/-
                                </td>
                              </tr>
                          <?php endforeach; ?>
                          <?php endif; ?>
                            </tbody>
                          </table>
                          </td>

                        </tr>
                          <?php endforeach;?>
                    <?php endif; ?>
                      </tbody>
                    </table>
                    </div>
                </div>

            </section>

   <?php $this->load->view('site/components/footer');?>