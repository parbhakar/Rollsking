<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
   <?php $this->load->view('site/components/sidebar.php');  ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

  


<style type="text/css">
a.btn.btn-success.btn-sm.mb-1 {
    font-size: inherit;
}
.dashboard-18 {
    width: 16.5%;
    float: left;
    margin-top: 4%;
}
.theiaStickySidebar ul {
    list-style-type: none;
}
.theiaStickySidebar ul li {
    line-height: 40px;
}
.theiaStickySidebar ul li a {
    color: #fff;
    font-size: 17px;
}
.content-wrapper {
    width: 83.5%;
    overflow: hidden;
}
.class-for-list{
  text-align: center;
  color: #fff;
}
.class-for-list > a{
  text-align: center;
  color: #fff;
}
.change-password-style {
    background: #fff;
    box-shadow: 0px 0px 11px -11px #000;
    padding: 25px;
    border: 1px solid #e4e4e4;
    border-radius: 5px;
}
h5.dashboard-head {
    /* background: #fbfbfb; */
    padding: 0 0 15px 0;
    margin: 0 0 10px 0;
    color: #444;
    border-bottom: 1px solid #f68f32;
    font-size: 20px;
    font-family: "Gotham", sans-serif;
}
.form-group {
    margin-bottom: 1rem;
}
ul.user-profile li {
    width: 50%;
    float: left;
    padding: 9px 0;
    border-bottom: 1px solid #efefef;
    display: block;
}
ul.user-profile li b {
    width: 100px;
    color: #444;
    text-transform: capitalize;
    /* float: left; */
    /* font-family: "Gotham", sans-serif; */
    font-size: 17px;
    font-weight: 500;
}
.btn-normal {
    font-size: 14px !important;
    padding: 15px 30px !important;
    font-weight: 600;
    color: #fff !important;
    background-color: #f68f32 !important;
    position: relative;
    -webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s;
    display: inline-block;
    line-height: 1;
    border-radius: 2px;
    letter-spacing: 0.7px;
}
.form-group.ed-btn {
    margin-top: 21px !important;
    display: inline-block;
    /* position: relative; */
    /* left: 0; */
    width: 100%;
    margin-left: 40px;
}
td.test_processs p {
    font-size: 18px;
    font-weight: 600;
}

</style>
     <section class="bg-grey product ptb-40">
                <div class="container addtocart_count ">
                     <div class="row">
                      <div class="col-md-12">
                         
                          <h2 style="padding: 0px 13px;" class="main-title"> Order List</h2>
                          <div class="float-right order-search">
                        
                            <select name="" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);" class="form-control search-order">
                           
                            <option hidden="">Select Address</option>
                             <option value="<?php echo base_url();?>order-history.html">All</option>
                             <?php
                            $userSession_id = $this->session->userdata('activeUserId');
                            $address = $this->Site_Model->getsave_More_address($userSession_id);

                            foreach($address as $ad){
                            ?>
                            <option value="<?php echo base_url();?>order-history.html/<?php echo $ad->id;?>"><?php echo $ad->user_name;?></option>
 
                          <?php } ?>
                          </select>
                         </div>
                          
                           
                      </div>
                    </div>
      <!-- Small boxes (Stat box) -->
      <div class="row">
          <div class="col-md-12">
               
                       <table class="table table-striped table-bordered bootstrap-datatable table-data-main datatable" style="font-size: 12px;">
                    <thead class="th-hidden">
                    <tr>
                        <th>Sr.No</th>
                        <th>Order</th>
                        <!-- <th>Delivery</th> -->
                        <th>Payment Amount</th>
                        <th>Order Date</th>
                        <th>Payment Type</th>
                        <th>Payment</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                    <?php @$orderData=$this->Site_Model->orderDatas(); $i=0;?>
                      <tbody>
                        <?php if (!empty($orderData)) : foreach($orderData as $order): $i++;?>
                        <tr class="main-tr">
                          <td><span class="title-responsive">Sr.No</span> <?php echo $i; ?></td>
                          <td><span class="title-responsive">Order</span>
                            <b>Order ID :-</b> <?php echo $order->order_unique_code; ?><br>
                            <b>User Name :-</b> <?php echo $order->order_firstname; ?>
                          </td>                         
                         <!--  <td><span class="title-responsive">Delivery</span> Rs.<?php echo $order->order_delivery; ?>/-</td> -->
                         <td><span class="title-responsive">Payment Amount</span> Rs. <?php echo $this->cart->format_number($order->order_amount,2); ?>/-</td>
                          <td><span class="title-responsive">Order Date </span> <?php echo $order->order_created; ?> </td>
                          <td><span class="title-responsive">Payment Type</span>
                            <?php  if($order->payment_type==1){?>
                            <span>Cash</span> 
                            <?php } else if($order->payment_type==2) { ?>  
                            <span>Online</span>
                            <?php } else if($order->payment_type==3) { ?>  
                            <span>Online Paytm</span>
                            <?php }else{
                              echo "";
                            } ?>
                          </td>
                          <td><span class="title-responsive">Payment</span>
                            <?php  if($order->order_payment_status==1){?>
                            <span>Paid</span> 
                            <?php } else if($order->order_payment_status==0) { ?>  
                            <span>Pending</span>
                            <br><br>

                              <a href="<?php echo base_url()?>Website/repayment_paytm/<?php echo $order->order_id;?>" class="btn btn-warning btn-xs">Re-Payment</a>
                            <?php } ?>
                           <br>
                           <br>
                           <a target="_blank" href="<?php echo base_url('Website/invoice_history/').$order->order_id; ?>" class="btn btn-success btn-xs">View Invoice</a> 
                          </td>
                          <td class="test_processs"><span class="title-responsive">Action</span>
                          
                          <?php 
                           if ($order->order_status == 0) { ?>

                              <p>Canceled By You</p>

                           <?php } elseif ($order->order_status == 1) { ?>
                             <p>Order Process</p>
                             <br>
                              <a href="<?php echo base_url('Website/cancleOrder/'.$order->order_id.'/0/'); ?>" onclick="return confirm('Do you really want to cancel this order ?')" class="btn btn-sm btn-danger"> Cancel Order </a>

                           <?php }elseif ($order->order_status == 2) { ?>
                             
                             <p>Order Packed</p>
                              
                           <?php }elseif ($order->order_status == 3) { ?>

                             <p>Order Shipped</p>
                              
                           <?php }elseif ($order->order_status == 4) { ?>

                           <p> Order Delivered</p>
                      
                           <?php }elseif ($order->order_status == 5) { ?>
                            <p>Order Done</p>
                           <?php }else{ ?>
                           <p>Canceled By Admin</p>

                           <?php } ?>






                             <button  class="btn btn-primary btn-sm" onclick="myFunction<?php echo $order->order_id; ?>()">Show Product</button>
                             <a style="color: #fff;" href="<?php echo base_url();?>Website/reorder_order_item/<?php echo $order->order_id?>" class="btn btn-primary btn-sm">Reorder Order</a>

                            
                           
                          </td>
                        </tr>
                        
                        <script>
                            function myFunction<?php echo $order->order_id; ?>() {
                              var x = document.getElementById("myDIV_<?php echo $order->order_id; ?>");
                              if (x.style.display === "none") {
                                x.style.display = "contents";
                              } else {
                                x.style.display = "none";
                              }
                            }
                        </script>
                        
                        <tr id="myDIV_<?php echo $order->order_id; ?>" style="display: none;">
                          <td colspan="8" class="inner-td">
                            <table class="table table-striped table-bordered bootstrap-datatable responsive datatable">
                            <thead class="th-hidden">
                            <tr>
                                <th>Sr.No</th>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Product Code</th>
                                <th>Unit Price</th>
                                <th>Qty</th>
                                <th>Subtotal</th>
                                <th>Return Order</th>
                            </tr>
                            </thead>
                            <tbody class="table-inner-table">
                            <?php $orderSersvice=$this->Site_Model->getOrderServces($order->order_id); ?>
                            <?php $k=0; if (!empty($orderSersvice)): foreach ($orderSersvice as $service): $k++;?>
                              <tr>
                                <td><span class="title-responsive">Sr.No</span> <?php echo $k; ?></td>
                                <td><span class="title-responsive">Product Image</span> <?php $productimg= $this->Site_Model->GetProductImages($service->product_id); ?>
                                    
                                    <img src="<?php echo base_url(); ?>uploads/product/<?php echo $productimg->product_img; ?>" style="width: 45px;" alt="<?php echo $productimg->product_img; ?>">
            
                                </td>
                                <td><span class="title-responsive">Product Name</span> <?php echo $service->name; ?></td>
                                <td><span class="title-responsive">Product Code</span> <?php echo $service->code; ?></td>
                                <td><span class="title-responsive">Product Code</span> <?php echo $service->one_price; ?></td>
                                <td><span class="title-responsive">Product Code</span> <?php echo $service->qty; ?></td>
                                <td><span class="title-responsive">Subtotal</span> Rs.<?php echo $service->price; ?>/-
                                </td>
                                <td id="refer_id<?php echo $service->item_id;?>"> 
                                  <?php
                                  if($order->order_status == 4){ ?>
                                    <?php
                                    if($service->status == 1){ ?>
                                      <form method="post" enctype="multipart/form-data" id="returnorder<?php echo $service->item_id;?>" action="">
                                       <input type="checkbox" id="itemid<?php echo $service->item_id;?>" name="itemid" value="<?php echo $service->item_id;?>">
                                       <!--  <input type="file" name="rimage" id="img<?php echo $service->item_id;?>"> -->
                                      
                                       <input type="submit" class="btn btn-default btn-sm" >
                                    </form>
                                    <?php } ?>
                                      
                                    <?php } ?>
                                   
                                  </td>
                              </tr>
                           
                           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                            
                                 
                          <?php endforeach; ?>


                          <?php endif; ?>
                            </tbody>
                          </table>
                          </td>

                        </tr>
                          <?php endforeach;?>
                          
                           <?php
                               foreach ($orderSersvice as $ae) { 
                                ?>
                            <script type="">

                            $('#returnorder<?php echo $ae->item_id;?>').on('submit', function(e)
                            {
                                  //alert('Hello');
                                    var itemid = $("#itemid<?php echo $ae->item_id; ?>").val();
                                     var img = $("#img<?php echo $ae->item_id; ?>").val();
                                     //alert(itemid);die();

                                    
                                    $.ajax({
                                        url: "<?php echo base_url('Website/returnorderajax'); ?>",
                                        type: "post",
                                        data: {itemid : itemid, img : img},
                                        dataType: "json",
                                        //cache: false,
                                       /* 
                                        success: function(response,textStatus){
                                           
                                          $('#itemid<?php echo $service->item_id;?>').html(response);   //select the id and put the response in the html
                                        },*/
                                        success: function (json) {
                                            //alert(json);die();

                                             
                                            var message = json.message;
                                            console.log(message);

                                             $("#addtocartRef").load(location.href + " #addtocartRef");
                                            $("#addtocartRefdesk").load(location.href + " #addtocartRefdesk");
                                            
                                           $("#respons").html(json);
                                            var x = document.getElementById("snackbar");
                                            //alert(x);
                                            x.className = "show";
                                            setTimeout(function(){
                                             x.className = x.className.replace("show", ""); }, 
                                             3000);
                                             location.reload();
                                            
                                        }
                                    });
                                    e.preventDefault();
                                });
                            </script>

                            <?php  } ?>
                    <?php endif; ?>
                      </tbody>
                    </table>
          </div>
      </div>

    </section>
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>


 