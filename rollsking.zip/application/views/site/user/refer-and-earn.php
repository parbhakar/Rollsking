<?php $this->load->view('site/components/header');?>
 

<section class="float-left dashboard-100">
                    <div class="dashboard-18">
                            <?php $this->load->view('site/components/sidebar'); ?>

                        </div>
                        <div class="dashboard-82">
 <?php 
            $userid=$this->session->userdata('activeUserId');
            $username=$this->Site_Model->getUserName($userid);
             ?>
            
            <div class="row">

                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                                <input type="text" class="form-control"  value="<?php echo base_url(); ?>user-register.html?refer_id=<?php echo $username->username; ?>" id="myInput">
                                <script>
                                function myFunction() {
                                  var copyText = document.getElementById("myInput");
                                  copyText.select();
                                  copyText.setSelectionRange(0, 99999)
                                  document.execCommand("copy");
                                  alert("Copied the text: " + copyText.value);
                                }
                                </script>
                        </div>
                        <div class="col-md-4">
                            <button onclick="myFunction()" class="btn btn-success" >Copy text</button>
                        </div>
            </div>                        

</div>

                   
             </section>
 <?php $this->load->view('site/components/footer');?>