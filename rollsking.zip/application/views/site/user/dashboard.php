<?php $this->load->view('site/components/header');?>
 

<section class="float-left dashboard-100">
                    <div class="dashboard-18">
                            <?php $this->load->view('site/components/sidebar'); ?>

                        </div>
                        <div class="dashboard-82">

                             <?php $orderData=$this->Site_Model->getOrderDataforUserDashboard(); ?>
                                 
                                    <div class="dashboard-1">
                                        <h4 class="dash-head"><?php echo count($orderData); ?></h4>
                                        <p class="dash-p">Total No. of Order</p>
                                        <div class="icon">
                                            <i class="fas fa-shopping-cart"></i>
                                        </div>
                                        <a href="<?php echo base_url('order-history.html'); ?>" class="dash-btn">More info <i class="fas fa-arrow-circle-right"></i></a>
                                    </div>
                                

                                
<?php  
$TotalAmount=0;
foreach ($orderData as $value) {
  $TotalAmount +=$value->order_amount;
}
  
?>
                                    <div class="dashboard-2">
                                        <h4 class="dash-head"><?php echo $TotalAmount; ?></h4>
                                        <p class="dash-p">Total Payment</p>
                                        <div class="icon">
                                            <i class="fas fa-rupee-sign"></i>
                                        </div>
                                        <a href="<?php echo base_url('order-history.html'); ?>" class="dash-btn">More info <i class="fas fa-arrow-circle-right"></i></a>
                                    </div>
                                

                                <?php $userdataForWallet= $this->Site_Model->getWalletAmount($this->session->userdata('activeUserId')); ?>
                                      

                                <div class="dashboard-1">
                                        <h4 class="dash-head">Rs.<?php echo $userdataForWallet->user_wallet_amount; ?>/-</h4>
                                        <p class="dash-p">Wallet Amount</p>
                                        <div class="icon">
                                            <i class="fas fa-rupee-sign"></i>
                                        </div>
                                        <a href="#" class="dash-btn">More info <i class="fas fa-arrow-circle-right"></i></a>
                                    </div>

                                

                        </div>

                   
             </section>
 <?php $this->load->view('site/components/footer');?>