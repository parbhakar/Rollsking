 



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Rollsking | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>admin_assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>admin_assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url();?>admin_assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>admin_assets/dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url();?>admin_assets/plugins/iCheck/square/blue.css">

 

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page" style="height: 0px;">

    <div class="login-box" style="margin: 8% auto;">
  <div class="login-logo">
    <a href="javascript:;"><img src="<?php echo base_url();?>assets/img/logo/logo_.png" style="width: 230px;"></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
   
    <p class="login-box-msg" style="padding: 7px 20px 7px 20px; background-color: #3c8dbc; margin-bottom: 9px; color: #fff;">FORGET PASSWORD</p>
         <!--  <div class="form-group">
            <p class="text-center"><?php //echo $this->session->flashdata('message'); ?></p>
          </div> -->
            <form method="post" action="<?php echo base_url('Website/submitForgetPassword'); ?>">
              <div class="form-group">
                <p class="text-center"><?php echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></p>
              </div>
              <div class="form-group">
                <input type="email" name="email" id="user_email" class="form-control" placeholder="Your email address" value="<?php echo set_value('user_email'); ?>">
                <?php echo form_error('user_email') ?>
              </div>
              <div class="form-group text-center add_top_20">
                 <input class="btn btn-style-form medium" type="submit" value="Forget Password">
              </div>
            </form>
                 
        <a href="<?php echo base_url('user-login.html'); ?>" class="txt-default pt-3 db-block">Back to sing in</a>  
    
  </div>
   
    <style type="">
        .home_PAGE p {
    font-size: 15px;
    font-weight: 600;
}

.home_PAGE {
    margin: 15px 0px;
    background: #e9ae49;
}
    </style>
</div>
<!-- /.login-box -->



<!-- jQuery 3 -->
<script src="<?php echo base_url();?>admin_assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url();?>admin_assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url();?>admin_assets/plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
