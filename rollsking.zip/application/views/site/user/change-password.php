<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
   <?php $this->load->view('site/components/sidebar.php');  ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

  
   <section class="bg-grey product ptb-40">
                <div class="container addtocart_count ">
                     <div class="row">
                       <div class="col-md-12">
                              <div class="change-password-style">
                                <h2 style="padding: 0px 13px;" class="main-title">Change Password</h2>
                                
                                <p style="text-align: center;"><?php echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></p>
                                <form name="updateProfile" method="post" action="<?php echo base_url('Website/changepassworddata'); ?>">
                                    <div class="row">

                                        <div class="form-group col-md-6">
                                            <label>New Password <span>*</span></label>
                                            <input name="pass" placeholder="Enter New Password" required="" class="form-control bg-white-form" type="text">
                                              <?php echo form_error('pass'); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Confirm Password <span>*</span></label>
                                            <input name="co_pass" placeholder="Confirm Password" required="" class="form-control bg-white-form" type="text">
                                            <?php echo form_error('co_pass'); ?>
                                        </div>

                                        <div class="form-group col-md-12">
                                            <input type="submit" name="submit" value="Update Password" class="btn btn-normal submit-btn">
                                        </div>

                                    </div>
                                </form>
                                </div>
                              </div>
                          </div>
                      </div>
        </section>
                  

               
</div>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>