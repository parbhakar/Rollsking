<?php $this->load->view('site/components/header');?>


   <section class="float-left dashboard-100">
                <div class="dashboard-18">
                    <?php $this->load->view('site/components/sidebar'); ?>

                </div>
                <div class="dashboard-82">

                    <div class="change-password-style">
                        <h5 class="dashboard-head">Notification</h5>
<p style="text-align: center;"><?php echo @$this->session->userdata('message');$this->session->unset_userdata('message') ?></p>
               
<table class="table">
  <thead>
    <tr>
      <th>S.No</th>
      <th>Notification</th>
    </tr>
  </thead>
  <tbody>
    
    <?php if (!empty($notification)) { $i=0; foreach ($notification as $key => $value) { $i++; ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $value->notification; ?></td>
    </tr>
    <?php }}?>
    
  </tbody>

</table>
                    </div>

                </div>

            </section>
 <?php $this->load->view('site/components/footer');?>