<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <!--  <section class="content-header">
      <h1>
        All Products
        <small>Control panel</small>
      </h1>
      
    </section> -->

    <!-- Main content -->

 
    
 <section class="bg-grey product ptb-40">
                <div class="container addtocart_count ">
                     <div class="row">
          <div class="col-md-12">
              <h2 style="padding: 0px 13px;" class="main-title"> <?php 
               echo $cat_info->category_name; 
               ?></h2>
              <div class="borederrr"></div>
              <p class="bottom-border"></p>
          </div>
        </div>
        
                <?php
                
                $Submenu=$this->Site_Model->getParentIDcat($cat_info->category_id);  //print_r($Submenu);die; 
                   if(!empty($Submenu)){ ?>
                 
                      <?php foreach ($Submenu as $SubmL){ 
                        ?><a href="<?php echo base_url();?>category/<?php echo $SubmL->category_url; ?>" class="bg-red-btn out-stock"> <?php echo $SubmL->category_name; ?></a>
                      <?php } ?>
                   <?php } ?>
    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="product-slide-6 no-arrow slick-initialized slick-slider">
                            <?php
                              
                                foreach ($product_list as $key => $ae) { ?>
                                <div>
                                    <div class="col-md-3">
                                    <div class="product-box product-box-main addtocart">
                                        <div class="product-imgbox">
                                            <div class="product-front">
                                                <a href="javascript:;">
                                                    <?php if (!empty($ae->product_img)) { ?>
                                                      <img style="width: 235px;" src="<?php echo base_url('uploads/product/'); ?><?php echo $ae->product_img; ?>" class="img-fluid lazy" alt="<?php echo $ae->product_name; ?>">
                                                    <?php  } else { ?>
                                                        <img class="img-fluid lazy" src="<?php echo base_url(); ?>admin_assets/img/no-image-icon.png" alt="product">
                                                    <?php } ?>
                                                </a>
                                            </div>

                                            <div class="product-icon">
                                                
                                            </div>

                                        </div>
                                        <div class="product-detail detail-center1">
                                            <div class="product-box-main-details">   
                                            <h3><?php echo character_limiter($ae->product_name,20); ?> </h3>
                                           
                                                <?php if($ae->product_mrp > $ae->product_price ){ ?>
                                                 <?php   $percent = (($ae->product_mrp - $ae->product_price)*100) /$ae->product_mrp; ?> 
                                                  <span class="discount-style"><?php echo  number_format($percent, 2);?>% OFF </span>
                                                <?php } ?>
                                             
                                           
                                          <h5>MRP - <span class="text-cut">₹ <?php echo $ae->product_mrp; ?></span>
                                          <span class="detail-price">₹  <?php echo $ae->product_price; ?></span></h5>   
                                             </div>
                                              <div class="last-box-add">
                                               
                                                       <h5 class="quantity-style">Qty - <?php echo $ae->purchase_qty; ?></h5>
                                           
                                             
                                                        <form id="addtocartf<?php echo $ae->product_id; ?>" method="post" >
                                                 <input type="hidden" id="product_idf<?php echo $ae->product_id; ?>" name="product_id" value="<?php echo $ae->product_id; ?>">

                                                <input type="hidden" id="product_namef<?php echo $ae->product_id; ?>" name="product_name" value="<?php echo $ae->product_name; ?> <?php echo $ae->purchase_qty; ?>">
                                                <input type="hidden" id="product_pricef<?php echo $ae->product_id; ?>" name="product_price" value="<?php echo $ae->product_price; ?>">
                                                

                                                <?php if($ae->stock_status == 1 && $ae->product_qty >= 1){ ?>
                                                <input type="number" id="product_qty<?php echo $ae->product_id; ?>" name="product_qty" value="1">
                                                    <button class="bg-blue-btn addtocart-b" type="submit" name="submit" value="addtocart">Add <i class="fa fa-shopping-bag"></i> </button>
                                                <?php }else{ ?>
                                                    <a href="javascript:;" class="bg-red-btn out-stock"> Out of Stock</a>
                                                <?php } ?>
                                                        </form>
                                               
                                              </div>
                                                
                                             
                                        </div>
                                        
                                    </div>
                                    </div>
                                </div> 

                               

                                    <?php } ?>


                                      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                            <?php
                              // $Vegetabless=$this->Site_Model->getCategoryProductForcolumn(49); 
                               foreach ($product_list as $key => $ae) { 
                                ///echo $ae->product_id;die;
                                ?>
                            <script type="">
                            $('#addtocartf<?php echo $ae->product_id; ?>').on('submit', function(e)
                            {
                                  //alert('Hello');
                                    var product_id = $("#product_idf<?php echo $ae->product_id; ?>").val();
                                    var product_name = $("#product_namef<?php echo $ae->product_id; ?>").val();
                                    var product_price = $("#product_pricef<?php echo $ae->product_id; ?>").val();
                                    var quantity = $("#product_qty<?php echo $ae->product_id; ?>").val();
                                    //alert(product_id);

                                    
                                    $.ajax({
                                        url: "<?php echo base_url('Website/addtocartajax'); ?>",
                                        type: "post",
                                        data: {product_id : product_id, product_name : product_name , product_price : product_price , quantity : quantity},
                                        dataType: "json",
                                        //cache: false,
                                        success: function (json) {
                                            
                                            var message = json.message;
                                            console.log(message);
                                            //alert(json);
                                            $("#addtocartRef").load(location.href + " #addtocartRef");
                                            $("#addtocartRefdesk").load(location.href + " #addtocartRefdesk");
                                            
                                            $("#respons").html(json);
                                            var x = document.getElementById("snackbar");
                                            //alert(x);
                                            x.className = "show";
                                            setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
                                        }
                                    });
                                    e.preventDefault();
                                });
                            </script>

                            <?php  } ?>
                            </div>


                           
                            <!-- <div class="col-md-12 text-center">
                                <a style="background: #aaaa98;color: #000;box-shadow: 2px 3px 4px 1px #000;font-size: 17px;    text-transform: uppercase;" class="btn btn-product-style" href="<?php echo base_url('category/vegetables.html'); ?>">See More</a>
                            </div> -->
                        </div>
                        <?php echo $link;?>
                    </div>
                </div>
            </section>

    <!--End Product -->
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>

  