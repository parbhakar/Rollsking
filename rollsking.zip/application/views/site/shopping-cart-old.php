<?php $this->load->view('site/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('site/components/header.php'); ?>

  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('site/components/sidebar.php'); ?>
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <!--  <section class="content-header">
      <h1>
        All Products
        <small>Control panel</small>
      </h1>
      
    </section> -->

    <!-- Main content -->
 <style>
 	.shopping-cart .title li{
 		width: 13.5%;
 	}
 	.shopping-cart ul li{
 		width: 102px;
 	}
 	.alert-success {
    border-color: #008d4c;
    border: none;
}
 </style>
    
<section class="bg-grey product ptb-40 shoping_cart_page" style="height: 577px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
        		<div class="MESSAGE" style=" text-align: center; margin-bottom: 13px; width: 30%; z-index: 9999;">
  				 <p style="color: red; text-align: left;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-center' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
        	</div>
        	</div> 
        	<div class="col-md-8">
        	
           
			    <div class="shopping-cart">

			        <!-- New Shopping Cart -->
			 <?php
			 //echo "<pre>";
			 //print_r($this->cart->contents()); die();
			 if (count($this->cart->contents()) != 0) { ?>
			        <ul class="title title-desktop clearfix">
			            <li class="second">IMAGE</li>
			            <li>PRODUCT NAME</li>
			            <li>PRICE</li>
			            
			            <li>QUANTITY</li>
			            <li>GST Amount</li>
			           
			            <li class="last">TOTAL</li>
			             <li>ACTION</li>
			        </ul>



			 <?php $i = 1; 
                  $total=0; foreach ($this->cart->contents() as $key => $items): ?>
                    <form method="post" action="<?php echo base_url('update-cart.html'); ?>">
	                   <ul class="clearfix detail-1" id="">
	                    	<?php $getProduct=$this->Site_Model->getProductDataForCart($items['id']);//print_r($getProduct) ?>
	                        <li class="second">
	                            <span class="title-responsive">IMAGE</span>
	                            <a href="#">
	                            <?php if (!empty($getProduct->product_img)) { ?>
                                  <img style="width: 80px;height: 80px;margin-top: 0px; object-fit: cover;" src="<?php echo base_url('uploads/product/'); ?><?php echo $getProduct->product_img; ?>" alt="<?php echo $getProduct->product_img; ?>"   class="">
                                <?php  } else { ?>
                                    <img style="width: 100px;" src="<?php echo base_url(); ?>admin_assets/img/no-image-icon.png" class="lazy" src="<?php echo base_url();?>assets/loding.gif" alt="cart"  >
                                <?php } ?>

	                            </a>
	                        </li>
	                        
	                        <li>
	                            <span class="title-responsive">PRODUCT NAME</span>
	                            <a href="javascript:;">
	                               <p style="font-size: 14px;"> <?php echo $items['name']; ?></p>
	                           </a>
	                        </li>
                            <input type="hidden" name="product_id" value="<?php echo $items['id']; ?>">
                                                    
	                        <li>
	                            <span class="title-responsive">PRICE</span>
	                            <p>₹ <?php echo $this->cart->format_number($items['price'],2); ?></p>
	                       </li>
	                       
	                       
	                        <li>
	                        	<input type="hidden" name="rowid" value="<?php echo $items['rowid']; ?>">
	                            <span class="title-responsive">QUANTITY </span>
	                            <div class="qty-box">
	                                <div class="input-group">
	                                	 
	                                    <input type="number" style="margin-top: 0px;" name="quantity" class="form-control input-number" value="<?php echo $items['qty']; ?>" onchange="this.form.submit();">
	                                </div>
	                            </div>
	                        </li>
	                        <li>
	                            <span class="title-responsive">GST Amount</span>
	                            <a href="javascript:;">
	                            	<?php $productGSTAmt = ($getProduct->slab / 100) * $items['price']; ?>
	                               <?php  $totalGST=$productGSTAmt * $items['qty']; ?>
	                               <p>₹ <?php echo $this->cart->format_number($totalGST,2)?></p>
	                               
	                           </a>
	                        </li>

	                         <li>
	                            <span class="title-responsive">TOTAL</span>
	                            <p class="td-color">₹  <?php echo $this->cart->format_number($totalGST + $items['price'] * $items['qty'], 2); ?></p>
	                            <?php $total += $totalGST + $items['price'] * $items['qty'] ?>
	                       </li>
	                        
	                        <li>
	                            <span class="title-responsive">ACTION</span>
	                            <a href="<?php echo base_url(); ?>Website/deletecartItem/<?php echo $items['rowid']; ?>" class="icon text-danger"><i class="fa fa-trash delet"></i></a>
	                            <?php /*<button name="deletecartItem" value="<?php echo $items['rowid']; ?>"><i class="fas fa-trash-alt"></i></button> */?>
	                        </li>
	                       
	                       
	                    </ul>
	                </form>
          <?php $i++; ?>
<?php endforeach; ?>
</div>

           
        </div>
        <div class="col-md-4">
        <div class="cart-buttons">
        	

        	

        		 <div class="cart-total-style">

                                <h3>Shopping Cart</h3>
                                
                                <ul class="treatments checkout clearfix">

                                    <li>Total Amount to Pay : <strong class="price"> Rs. <?php echo $this->cart->format_number($total); ?>/-</strong></li>
                            </ul>
                   

        	
            <a href="<?php echo base_url(); ?>" class="btn btn-normal check-out">continue shopping</a> 
            	<?php if($this->session->userdata("isUserLogged_in")==1){ ?>
            		<a href="<?php echo base_url('checkout-billing.html'); ?>" class="btn btn-normal check___out">Proceed to Pay</a>
            	<?php }else{ ?>
            		<a href="<?php echo base_url('checkout-billing.html'); ?>" class="btn btn-normal logbtn">Login & Continue</a>
            	<?php } ?>
                </div>
        </div>
        <?php }else{ ?>
	<h3 class="text-center">Cart Empty</h3>
<?php } ?>
    </div>
</div>
</div>
</section>

<!--section end-->


<?php /*<script type="text/javascript">
    $(document).ready(function() {
        $('button[name="deletecartItem"]').on('click', function() {
           // alert('Check Value');
            var cart_id = $(this).val();
				$.ajax({
			            url: "<?php echo base_url(); ?>Website/deletecartItemajax",
			            type: "post",
			            data: {cart_id : cart_id},
			            dataType: "json",
			            cache: false,
			            success: function (json) {
			                var message = json.message;
			                console.log(message);
			                //alert(json);
			                $("#addtocartRef").load(location.href + " #addtocartRef");
			                $("#addtocartRefdesk").load(location.href + " #addtocartRefdesk");
			                
			                $("#respons").html(json);
			                var x = document.getElementById("snackbar");
			                x.className = "show";
			                setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
			            }
			        });
			        e.preventDefault();
        });
    });
</script> */?>
  <!-- /.content-wrapper -->
<?php $this->load->view('site/components/footer.php');?>
<?php $this->load->view('site/components/footer_js.php');?>