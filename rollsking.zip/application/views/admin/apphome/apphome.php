<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
   .content-wrapper {
    min-height: 10px !important;
}
  </style>
  <!-- ----------------------------Start Slider ---------------------------------->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Website & App Slider
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">  Website & App Slider</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
            <div class="col-lg-5 btn-class">
             Website & App Slider
            </div>
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
  <form name="optionForm" role="form" action="<?php echo base_url('Admin/homesubmit_image'); ?>" method="post" enctype="multipart/form-data" >
    <input type="hidden" name="image_section_type" value="1">
      <div class="col-md-12">
      <div class="form-group"><label>Select Images</label>
      <input  type="file" name="userfile[]" id="userfile"  multiple/>
      </div>
      </div>
      <div class="col-md-12">
      <div class="form-group"> 
      <input class="btn-success btn col-md-2" type="submit" name="submit" id="submit" value="Upload Images" />
      </div>
      </div>
      <div class="clear"></div>
      </form>                 </div>
                </div>

                </div>
               </div>


               <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
            <div class="col-lg-5 btn-class">
              Website & App Slider
            </div>
            <div class="col-lg-7">
             
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
             <?php
      $getPhoto = $this->Admin_Model->getSliderPhoto(1);
     
      $k=0;
      foreach($getPhoto as $photo){
    ?>
      <div class="col-md-2 bg-info" style="margin:15px;">
        <div class="form-group">
           <p>&nbsp;</p>
          <p><img src="<?php echo base_url("uploads/app_home")."/".$photo->image_name;?>" class="img-responsive" style="height:110px;"></p>
          
          
          <p><select class="form-control" id="formainslider" name="formainslider" required onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                    <?php 
                    $categoryList = $this->Admin_Model->getActiveCategoryForApp();
                    if(count($categoryList)>0) {?>
                      <option value="">Select Category</option>
                     <?php  foreach($categoryList as $category){ ?>
                    <option value="<?php echo base_url();?>Admin/updatedata/<?php echo $photo->image_id; ?>/<?php echo $category->category_id; ?>" <?php if($photo->image_link==$category->category_id) echo 'selected'; ?>><?php echo $category->category_name; ?></option> 
                    <?php } } ?>
              </select>
            </p>
          
          <p align="center"><a href="<?php echo base_url('Admin/appdelete_photo/'.$photo->image_id); ?>" title="Delete" class="btn btn-danger btn-block" onclick="return confirmDelete();"><i class="glyphicon glyphicon-trash icon-white"></i></a></p>
        </div>
      </div>  
    <?php
    $k++;
    if($k%5==0)
    {
      echo '</div><div class="row">';
    }
    
     
      }
    ?>  
                     </div>
                </div>






                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->

      </div><!-- /.content-wrapper -->


    </div><!-- ./wrapper -->
<!-- ----------------------------Slider End ---------------------------------->







<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>