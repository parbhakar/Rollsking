	<?php $this->load->view('admin/components/header_css.php'); ?>
	<div class="wrapper">

	  <?php $this->load->view('admin/components/header.php'); ?>
	  <!-- Left side column. contains the logo and sidebar -->
	  <?php $this->load->view('admin/components/sidebar.php'); ?>
	  <!-- Content Wrapper. Contains page content -->
	  <style type="text/css">
	    .dataTables_filter{
	      text-align: right;
	    }
	    .paging_simple_numbers {
	      text-align: right;
	    }
	    .Genrate_inv p:nth-child(1) {
		    font-size: 23px;
		    font-weight: 700;
		    letter-spacing: 6px;
		}
		.Genrate_inv p:nth-child(2) {
		    font-size: 17px;
		    font-weight: 600;
		    letter-spacing: 2px;
		    text-transform: uppercase;
		    color: #0400ff;
		}
	  </style>
	  <div class="content-wrapper">
	    <!-- Content Header (Page header) -->
	    <section class="content-header">
	      <h1>
	       Invoice Genrate  List
	        <small>Control panel</small>
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
	        <li class="active"> Invoice Genrate  List</li>
	      </ol>
	    </section>
	   
 		<section class="content">
 		 <div class="row">
         <div class="col-md-12">
         	<div id="listGroup" class="box box-info">
                <div class="box-header with-border">
                	  
                	  <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
				              <?php if ($ms){?>
				                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
				                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				                <i class="icon fa fa-check"></i><?php echo $ms ;?>
				                </div>
				              <?php }?>
				    <table  class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No</th>
        <th>Inv Type</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Month Order</th>
        <th>Bill Amount</th>
        <th>Parsentage</th>   
        <th>Date</th>       
        
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
  <?php
    $i = 1;
    $userList = $this->Admin_Model->genrate_list();	
    foreach($userList as $ae) { 
    	$i;
  ?>
    <tr>
        <td><?php echo $i++; ?></td>
        <td>
            <?php  $invName=$this->Admin_Model->getInvNameBydb($ae->inv_type)?>
            <?php echo $invName->inv_name; ?></td>
        <td><?php echo $ae->username; ?></td>
        <td><?php echo $ae->useremail; ?></td>
        <td><?php echo $ae->userphone; ?></td>
        <td><?php echo $ae->order_month_amount; ?>/-</td>
        <td><?php echo $ae->bill_amont; ?>/-</td>
        <td><?php echo $ae->persantage; ?>%</td> 
        <td><?php echo $ae->order_created;?></td>
        
        <td>
          <?php
        if($ae->status==1){
        ?>
       	
        <p><a href="<?php echo base_url('admin/Invoice_Genrate_status/'.$ae->inv_id.'/0/'); ?>"><span class="label label-danger">unpaid</span></a></p>
        <?php } else { ?>

        	 <p><a href="<?php echo base_url('admin/Invoice_Genrate_status/'.$ae->inv_id.'/1/'); ?>"><span class="label label-success">paid</span></a></p>
        <?php } ?>
        <a href="<?php echo base_url('Admin/invinfo')."/".str_replace('=','',base64_encode($ae->inv_id)); ?>">Invoice</a>
         
        </td>
    </tr>
  <?php  } ?>
    </tbody>
    </table>
      <?php echo @$links; ?>
                		</div>
	   
			  </div>
			 </div>
		 </div>
	 </section>
	 
	</div><!-- /.content-wrapper -->

	<?php $this->load->view('admin/components/footer'); ?>
	</div><!-- ./wrapper -->

	<?php $this->load->view('admin/components/footer.php'); ?>
	<?php $this->load->view('admin/components/footer_js.php'); ?>