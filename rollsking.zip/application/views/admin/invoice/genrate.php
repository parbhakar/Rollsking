	<?php $this->load->view('admin/components/header_css.php'); ?>
	<div class="wrapper">

	  <?php $this->load->view('admin/components/header.php'); ?>
	  <!-- Left side column. contains the logo and sidebar -->
	  <?php $this->load->view('admin/components/sidebar.php'); ?>
	  <!-- Content Wrapper. Contains page content -->
	  <style type="text/css">
	    .dataTables_filter{
	      text-align: right;
	    }
	    .paging_simple_numbers {
	      text-align: right;
	    }
	    .Genrate_inv p:nth-child(1) {
		    font-size: 23px;
		    font-weight: 700;
		    letter-spacing: 6px;
		}
		.Genrate_inv p:nth-child(2) {
		    font-size: 17px;
		    font-weight: 600;
		    letter-spacing: 2px;
		    text-transform: uppercase;
		    color: #0400ff;
		}
	  </style>
	  <div class="content-wrapper">
	    <!-- Content Header (Page header) -->
	    <section class="content-header">
	      <h1>
	       Invoice Genrate  List
	        <small>Control panel</small>
	      </h1>
	      <ol class="breadcrumb">
	        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
	        <li class="active"> Invoice Genrate  List</li>
	      </ol>
	    </section>
	   
 		<section class="content">
 		 <div class="row">
         <div class="col-md-12">
         	<div id="listGroup" class="box box-info">
                <div class="box-header with-border">
                	  
                	  <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
				              <?php if ($ms){?>
				                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
				                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				                <i class="icon fa fa-check"></i><?php echo $ms ;?>
				                </div>
				              <?php }?>
				    <div class="col-md-4 col-md-offset-4">
				    	<div class="Genrate_inv">
				    		<p class="text-center">This Month Order</p>
				    		<?php 
				    		$total=0;
				   		 $userid = $this->uri->segment(3);
					     $data  = $this->Admin_Model->getstart_date_anddate($userid);
					     //print_r($data); 
					     foreach($data as $ae){ 
					     $total+=$ae->order_amount;
					     } ?>
				    		
				    		<p class="text-center">Amount : <?php echo number_format($total, 2); ?></p>
				    	
				    		<form method="post" action="<?php echo base_url('Admin/genrate_inv_billamount');?>">
				    			<input type="hidden" value="<?php echo $userid;?>" name="order_userid">
				    			<input type="hidden" value="<?php echo $data[0]->order_firstname ;?>" name="order_firstname">
				    			<input type="hidden" value="<?php echo $data[0]->order_email ;?>" name="order_email">
				    			<input type="hidden" value="<?php echo $data[0]->order_phone ;?>" name="order_phone">
				    			<input type="hidden" value="<?php echo $data[0]->order_amount ;?>" name="order_amount">
				    			<input type="hidden" value="<?php echo $data[0]->order_created ;?>" name="order_created">
                                
                                <p class="text-center">
                                    <select name="inv_type" class="form-control" required>
                                        <option value="">Select Invoice Type</option>
                                        <?php $invtypes=$this->Admin_Model->getInvtypes(); ?>
                                        <?php foreach($invtypes as $typs){ ?>
                                            <option value="<?php echo $typs->id; ?>"><?php echo $typs->inv_name; ?></option>
                                        <?php } ?>
                                    </select>
                                </p>

				    			<p class="text-center"><input class="form-control" type="number" name="billamount" required value=""></p>
				    			
				    			<?php if(empty($ae->order_amount)){ ?>
				    				<p class="text-center"><input class="form-control" disabled type="submit" value="Genrate inv" name=""></p>
				    			 <?php }else{  ?> 
								<p class="text-center"><input class="form-control" type="submit" value="Genrate inv" name=""></p>
				    			 <?php } ?>
				    			
				    			<!--<p class="text-center"><input class="form-control" type="submit" value="Genrate inv" name=""></p>-->
				    		</form>
				    	
				    	</div>
				    	
				    </div>
                </div>
	   
			  </div>
			 </div>
		 </div>
	 </section>
	 
	</div><!-- /.content-wrapper -->

	
	</div><!-- ./wrapper -->

	<?php $this->load->view('admin/components/footer.php'); ?>
	<?php $this->load->view('admin/components/footer_js.php'); ?>