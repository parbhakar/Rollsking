<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Order Item List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Order Item List</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-5 btn-class">
              Order Item
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                       <table class="table table-striped table-bordered bootstrap-datatable responsive datatable">
                            <thead class="th-hidden">
                            <tr>
                                <th>Sr.No</th>
                                <th>Order ID</th>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Product Code</th>
                                <th>Product Price</th>
                                <th>Product Qty</th>
                                <th>Subtotal</th>
                            </tr>
                            </thead>
                            <tbody class="table-inner-table">
                
                            <?php
                            $totalqty=0;
                            $totalprice=0;
                             $k=0; if (!empty($orderSersvice)): foreach ($orderSersvice as $service): $k++;?>
                              <tr>
                                <td> <?php echo $k; ?></td>
                                <td><?php $orderuniqueid=$this->Admin_Model->getorder_unique_code($service->order_id); echo $orderuniqueid->order_unique_code;?></td>



                                <td><?php $productimg= $this->Admin_Model->GetProductImages($service->product_id); ?>
                                    
                                    <img src="<?php echo base_url(); ?>uploads/product/<?php echo $productimg->product_img; ?>" style="width: 45px;" alt="<?php echo $productimg->product_img; ?>">
            
                                </td>
                                <td><?php echo $service->name; ?></td>
                                <td><?php echo $service->code; ?></td>
                                <td>Rs.<?php echo $service->one_price; ?>/-</td>
                                <td><?php echo $service->qty; $totalqty+=$service->qty;  ?></td>
                                <td>Rs.<?php echo $service->price; ?>/-   <?php  $totalprice+=$service->price; ?>
                                </td>
                              </tr>
                          <?php endforeach; ?>
                          <tr>
                                <td colspan="5"></td>
                               
                    
                                <td><b>Total Qty</b></td>
                                <td><?php echo $totalqty; ?></td>
                                <td>Rs.<?php echo $totalprice; ?>/-</td>
                              </tr>
                          <?php endif; ?>

                            </tbody>
                          </table>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->

    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>