<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Order Item List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Order Item List</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-5 btn-class">
              Order Item
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                       <table class="table table-striped table-bordered bootstrap-datatable responsive datatable">
                            <thead class="th-hidden">
                            <tr>
                                <th>Sr.No</th>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Product Code</th>
                                <th>Product Price</th>
                                <th>Qty</th>
                                <th>Qty Price</th>
                                <th>Purchase Price</th>
                                 <th>Purchase Price By Qty</th>
                                
                                 <th>Profit</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody class="table-inner-table">
                           
                            <?php $k=0; if (!empty($orderSersvice)): foreach ($orderSersvice as $service): $k++;?>
                              <tr>
                                <td> <?php echo $k; ?></td>
                                <td><?php $productimg = $this->Admin_Model->GetProductImages($service->product_id); ?>
                                    <img src="<?php echo base_url(); ?>uploads/product/<?php echo $productimg->product_img; ?>" style="width: 45px;" alt="<?php echo $productimg->product_img; ?>">
                                </td>
                                <td><?php echo $service->name; ?></td>
                                <td><?php echo $service->code; ?></td>
                                <td>Rs.<?php echo $service->one_price; ?>/-</td>
                                <?php $qtyprint=$this->Admin_Model->getOrderQtysearch($_GET['search-date-from'],$_GET['search-date-to'],$service->product_id);

                                //print_r($qtyprint); die();
                                 ?>
                                <td><?php 
                                $totalqty=0;
                                foreach ($qtyprint as $key => $qty) {
                                 $totalqty+=$qty->qty;
                                }
                                echo $totalqty;

                                 ?></td>
                                 <th>
                                   <?php 
                                $totalprice=0;
                                foreach ($qtyprint as $key => $prices) {
                                 $totalprice+=$prices->price;
                                }
                                echo "Rs.".$totalprice."/-";
                                 ?>
                                 </th>
                                 <td>


                                <?php 
                                   $productpurchaseprice=$qtyprint[0]->product_purchase_price;
                                   echo "Rs.".$productpurchaseprice."/-";
                                 ?>
                                 </td>



                                 <td>
                                   <?php 
                                
                                echo "Rs.".$finalPurchase=$productpurchaseprice * $totalqty."/-";
                                 ?>
                                 </td>
                               
                                <td>Rs.<?php echo $totalprice - $finalPurchase; ?>/-</td>
                                <td>
                                  <form method="get" action="<?php echo base_url(); ?>Admin/orderedproduct">
                                    <input type="hidden" name="product_id" value="<?php echo $service->product_id; ?>">
                                    <input type="hidden" name="search-date-from" value="<?php echo $_GET['search-date-from']; ?>">
                                    <input type="hidden" name="search-date-to" value="<?php echo $_GET['search-date-to']; ?>">
                                    <button class="label-success label label-default">View</button>
                                  </form>
                                </td>
                                </td>
                              </tr>
                          <?php endforeach; ?>
                          <?php endif; ?>
                            </tbody>
                          </table>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->

    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>