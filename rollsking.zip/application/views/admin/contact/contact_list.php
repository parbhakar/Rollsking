<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Contact Query List Management
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Contact Query</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content" style="margin-bottom: 30px;">
       <div class="box">
             <div class="box-header with-border">
            <div class="col-lg-5">
              <h3 class="box-title">Get In Touch Message List</h3>
            </div>
            <!-- <div class="col-lg-5 btn-class">
              <a href="<?php echo base_url(); ?>admin/Category/add_category" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Category</a>&nbsp;
              <a href="<?php echo base_url(); ?>admin/Category" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list"></span> Category List</a>&nbsp;
            </div> -->
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message') ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px; color: #fff !important; ">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No.</th>
        <th>Name</th>
        <th>Contact</th>
        <th>Message</th>
        <th>Created Date</th>
        <th>Action</th>
       
    </tr>
    </thead>
    <tbody>
  <?php
   $count=0;
  if(count($allContactQuery)>0)
  {
    foreach($allContactQuery as $ae) {
      $count++;
  ?>
    <tr>

        <td><?php echo $count; ?></td>
        <td><?php echo $ae->contact_name; ?></td>
        <td class="center">
      <p><?php echo $ae->contact_email; ?></p>
      <p><?php echo $ae->contact_phone; ?></p>
    </td>
        <td class="center"><?php echo $ae->contact_message; ?></td>
        <td class="center"><?php echo date("Y-m-d h:i A",strtotime($ae->contact_created)); ?></td>
    <td class="center">
    <p><a href="<?php echo base_url('Admin/deleteQuery/'.$ae->contact_id.'/'); ?>" Onclick="return ConfirmDelete()"><span class="btn btn-danger"><i class="glyphicon glyphicon-trash icon-white"></i></span></a></p>
    <?php
    /*
    <p>
      <form name="storyview" action="<?php echo base_url('Admin/remarkList'); ?>" method="post">
        <input type="hidden" name="collectionId" value="<?php echo $ae->contact_id; ?>">
        <button class="btn btn-info">
          <i class="glyphicon glyphicon-edit icon-white"></i>
          Remark
        </button>
      </form>
    </p>
    */ ?>
    </td>
 
    </tr>
  <?php } } ?>
    </tbody>
    </table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
      <!-- /.row (main row) -->
    </section>
    <!-- /.content -->
  </div>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>