<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Order List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Order List</li>
      </ol>
    </section>




    <div class="row">

   <div class="col-md-5">
    <?php /*  <form method="post" action="<?php echo base_url(); ?>Admin/orderExport">
         <div class="col-md-5">
            <div class="form-group">
              <div class="form-group"><label> Export Order From Date</label>
              <input autocomplete="off" type="text" name="search-date-from" id="datetimepicker2" class="form-control">
            </div>
            </div>
            <?php echo form_error("search-date-from");?>
          </div>
           <div class="col-md-5">
            <div class="form-group">
              <div class="form-group"><label> Export Order To Date</label>
              <input autocomplete="off" type="text" name="search-date-to" id="datetimepicker3" class="form-control">
            </div>
            </div>
            <?php echo form_error("search-date-to");?>
          </div>

                    <div class="col-md-2" style="margin-top: 5px;">
                        <div class="form-group">
                            <div class="form-group"><label></label>
                            <input type="submit" name="submit" class="btn btn-success" value="Export">
                        </div>
                        </div>
                    </div>
    </form> */?>
    <form method="get" action="<?php echo base_url(); ?>Admin/searchOrderItemBydate">
         <div class="col-md-4">
            <div class="form-group">
              <div class="form-group"><label> Product From</label>
              <input autocomplete="off" type="text" name="search-date-from" id="datetimepicker2" class="form-control">
            </div>
            </div>
            <?php echo form_error("search-date-from");?>
          </div>
         
         <div class="col-md-4">
            <div class="form-group">
              <div class="form-group"><label> Product To</label>
              <input autocomplete="off" type="text" name="search-date-to" id="datetimepicker3" class="form-control">
            </div>
            </div>
            <?php echo form_error("search-date-from");?>
          </div>
         

                    <div class="col-md-2" style="margin-top: 5px;">
                        <div class="form-group">
                            <div class="form-group"><label></label>
                            <input type="submit" name="submit" class="btn btn-success" value="Search">
                        </div>
                        </div>
                    </div>
                    <div class="col-md-2" style="margin-top: 5px;">
                        <div class="form-group">
                            <div class="form-group"><label></label>
                            <input type="submit" name="submit" class="btn btn-success" value="Export">
                        </div>
                        </div>
                    </div>
    </form>
    </div>
    <form method="get" action="<?php echo base_url('Admin/orderlist');?>">
      <div class="col-md-7">
        <div class="col-md-2">
          <div class="form-group">
              <div class="form-group"><label>From Date</label>
              <?php $fromdate=$this->input->get("fromdate");?>
          <input type="text" autocomplete="off" value="<?php echo $fromdate; ?>" name="fromdate" placeholder="From Date" id="datetimepicker4" class="form-control">
            </div>
            </div>
        </div>  

        <div class="col-md-2">
          <div class="form-group">
              <div class="form-group"><label> To Date</label>
               <?php $todate=$this->input->get("todate");?>
          <input type="text" autocomplete="off" value="<?php echo $todate; ?>" name="todate" placeholder="To Date" id="datetimepicker5" class="form-control">
            </div>
            </div>
       
        </div>


        <div class="col-md-2">
          <div class="form-group"><label> Paid UnPaid</label>
            <?php $paid_unpaid=$this->input->get("paid_unpaid");?>
         <select name="paid_unpaid" class="form-control">
           <option value="" <?php if ($paid_unpaid == null): echo "selected"; ?><?php endif ?>>Select Payment </option>

           <option value="0" <?php if ($paid_unpaid == 0): echo "selected"; ?><?php endif ?>>Pending</option>
           <option value="1"  <?php if ($paid_unpaid == 1): echo "selected"; ?><?php endif ?>>Paid</option>
         </select>
            </div>
        </div>
        
        
      
   <div class="col-md-2">
          <div class="form-group"><label> Select Vendor</label>
          <?php $sales=$this->input->get("sales");?>
         <select name="sales" class="form-control">
            <option value="">Select Vendor </option>
            <?php foreach($employee_list as $list){ ?>
             <option value="<?php echo $list->id; ?>"  <?php if($list->id == $sales){echo "selected";}else{} ?>><?php echo $list->first_name; ?></option>
            <?php }?>
         </select>
            </div>
        </div>
     
      <div class="col-md-2" style="margin-top: 23px;">
        <input type="submit" value="Search" name="submit" title="submit" style="margin-right: 10px;"  class="btn btn-success">
      </div>
       </div>
</form>
    </div>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
                    
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
            <div class="col-lg-5 btn-class">
                Order List
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            
            </div>
                   <div class="box-body">
                    <div class="col-md-12">
          <div class="col-md-5">
            <?php echo $links; ?>
            </div>
   <div class="col-md-7" style="margin: 20px 0px 20px 0px;">
      <form method="GET" action="<?php echo base_url('Admin/orderlist'); ?>">
          <div class="col-md-3 mtassing">
          <input type="text" name="orderid" class="form-control" id="orderid" data-live-search="true" placeholder="Search by Order ID" value="<?php echo @$_GET['orderid']; ?>"> 
        </div> 
        <div class="col-md-3 mtassing">
          <input type="text" name="name" class="form-control" id="name" data-live-search="true" placeholder="Search by User Name" value="<?php echo @$_GET['name']; ?>"> 
        </div> 
        <div class="col-md-3 mtassing">
         <input type="text" name="mobile" class="form-control" id="mobile" data-live-search="true" placeholder="Search by Mobile Number" value="<?php echo @$_GET['mobile']; ?>">
        </div>
 
        <div class="col-md-3 mtassing">
          <input type="submit" value="Search" name="submit" title="Search" style="margin-right: 10px;" class="btn btn-success">
        		
		 </div>
      </form>
    </div>
              <?php if (empty($orderData)) {?>
      <h4>Order Data Not Available</h4>
  <?php  }else{ ?>
    <table  class="table table-striped table-bordered bootstrap-datatable responsive datatable">
                    <thead>
                    <tr>
                        <th>Sr.No</th>
                        <th>Order ID</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Amount</th>
                        <th>Date</th>
                        
                        <!-- <th>Payment Type</th> -->
                        <th>Payment</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                   
                      <tbody>
                        <?php
                         if($this->uri->segment('3')==null)
                          {
                              $kk=0;
                          }else{
                              $kk=$this->uri->segment('3');
                          }
                          
                        if (!empty($orderData)) : $k=$kk; foreach($orderData as $order): $k++;?>
                        <tr>
                          
                          <td><?php echo $k; ?></td>
                          <td><?php echo $order->order_unique_code; ?></td>
                          <td><b>Name :</b> <?php echo $order->order_firstname; ?><br>
                          <b>Address :</b> <?php echo $order->order_address; ?><br>
                          <b>Pincode :</b> <?php echo $order->order_zipcode; ?><br>
                          <b>From :</b> <?php echo $order->order_from; ?></td>
                          <td><?php echo $order->order_phone; ?></td>
                          <td>Rs.<?php echo $order->order_amount; ?>/-</td>
                          <td>
                            <b>Order Date : -</b> <?php echo $order->order_created; ?><br>
                           
                          </td>
                         
                          
                          <!-- <td>
                            <?php  if($order->payment_type==1){?>
                            <span class="label-success label label-default" style="background-color: #009813; padding: 1px 9px;">Cash</span> 
                            <?php } else if($order->payment_type==2) { ?>  
                            <span class="label-default label label-success" style="background-color: #980000; padding: 1px 9px;">Online</span>
                            <?php }else{
                             //echo "Not Payment Type";
                            } ?>
                          </td> -->
                          <td>
                            <?php if($order->order_payment_status==1){?>
                            <a href="<?php echo base_url('Admin/subPaidOrder/'.$order->order_id.'/0'); ?>" onclick="return confirm('Do you really want to UnPaid this Order ?')"><span class="label-success label label-default">Paid</span></a>
                            <?php } else if($order->order_payment_status==0) { ?>  
                            <a href="<?php echo base_url('Admin/subPaidOrder/'.$order->order_id.'/1'); ?>" onclick="return confirm('Do you really want to Paid this Order ?')"><span class="label label-danger">Not Paid</span></a>
                            <?php }else{echo "";} ?>
                          </td>

                          <td>
                            <a target="_blank" href="<?php echo base_url(); ?>Admin/subviewOrderItem/<?php echo $order->order_id; ?>" class="btn btn-primary btn-xs">Booked Item</a> <br>
                            
                            <a target="_blank" href="<?php echo base_url('Admin/suborderinfo')."/".str_replace('=','',base64_encode($order->order_id)); ?>" class="btn btn-success btn-xs">Invoice</a> 
                            
                           <br>


                            <?php  if ($order->order_status == 0) { ?>

                             <a href="" ><span class="btn btn-primary btn-xs" style="background-color: #f10808 !important;  color: #fff;">Canceled By User</span></a>

                           <?php } elseif ($order->order_status == 1) { ?>

                            <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/2/'); ?>" onclick="return confirm('Do you really want to Order Packed ?')"><span class="btn btn btn-warning btn-xs" style="color: #fff;">Order Packed</span></a>
                  
                              <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/6/'); ?>" onclick="return confirm('Do you really want to cancel this order ?')"><span class="btn btn-primary btn-xs" style="background-color: #1e686c !important;  color: #fff;">Cancel Order</span></a>
                           <?php }elseif ($order->order_status == 2) { ?>
                            
                            <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/3/'); ?>" onclick="return confirm('Do you really want to Order Shipped ?')"><span class="btn btn btn-warning btn-xs" style="color: #fff;">Order Shipped</span></a>

                              <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/6/'); ?>" onclick="return confirm('Do you really want to cancel this order ?')"><span class="btn btn-primary btn-xs" style="background-color: #1e686c !important;  color: #fff;">Cancel Order</span></a>
                           <?php }elseif ($order->order_status == 3) { ?>

                              <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/4/'); ?>" onclick="return confirm('Do you really want to order Delivered ?')"><span class="btn btn-warning btn-xs" style="color: #fff;">Order Delivered</span></a>

                              <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/6/'); ?>" onclick="return confirm('Do you really want to cancel this order ?')"><span class="btn btn-primary btn-xs" style="background-color: #1e686c !important;  color: #fff;">Cancel Order</span></a>

                           <?php }elseif ($order->order_status == 4) { ?>
                              <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/5/'); ?>" onclick="return confirm('Check the payment status of the order and then confirm it. If the order is paid then OK if not so cancel!!')"><span class="btn btn btn-warning btn-xs" style="color: #fff;">Final Delivered</span></a>
                            <?php }elseif ($order->order_status == 5) { ?>

                              <a href="<?php echo base_url('Admin/subcancleOrder/'.$order->order_id.'/5/'); ?>" onclick="return confirm('Do you really want to order Onway ?')"><span class="btn btn btn-warning btn-xs" style="color: #fff;">Order Done</span></a>

                            <?php }elseif ($order->order_status == 6) {  ?>
                              
                              <a href="" onclick="return confirm('This Order Canceled By Admin')"><span class="btn btn-primary btn-xs" style="background-color: #f10808 !important;  color: #fff;">Canceled By Admin</span></a>
                            <?php } ?>

                          </td>
                        </tr>
                      <?php endforeach;?>
                    <?php endif; ?>
                      </tbody>
        </table>

      <?php } ?>
      <?php echo $links; ?>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.css" />
<link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" />
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.js"></script>

<script>
function ConfirmDelete()
{
  var conf = confirm("Do you really want to delete this Order ?");
  if(conf==true)
  {
    return true;
  }
  else{
    return false;
  }
}
</script>

<script>
function ConfirmOrderDone()
{
  var confDel = confirm("Do You Really want to Done this Order?");
  
  if(confDel==1) { return true; } else { return false; }
   
}

function ConfirmSerDone()
{
  var confDel = confirm("Do You Really want to Done this Service?");
  
  if(confDel==1) { return true; } else { return false; }
   
}
</script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/calendar/jquery.datetimepicker.css"/>
<script src="<?php echo base_url();?>assets/calendar/jquery.js"></script>
<script src="<?php echo base_url();?>assets/calendar/jquery.datetimepicker.full.js"></script>
<script>
    // $('#datetimepicker2').datetimepicker({
    // format:'Y-m-d h:i:s',  
    // //  format:'d/m/Y H:i', 
    //   // minTime: '0:00',
    //   // maxTime: '24:00',
    // });


$('#datetimepicker3').datetimepicker({
      format:'Y-m-d',  
      timepicker:false
    });
    $('#datetimepicker4').datetimepicker({
      format:'Y-m-d',  
      timepicker:false
    });

</script>




<script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>
<script>
    $('#datetimepicker2').datetimepicker({
      timepicker:false,
      format:'Y-m-d'
    });
    $('#datetimepicker3').datetimepicker({
      timepicker:false,
      format:'Y-m-d'
    });
     $('#datetimepicker5').datetimepicker({
      timepicker:false,
      format:'Y-m-d'
    });
</script>
<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>