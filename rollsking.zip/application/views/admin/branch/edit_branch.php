<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Add Branch
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Add Branch</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-4 btn-class">
              <a href="<?php echo base_url(); ?>Admin/addbranch" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Branch </a>&nbsp;
              <a href="<?php echo base_url(); ?>Admin/branchList" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list"></span> Branch List</a>&nbsp;
            </div>
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
            <?php  echo form_open('Admin/updatebranch', array('method'=>'post','role'=>'form')); ?>
                <input type="hidden" name="bra_id" value="<?php echo $bra_info->bra_id; ?>">
            <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Company Name</label>
                               <select name="bra_company_id" class="form-control">
                                <option value="">Select Company</option>
                                <?php if (!empty($companyList)) {
                                        foreach ($companyList as $ae) {?>
                                <option value="<?php echo $ae->company_id; ?>" <?php if($ae->company_id==$bra_info->bra_company_id) echo "selected" ?>><?php echo $ae->company_name;?></option>
                                <?php }} ?>
                                </select>


              </div>
              <?php echo form_error("bra_company_id"); ?>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Branch Name</label>
                                <input type="text" class="form-control" id="bra_name" placeholder="Enter Branch Name" name="bra_name" value="<?php echo $bra_info->bra_name; ?>">
                            </div>
                            <?php echo form_error("bra_name"); ?>
                        </div>
            <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> Branch Address</label>
                                <input type="text" class="form-control" onFocus="initializeAutocomplete()" id="locality"  placeholder="Enter Branch Address" name="bra_address" value="<?php echo $bra_info->bra_address; ?>">
                            </div>
                                <?php echo form_error("bra_address"); ?>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                 <label for="exampleInputEmail1">Branch State</label>
                                <select name="company_state" id="company_state" onChange="getstatedetails(this.value)" class="form-control">
                                <option value="">Select State</option>
                                <?php if (!empty($stateList)) {
                                        foreach ($stateList as $ae) {?>
                                <option value="<?php echo $ae->state_id; ?>" <?php if($ae->state_id==$bra_info->bra_state) echo "selected" ?>><?php echo $ae->state_name;?></option>
                                <?php }} ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Branch City</label>
                                <select class="form-control" name="company_city" id="company_city">
                                    <option value="">Select City</option>
                                </select>
                            </div>
                            <?php echo form_error("company_city"); ?>
                        </div> 
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> Branch Zip Code</label>
                                <input type="text" class="form-control" id="bra_zip" placeholder="Enter Branch Address" name="bra_zip" value="<?php echo $bra_info->bra_zip; ?>">
                            </div>
                            <?php echo form_error("bra_lat"); ?>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> Branch Latitude</label>
                                <input type="text" class="form-control" id="latitude" placeholder="Enter Branch latitude" name="bra_lat" value="<?php echo $bra_info->bra_lat; ?>">
                            </div>
                                <?php echo form_error("bra_lat"); ?>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> Branch Longitude</label>
                                <input type="text" class="form-control" id="longitude" placeholder="Enter Branch longitude" name="bra_long" value="<?php echo $bra_info->bra_long; ?>">
                            </div>
                            <?php echo form_error("bra_long"); ?>
                        </div>
                        
           <div class="col-md-12">
            <div class="form-group">
              <button type="submit" class="btn btn-info">Update Branch</button>
            </div>
                    </div>
                 <?php  echo form_close(); ?>
               
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.css" />
<link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" />
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.js"></script>


<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyA5H3QyDBKmq8guZphzXJP_33eh5aA94wA&sensor=false&libraries=places"></script>

<input type="hidden" name="city" id="city" placeholder="City" value="" ><br>
<input type="hidden" name="place_id" id="location_id" placeholder="Location Ids" value="" ><br>


<script type="text/javascript">
function onLoadGetCity() {
  var state_id="<?php echo $bra_info->bra_state; ?>";
  //alert('Check Value');
      if(state_id) {
          //alert('Check Value');
          $.ajax({
              url: '<?php echo base_url(); ?>Admin/getCityForAjax/'+state_id,
              type: "POST",
              dataType: "json",
              success:function(data) {
                  $('select[name="company_city"]').empty();
                  $.each(data, function(key, value) {
                      $('select[name="company_city"]').append('<option ' + (value.city_id === '<?php echo $bra_info->bra_city;?>' ? 'selected' : '') + ' value="'+ value.city_id +'">'+ value.city_name +'</option>');
                  });
              }
          });
      }else{
          $('select[name="company_city"]').empty();
      }
    }
</script>





<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyA5H3QyDBKmq8guZphzXJP_33eh5aA94wA&sensor=false&libraries=places"></script>

<input type="hidden" name="city" id="city" placeholder="City" value="" ><br>
<input type="hidden" name="place_id" id="location_id" placeholder="Location Ids" value="" ><br>

<script type="text/javascript">
  function initializeAutocomplete(){
    var input = document.getElementById('locality');
    // var options = {
    //   types: ['(regions)'],
    //   componentRestrictions: {country: "IN"}
    // };
    var options = {}

    var autocomplete = new google.maps.places.Autocomplete(input, options);

    google.maps.event.addListener(autocomplete, 'place_changed', function() {
      var place = autocomplete.getPlace();
      var lat = place.geometry.location.lat();
      var lng = place.geometry.location.lng();
      var placeId = place.place_id;
      // to set city name, using the locality param
      var componentForm = {
        locality: 'short_name',
      };
      for (var i = 0; i < place.address_components.length; i++) {
        var addressType = place.address_components[i].types[0];
        if (componentForm[addressType]) {
          var val = place.address_components[i][componentForm[addressType]];
          document.getElementById("city").value = val;
        }
      }
      document.getElementById("latitude").value = lat;
      document.getElementById("longitude").value = lng;
      document.getElementById("location_id").value = placeId;
    });
  }
</script>

<script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>