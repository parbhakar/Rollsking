<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Branch List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Branch List</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-4 btn-class">
              <a href="<?php echo base_url(); ?>Admin/addbranch" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Branch </a>&nbsp;
              <a href="<?php echo base_url(); ?>Admin/branchList" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list"></span> Branch List</a>&nbsp;
            </div>
             <?php  echo form_open_multipart('Admin/branchList', array('method'=>'get','role'=>'form')); ?>
    <div class="col-md-4">
       
        <div class="form-group">
            <select name="companyid" class="form-control">
            <option value="">Select Company</option>
            <?php if (!empty($companyList)) {
                foreach ($companyList as $ae) {?>
            <option value="<?php echo $ae->company_id; ?>" <?php if($ae->company_id==$this->input->get('companyid')) echo "selected"; ?>><?php echo $ae->company_name;?></option>
            <?php }} ?>
            </select>
        </div>
    </div>
    <div class="col-md-2">
        <div>
            <input type="submit" class="btn btn-success" name="submit" value="Search">
        </div>
    </div>
    <?php  echo form_close(); ?>
            <div class="col-lg-5">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
          <table id="example" class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No.</th>
        <th>Company Name</th>
        <th>Branch Name</th>
        <th>Address</th>
        <th>Status</th>
        <th>Action</th>
       
    </tr>
    </thead>
    <tbody>
  <?php
   $count=0;
  if(count($branchList)>0)
  {
    foreach($branchList as $ae) {
      $count++;
  ?>
    <tr>
        <td><?php echo $count; ?></td>
        <?php $companyData=$this->Admin_Model->getCompanyDataForlab($ae->bra_company_id) ?>
        <td><?php echo $companyData->company_name; ?></td>
        <td><?php echo $ae->bra_name; ?></td>
        <td>
            <b>Address :</b><?php echo $ae->bra_address; ?><br>
            <b>State : </b><?php  $stateName=$this->Admin_Model->getStateName($ae->bra_state); 
            echo $stateName->state_name;?><br>
            <b>City : </b><?php  $cityName=$this->Admin_Model->getCityName($ae->bra_city); 
            echo $cityName->city_name;?><br>
            <b>Zip Code : </b><?php  echo $ae->bra_zip; ?><br>
            <b>Latitude :</b><?php echo $ae->bra_lat; ?><br>
            <b>Longitude : </b><?php echo $ae->bra_long; ?>
        </td>

    <td class="center">
    <?php
      if($ae->bra_status==1){
    ?>
    <p><a href="<?php echo base_url('Admin/branchStatus/'.$ae->bra_id.'/0/'); ?>"><span class="label label-success">Active</span></a></p>
    <?php } else { ?>
    <p><a href="<?php echo base_url('Admin/branchStatus/'.$ae->bra_id.'/1/'); ?>"><span class="label label-danger">Inactive</span></a></p>
    <?php } ?>
    
  
    </td>
    <td>  
      <p><a href="<?php echo base_url('Admin/branchDelete/'.$ae->bra_id.'/3/'); ?>" Onclick="return ConfirmDelete()"><span class="btn btn-danger"><i class="glyphicon glyphicon-trash icon-white"></i></span></a></p>
      <p><a href="<?php echo base_url('Admin/editbranch/'.$ae->bra_id.'/'); ?>" ><span class="btn btn-info"><i class="glyphicon glyphicon-edit icon-white"></i></span></a></p>
      
    </td>
 
    </tr>
  <?php } } ?>
    </tbody>
    </table>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.css" />
<link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" />
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.js"></script>

    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>
<script>
function ConfirmDelete()
{
  var conf = confirm("Do you really want to delete this Lab? if you Delete Lab So Delete all Test Automatically");
  if(conf==true)
  {
    return true;
  }
  else{
    return false;
  }
}
</script>
<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>