<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Labs List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Labs List</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-5 btn-class">
              <a href="<?php echo base_url(); ?>Admin/addCompany" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Company </a>&nbsp;
              <a href="<?php echo base_url(); ?>Admin/companyList" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list"></span> Company List</a>&nbsp;
            </div>
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
         <table id="example" class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No.</th>
        <th>Company Name</th>
        <th>Company Information.</th>
        <th>Address</th>
        <th>Logo</th>
        <th>Status</th>
        <th>Action</th>
       
    </tr>
    </thead>
    <tbody>
  <?php
   $count=0;
  if(count($allElement)>0)
  {
    foreach($allElement as $ae) {
      $count++;
  ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><?php echo $ae->company_name; ?></td>
        <td><b>CIN No. :</b> <?php echo $ae->company_cin; ?><br>
            <b>GST No. : </b><?php echo $ae->company_gst_no; ?><br>
            <b>Registration No. : </b><?php echo $ae->company_regis_no; ?><br>
            <b>Phone No. : </b><?php echo $ae->company_phone; ?><br>
            <b>Email ID : </b><?php echo $ae->company_email; ?>
        </td>
        <td>
            <b>Address : </b><?php echo $ae->company_address; ?><br>
            <b>State : </b><?php   
            echo $ae->company_name;?><br>
            <b>City : </b><?php   
            echo $ae->company_name;?><br>
            <b>Zip Code : </b><?php  echo $ae->company_zip; ?><br>
        </td>
        <td><img style="width: 100px;" src="<?= base_url();?>uploads/company_logo/<?= $ae->company_logo; ?>"></td>
        
    <td class="center">
    <?php
    if($ae->company_status==1){
    ?>
    <p><a href="<?php echo base_url('Admin/companyStatus/'.$ae->company_id.'/0/'); ?>"><span class="label label-success">Active</span></a></p>
    <?php } else { ?>
    <p><a href="<?php echo base_url('Admin/companyStatus/'.$ae->company_id.'/1/'); ?>"><span class="label label-danger">Inactive</span></a></p>
    <?php } ?>
    
  
    </td>
    <td>  
      <p><a href="<?php echo base_url('Admin/companyDelete/'.$ae->company_id.'/3/'); ?>" Onclick="return ConfirmDelete()"><span class="btn btn-danger"><i class="glyphicon glyphicon-trash icon-white"></i></span></a></p>
      <p><a href="<?php echo base_url('Admin/eidtCompany/'.$ae->company_id.'/'); ?>" ><span class="btn btn-info"><i class="glyphicon glyphicon-edit icon-white"></i></span></a></p>
    </td>
 
    </tr>
  <?php } } ?>
    </tbody>
    </table>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.css" />
<link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" />
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.js"></script>

    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>
<script>
function ConfirmDelete()
{
  var conf = confirm("Do you really want to delete this Company ? if you Delete Company So Delete all Labs and Test Automatically");
  if(conf==true)
  {
    return true;
  }
  else{
    return false;
  }
}
</script>
<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>