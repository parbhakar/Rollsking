<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Brand List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Brand List</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
              <div class="col-lg-4 btn-class">
               <a href="javascript:;" data-toggle="modal" data-target="#addbrandmodel" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Brand </a>
            </div>
            
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>

			<div class="box-body">
			<div class="col-md-12">
	   <table id="example1" class="table table-striped table-bordered bootstrap-datatable responsive datatable">
	    <thead>
	    <tr>
	        <th>S.No</th>
	        <th>Brand Name</th>
	        <th>Brand Image</th>
	        <th>Created</th>
	        <th>Action</th>
	    </tr>
	    </thead>
	    <tbody>
	    	<?php
	    	$a=1;
	    		$get_brand = $this->Admin_Model->get_brand_list();
	    		//print_r($get_brand);
	    		foreach($get_brand as $ad){
	    			$a;
	    		 
	    	?>
	    	<tr>
	    		<td><?php echo $a++;?></td>
	    		<td><?php echo $ad->b_name; ?></td>
	    		<td>
	    		    
	    		    
	    		 <?php if (!empty($ad->b_img)) { ?>
              <img width="100px" height="100px" src="<?php echo base_url('uploads/brand/'.$ad->b_img);?>">
            <?php  } else { ?>
             <img src="<?php echo base_url(); ?>admin_assets/img/no-image-icon.png" height="60">
            <?php } ?>
	    		 </td>
	    		<td><?php echo $ad->created_date; ?></td>
	    		<td>
	    			<?php
	    				if($ad->status==1){ ?>
	    					<a class="label label-success" href="<?php echo base_url('Admin/brandstatus/'.$ad->id.'/0/')?>">Active</a>
	    				<?php }else{ ?>
	    					<a class="label label-danger" href="<?php echo base_url('Admin/brandstatus/'.$ad->id.'/1/')?>">In Active</a>
	    					 		


	    				<?php }	?>
                            <br>
                            <br>
	    				<a href="javascript:;" data-toggle="modal" data-target="#editebrand<?php echo $ad->id;?>"><span class="btn btn-info"><i class="glyphicon glyphicon-edit icon-white"></i></span></a>
	    				&nbsp;
	    				<a href="<?php echo base_url('Admin/delete_brand/'.$ad->id);?>" onclick="return confirm('Do you want to delete')" ><span class="btn btn-danger"><i class="glyphicon glyphicon-trash icon-white"></i></span></a>

	    			
	    		</td>
	    	</tr>




	    		 <!--Edit Brand-->
      <div class="modal fade" id="editebrand<?php echo $ad->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Edit Brand</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <form method="post" action="<?php echo base_url('Admin/Edit_brand');?>" enctype="multipart/form-data">
		      <div class="modal-body">

		       <input type="text" name="bname" class="form-control" value="<?php echo $ad->b_name?>" placeholder="Enter Brand Name">
		       <input type="hidden" name="Brand_id" value="<?php echo $ad->id?>" placeholder="Enter Brand Name">
		       <br>
		       <label>Brand Image</label>
		        <input type="file" name="bimgu" class="form-control" value="<?php echo $ad->b_img?>" placeholder="">
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-warning">Save changes</button>
		      </div>
		      </form>
		    </div>
		  </div>
		</div>
      <!--Edit Brand End-->

	  	    <?php } ?>
	    </tbody>
	    </table>


        </div>
    </div>
    </div>
   </div>
  </div>
</div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <!--Add Brand-->
      <div class="modal fade" id="addbrandmodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Add Brand </h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <form method="post" action="<?php echo base_url('Admin/add_brand');?>" enctype="multipart/form-data">
		      <div class="modal-body">

		       <input type="text" name="bname" class="form-control" placeholder="Enter Brand Name">
		       <br>
		       <label>Brand Image</label>
		        <input type="file" name="bimg" class="form-control" placeholder="">
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-warning">Save changes</button>
		      </div>
		      </form>
		    </div>
		  </div>
		</div>
      <!--Add Brand End-->



<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->
    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>