<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       User Amount Transaction
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">  User Amount Transaction</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-5 btn-class">
              <a href="<?php echo base_url(); ?>Admin/add_cashback/<?php echo $this->uri->segment(3); ?>" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list" ></span> Add Cashback </a>&nbsp;
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                      <table id="example" class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No</th>
        <th>Date & Time</th>
        <th>Transaction No</th>
        <th>Transaction Source</th>
        <th>Credit</th>
        <th>Debit</th>
        <th>Total Amount</th>
       
        
    </tr>
    </thead>
    <tbody>
  <?php
   $kk=1;
  if(count($amount_transaction_list)>0)
  {
    foreach($amount_transaction_list as $ae) {
  ?>
    <tr>
        <td><?php echo $kk; ?></td>
        <td><?php echo date('d, M Y',strtotime($ae->transaction_created)); ?></td>
        <td><?php echo $ae->transaction_number; ?></td>
        <td><?php echo $ae->transaction_from; ?></td>
        <td><?php if($ae->transaction_credit_amount != 0){echo $ae->transaction_credit_amount;}else{ }; ?></td>
        <td><?php if($ae->transaction_debit_amount != 0){echo $ae->transaction_debit_amount;}else{ }; ?></td>
        <td>Rs.<?php echo $ae->transaction_available_amount; ?>/-</td>
        </td>
    </tr>
  <?php $kk++; } } ?>
    </tbody>
    </table>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->



    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>