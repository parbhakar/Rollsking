<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Add Cashback
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Add Cashback</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-5 btn-class">
              <a href="<?php echo base_url(); ?>Admin/amount_transaction/<?php echo $this->uri->segment(3); ?>" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list" ></span> View Transaction </a>&nbsp;
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                     <form action="<?php echo base_url('Admin/submitcashback'); ?>" method="post">
                        <input type="hidden" name="userid" value="<?php echo $userid; ?>">
                               <div class="row">
                                  <div class="col-md-4">
                                    
                                    <div class="col-md-12">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Enter Cashback Amount</label>
                                         <input type="number" required name="cashback_amount" id="cashback_amount" class="form-control">
                                      </div>
                                    </div>
                                      <div class="col-md-12">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Enter Cashback Remark</label>
                                         <input type="text" required name="cashback_remark" id="cashback_remark" class="form-control">
                                      </div>
                                    </div>
                                     <div class="col-md-12">
                                      <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-sm pull-right btn-block bg-aqua">Add Cashback</button>
                                      </div>
                                    </div>
                                     
                                    </div>
                                  </div>
                      </form>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>