<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       View Address
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> View All Address</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-5 btn-class">
               <!--<a href="<?php echo base_url('Admin/show_add_sub_users');?>" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle"></span> Add Sub Users </a>-->
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                   
                      <table  class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
   <tr>
        <th>Sr.No</th>
        <th>User Profile</th>
        <th>Company Details</th>
        <th>Status</th>
    </tr>
    </thead>
    <tbody>
    <?php
    // $url = $this->uri->segment(3);
    $i = 1;
    $saveaddres = $this->Admin_Model->ViewALLADDRESS_LIST();
    //print_r($saveaddres);

    foreach($saveaddres as $ae){
        $i;
    ?>

    <tr>
        <td><?php echo $i++;?></td>
        <td>
          Name : <?php echo $ae->user_name;?><br>
          Email : <?php echo $ae->user_email;?><br>
          Phone : <?php echo $ae->user_mobile;?><br>
        </td>
        
        <td>
          Shop Name : <?php echo $ae->user_shop;?><br>
          Gst : <?php echo $ae->user_gst;?><br>
          State : <?php echo $ae->user_state;?><br>
          City : <?php echo $ae->user_city;?><br>
          Pincode : <?php echo $ae->pin_code;?><br>
          Address : <?php echo $ae->user_address;?><br>
        </td>
        <td>
          <!-- <a class="btn-success" href="<?php echo base_url();?>Admin/update_address_status/<?php echo $ae->id; ?>/2">Go</a> -->

           
 <select name=""onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
               <option value="" hidden>Select Status</option>
               <option value="<?php echo base_url();?>Admin/update_address_status/<?php echo $ae->id; ?>/1" <?php if($ae->status==1) { echo "selected";} ?>>Pendding</option>             
               <option value="<?php echo base_url();?>Admin/update_address_status/<?php echo $ae->id; ?>/2" <?php if($ae->status==2) { echo "selected";} ?>>Approved</option>
               <option value="<?php echo base_url();?>Admin/update_address_status/<?php echo $ae->id; ?>/3" <?php if($ae->status==3) { echo "selected";} ?>>Reject</option>
          </select>
          
        </td>


    </tr>

     
  <?php } ?>
   
    </tbody>
    </table>
      <?php //echo $links; ?>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->



    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>



<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>