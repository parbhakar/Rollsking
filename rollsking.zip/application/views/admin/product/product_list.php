<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Product List
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Product List</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           <div class="col-lg-4 btn-class">
              <a href="<?php echo base_url(); ?>Admin/addproduct" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Product </a>&nbsp;
              <a href="<?php echo base_url(); ?>Admin/product" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list"></span> Product List</a>&nbsp;
            </div> 
           
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                  
                  <div class="col-md-7">
                  <?php echo $links; ?>
                  </div>
   <div class="col-md-5" style="margin: 20px 0px 20px 0px;">
      <form method="GET" action="<?php echo base_url('Admin/product'); ?>">
        <div class="col-md-10 mtassing">
          <input type="text" name="product_name" class="form-control" id="product_name" data-live-search="true" placeholder="Search by Product Name" value="<?php echo @$_GET['product_name']; ?>"> 
        </div> 
 
        <div class="col-md-2 mtassing">
          <input type="submit" value="Search" name="submit" title="Search" style="margin-right: 10px;" class="btn btn-success">
        		
		 </div>
      </form>
    </div>
                     <table  class="table table-striped table-bordered bootstrap-datatable responsive datatable">
    <thead>
    <tr>
        <th>S.No</th>
        <th>Image</th>
        <th>Product Name</th>
        <th>HSN Code</th>
        <th>Category</th>
        <th>GST Slab</th>
     
        <!-- <th>MRP</th> -->
        <th>Price</th>
        <!--<th>Shipping</th> -->
        <th>Qty</th>
        <th>Auto Qty</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
  <?php
  
  if($this->uri->segment('3')==null)
  {
      $k=0;
  }else{
      $k=$this->uri->segment('3');
  }
  
 
  if(count($product_list)>0)
  {
    foreach($product_list as $ae) {
      $k++;
  ?>
    <tr>
        <td><?php echo $k; ?></td>
        <td>
          <?php if (!empty($ae->product_img)) { ?>
              <img src="<?php echo base_url("uploads/product")."/".$ae->product_img; ?>" height="60">
            <?php  } else { ?>
             <img src="<?php echo base_url(); ?>admin_assets/img/no-image-icon.png" height="60">
            <?php } ?>
          
        </td>
        <td>
    Name :- <?php echo $ae->product_name; ?><br>
    Product ID :- <?php echo $ae->product_id; ?>
    
    </td>
    <td><?php echo $ae->hsncode; ?> </td>
        <td>
    <?php
    if($ae->product_id!=0) { 
      $CategoryData= $this->Admin_Model->getCatNameForProduct($ae->product_id); 
      if($CategoryData){
           foreach ($CategoryData as $key => $aed) {
            echo $aed->category_name;echo "<br>";
          }
      }
     
    } else { 
      echo "Parent"; 
    } 
    ?>
    </td>
     <td> <?php echo $ae->slab; ?> % </td>  
 <!--    <td><?php echo "Rs.".$ae->product_mrp."/-"; ?></td> -->
    <td><?php echo "Rs.".$ae->product_price."/-"; ?></td>
    <!--<td><?php echo "Rs.".$ae->product_shipping_price."/-"; ?></td>
    <td><?php echo $ae->product_qty; ?></td>-->
    <td>
         <input style="width: 70px;margin: 0px auto;display: block;" type="number" id="product_QTY<?php echo $ae->product_id;?>" onchange="" name="product_qty<?php echo $ae->product_id;?>" value="<?php echo $ae->product_qty; ?>">
         
    </td>
     <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
         <script type="text/javascript">
            $(document).ready(function(){
              $("#product_QTY<?php echo $ae->product_id;?>").change(function(){

                var product_qty = $("#product_QTY<?php echo $ae->product_id;?>").val();
                var product_id = <?php echo $ae->product_id;?>

                //alert(product_qty);
                //alert(product_id);
                 $.ajax({
                      url: "<?php echo base_url('Admin/Single_product_qty_Update')?>",
                      type: "post",
                      data: {product_qty : product_qty, product_id : product_id},
                      dataType: "json",
                      //cache: false,
                      success: function (json) {
                          var message = json;
                            alert(message);
                      }
                  });
                });
            });

      
    </script>
    <td><?php echo $ae->auto_update_qty; ?></td>
    
     
        <td class="center">
     <!--  <p class="text-center">
      <?php  if($ae->product_status==1) { ?>
    
        <a href="<?php echo base_url('Admin/updateuproductstatus/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">Active</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductstatus/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Inactive</span></a>
       
      <?php } ?>
       
      <?php  if($ae->featured_status==1) { ?>
        <a href="<?php echo base_url('Admin/updateuproductfeature/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">Featured</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductfeature/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Not Featured</span></a>
      <?php } ?>
      
       <?php  if($ae->discounted_products==1) { ?>
        <a href="<?php echo base_url('Admin/updateuproductdiscounted_products/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">Discounted</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductdiscounted_products/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Not Discounted</span></a>
      <?php } ?>

      
      </p> -->
   
   
        
      <p class="text-center">

      <a href="<?php echo base_url('Admin/add_image')."/".$ae->product_id; ?>" title="Add Images" class="btn btn-warning"><i class="glyphicon glyphicon-camera icon-white"></i></a>
      
   
      <a href="<?php echo base_url('Admin/editproduct/'.str_replace('=','',base64_encode($ae->product_id))); ?>" class="btn btn-info"><i class="glyphicon glyphicon-edit icon-white"></i></a>
      <a href="<?php echo base_url('Admin/deleteproductmain/'.str_replace('=','',base64_encode($ae->product_id))); ?>" class="btn btn-danger" onclick="return confirm('Do you really want to delete this Main product? if yes so child product delete automatically')"><i class="glyphicon glyphicon-trash icon-white"></i></a>
     <!--  <a href="<?php echo base_url('Admin/child_product_list/'.str_replace('=','',base64_encode($ae->product_id))); ?>" class="btn btn-info" title="Child Products"><i class="glyphicon glyphicon-plus icon-white"></i></a>
      <br>

      <a href="<?php echo base_url('Admin/add_price_by_pin_code/'.str_replace('=','',base64_encode($ae->product_id))); ?>"><span class="label-success label label-default">Price By Pincode</span></a>
     
       <?php  if($ae->new_products==1) { ?>
        <a href="<?php echo base_url('Admin/updateuproductnew_products/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">New Product</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductnew_products/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Old Product</span></a> -->
      <?php } ?>
      </p>
    </td>
     
    </tr>
  <?php } } ?>
    </tbody>
    </table>
    
    <?php echo $links; ?>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->
    <script>
      $(function () {      
        $('#example').DataTable();
        //$('#timepicker1').timepicker();
      });
</script>

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>