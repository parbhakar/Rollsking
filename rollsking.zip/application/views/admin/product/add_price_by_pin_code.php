<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add Price by Pin Code
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Add Price by Pin Code</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
            <div class="col-lg-5 btn-class">
             Add Price by Pin Code
            </div>
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-8">
    <form name="optionForm" role="form" action="<?php echo base_url('Admin/addpricebypincode'); ?>" method="post">

            <input type="hidden" name="product_id" value="<?php echo $product_id=base64_decode($this->uri->segment(3)); ?>">
           

            <?php if(!empty($get_pincode)){
              foreach ($get_pincode as $key => $value) { ?>

                <input type="hidden" name="branch_id[]" value="<?php echo $value->bra_id; ?>">
               <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">Branch Pin Code</label>
                  <input type="text" class="form-control" id="branch_pin_code" placeholder="Enter Price" name="branch_pin_code" readonly="" value="<?php echo $value->bra_zip; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">

                  <?php $productprice=$this->Admin_Model->getProductPriceForEditPriceBypincode($value->bra_id,$product_id);
                  $productpriceinkh=$this->Admin_Model->getProductPriceForPincode($product_id); ?>
                  <label for="exampleInputEmail1">Product Price</label>
                  <input type="text" class="form-control" id="product_price" placeholder="Enter Shipping Price" name="product_price[]" value="<?php if(!empty(set_value('product_price'))){ echo set_value('product_price'); }else{ if(!empty($productprice->product_price)){ echo $productprice->product_price; }else{ echo $productpriceinkh->product_price; }} ?>">
                </div>
                <?php echo form_error("product_price"); ?>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">Max Qty (Per Purchase)</label>
                  <input type="text" class="form-control" id="offerQty" placeholder="Enter Price" name="offerQty[]" value="<?php if(!empty(set_value('offerQty'))){ echo set_value('offerQty'); }else{ if(@$productprice->offerQty !=0){ echo @$productprice->offerQty; }else{ echo 0; }} ?>">
                </div>
              </div>
             <?php  }} ?>
             <div class="col-md-12" style="text-align: center;">  
              <div class="col-md-5"><button type="submit" class="btn btn-info col-md-8">Add Price</button></div>
             </div>  
            </form>                    
            </div>

              


    

                </div>

                </div>
               </div>


              
              </div>
          </div>

        </section><!-- /.content -->





      </div><!-- /.content-wrapper -->

    </div><!-- ./wrapper -->

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>