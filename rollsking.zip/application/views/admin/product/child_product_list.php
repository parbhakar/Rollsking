<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add Child Product
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Add Child Product</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
            <div class="col-lg-5 btn-class">
             Add Child Product
            </div>
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
    <form name="optionForm" role="form" action="<?php echo base_url('Admin/childProductsubmit'); ?>" method="post">

            <input type="hidden" name="product_id" value="<?php echo base64_decode($this->uri->segment(3)); ?>">
            <div class="form-group col-md-3">
                <label for="exampleInputFile">Status</label>
                <select name="product_status" class="form-control">
                  <option value="1">Enable</option>
                  <option value="0">Disable</option>
                </select>
              </div> 
              
              <div class="form-group col-md-3">
                <label for="exampleInputFile"> Stock Status</label>
                <select name="stock_status" class="form-control">
                  <option value="1">In Stock</option>
                  <option value="0">Out Of Stock</option>
                </select>
              </div>    

              <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Code</label>
                  <input type="text" class="form-control" id="product_code" placeholder="Enter Qty" name="product_code" value="<?php echo set_value('product_code'); ?>">
                </div>
                <?php echo form_error( "product_code"); ?>
              </div>
               <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Qty</label>
                  <input type="number" class="form-control" id="product_qty" placeholder="Enter Qty" name="product_qty" value="<?php echo set_value('product_qty'); ?>">
                </div>
                <?php echo form_error( "product_qty"); ?>
              </div>  

               <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Purchase Qty</label>
                  <input type="text" class="form-control" id="purchase_qty" placeholder="Enter Qty" name="purchase_qty" value="<?php echo set_value('purchase_qty'); ?>">
                </div>
                <?php echo form_error( "purchase_qty"); ?>
              </div>  
              <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product MRP</label>
                  <input type="text" class="form-control" id="product_mrp" placeholder="Enter MRP" name="product_mrp" value="<?php echo set_value('product_mrp'); ?>">
                </div>
                <?php echo form_error("product_mrp"); ?>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Price</label>
                  <input type="text" class="form-control" id="product_price" placeholder="Enter Price" name="product_price" value="<?php echo set_value('product_price'); ?>">
                </div>
                <?php echo form_error("product_price"); ?>
              </div>
              <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Shipping Price</label>
                  <input type="text" class="form-control" id="product_shipping_price" placeholder="Enter Shipping Price" name="product_shipping_price" value="<?php echo set_value('product_shipping_price'); ?>">
                </div>
                <?php echo form_error("product_shipping_price"); ?>
              </div>
               <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">KH Purchase Price</label>
                  <input type="text" class="form-control" id="kh_purchase_price" placeholder="Enter Purchase Price" name="kh_purchase_price" value="<?php echo set_value('kh_purchase_price'); ?>">
                </div>
                <?php echo form_error("kh_purchase_price"); ?>
              </div>



    

 <div class="col-md-12" style="text-align: center;">  
  <div class="col-md-3"><button type="submit" class="btn btn-info col-md-8">Add Product</button></div>
 </div>  
</form>                    </div>
                </div>

                </div>
               </div>


               <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
            <div class="col-lg-5 btn-class">
              Child Product List
            </div>
            <div class="col-lg-7">
             
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                     <table id="example" class="table table-striped table-bordered bootstrap-datatable datatable responsive">  
          <thead>
            <tr>
              <th>S.No</th>
              <th>Product Code</th>
              <th>Qty</th>
              <th>Purchase Qty</th>
              <th>Product MRP</th>
              <th>Product Price</th>
              <th>Shipping Price</th>
              <th>Stock Status</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="tbd1">
          <?php  
          $k=0;
          foreach($child_product_list as $ae){
          $k++; 
          ?>
            <tr>
              <td><?php echo $k ?></td>
              <td><?php echo $ae->product_code; ?></td>
              <td><?php echo $ae->product_qty; ?></td>
              
              
              <td><?php echo $ae->purchase_qty; ?></td>
              <td>Rs.<?php echo $ae->product_mrp; ?>/-</td>
              <td>Rs.<?php echo $ae->product_price; ?>/-</td>
              <td>Rs.<?php echo $ae->product_shipping_price; ?>/-</td>
               

      
               <td>

     <?php  if($ae->stock_status==1) { ?>
    
        <a href="<?php echo base_url('Admin/updateuproductstock_status/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">In Stock</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductstock_status/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Out Of Stock</span></a>
       
      <?php } ?>

</td>
         <td>
 <?php  if($ae->product_status==1) { ?>
    
        <a href="<?php echo base_url('Admin/updateuproductstatus/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">Active</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductstatus/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Inactive</span></a>
       
      <?php } ?>
      <br>
       
      <?php  if($ae->featured_status==1) { ?>
        <a href="<?php echo base_url('Admin/updateuproductfeature/'.str_replace('=','',base64_encode($ae->product_id).'/0/')); ?>"><span class="label-success label label-default">Featured</span></a>
      <?php } else { ?> 
        <a href="<?php echo base_url('Admin/updateuproductfeature/'.str_replace('=','',base64_encode($ae->product_id).'/1/')); ?>"><span class="label-default label label-danger">Featured</span></a>
      <?php } ?>

</td>
    <td> <a href="<?php echo base_url('Admin/deleteproduct/'.str_replace('=','',base64_encode($ae->product_id))); ?>"  onclick="return confirm('Do you really want to delete this product ?')" title="Delete"><span class="label label-danger">Delete</span></a>
      <br>

      <a href="<?php echo base_url('Admin/editproduct/'.str_replace('=','',base64_encode($ae->product_id))); ?>" class="label btn-info">Edit Product</a>
      <br>
      <a href="<?php echo base_url('Admin/add_price_by_pin_code/'.str_replace('=','',base64_encode($ae->product_id))); ?>"><span class="label-success label label-default">Price By Pincode</span></a>
    </td> 

    
   
            </tr> 
<?php  }  ?>
          </tbody>
        </table>
                     </div>
                </div>






                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->





      </div><!-- /.content-wrapper -->

    </div><!-- ./wrapper -->

<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>