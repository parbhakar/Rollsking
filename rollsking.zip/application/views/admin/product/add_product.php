<?php $this->load->view('admin/components/header_css.php'); ?>
<div class="wrapper">

  <?php $this->load->view('admin/components/header.php'); ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php $this->load->view('admin/components/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <style type="text/css">
    .dataTables_filter{
      text-align: right;
    }
    .paging_simple_numbers {
      text-align: right;
    }
  </style>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Add Product
        <small>Control panel</small>
      
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Add Product</li>
      </ol>
    </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
              <div class="col-md-12">
               <div id="listGroup" class="box box-info">
                <div class="box-header with-border">
           
             <div class="col-lg-4 btn-class">
              <a href="<?php echo base_url(); ?>Admin/addproduct" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-plus-circle" ></span> Add Product </a>&nbsp;
              <a href="<?php echo base_url(); ?>Admin/product" class="btn btn-flat margin" style="background-color: #605ca8; color: #fff;"><span class="fa fa-list"></span> Product List</a>&nbsp;
            </div> 
            <div class="col-lg-7">
              <p style="color: red;"><?php $ms=@$this->session->userdata('message');$this->session->unset_userdata('message'); ?></p>
              <?php if ($ms){?>
                <div class='alert alert-success alert-dismissible pull-right' style="margin: 0px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <i class="icon fa fa-check"></i><?php echo $ms ;?>
                </div>
              <?php }?>
            </div>
            </div>
                   
                   <div class="box-body">
                    <div class="col-md-12">
                 <form name="elementForm" id="leadAddForm" role="form" action="<?php echo base_url('Admin/productsubmit');?>" method="post" enctype="multipart/form-data">
                         
            <div class="col-md-12">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Name</label>
                  <input type="text" class="form-control" id="product_name" placeholder="Enter Name" name="product_name" value="<?php echo set_value('product_name'); ?>">
                </div>
                <?php echo form_error( "product_name"); ?>
              </div>  
              <div class="col-md-6">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Main Image</label>
                  <input type="file" class="form-control" id="product_image" placeholder="Choose Image" name="product_image" value="<?php //echo set_value('product_image'); ?>"> </div>
                <?php //echo form_error("product_image"); ?>
              </div>
              <div class="form-group col-md-3">
                <label for="exampleInputFile"> Is Featured </label>
                <select name="featured_status" class="form-control">
                  <option value="1">Yes</option>
                  <option value="0">No</option>
                </select>
              </div>
               <div class="form-group col-md-3">
                <label for="exampleInputFile">Status</label>
                <select name="product_status" class="form-control">
                  <option value="1">Enable</option>
                  <option value="0">Disable</option>
                </select>
              </div> 
              
              <div class="form-group col-md-3">
                <label for="exampleInputFile"> Stock Status</label>
                <select name="stock_status" class="form-control">
                  <option value="1">In Stock</option>
                  <option value="0">Out Of Stock</option>
                </select>
              </div>              

             

               <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Qty</label>
                  <input type="number" class="form-control" id="product_qty" placeholder="Enter Qty" name="product_qty" value="<?php echo set_value('product_qty'); ?>">
                </div>
                <?php echo form_error( "product_qty"); ?>
              </div>  


               <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Auto Update Qty</label>
                  <input type="number" class="form-control" id="auto_update_qty" placeholder="Enter Qty" name="auto_update_qty">
                </div>
              </div> 

               <div class="col-md-3" >
                <div class="form-group">
                  <label for="exampleInputEmail1">Purchase Qty</label>
                  <input type="text" class="form-control" id="purchase_qty" placeholder="Enter Purchase Qty" name="purchase_qty" value="<?php echo set_value('purchase_qty'); ?>">
                </div>
                <?php echo form_error( "purchase_qty"); ?>
              </div>  

               <div class="col-md-3" style="display: none;">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Code</label>
                  <input type="text" class="form-control" id="product_code" placeholder="Enter Product Code" name="product_code" value="<?php echo set_value('product_code'); ?>">
                </div>
                <?php echo form_error( "product_code"); ?>
              </div>  
               
              
              
              
              
             
              
              <div class="col-md-3" style="display:none;">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product MRP</label>
                  <input type="text" class="form-control" id="product_mrp" placeholder="Enter MRP" name="product_mrp" value="<?php echo set_value('product_mrp'); ?>">
                </div>
                <?php echo form_error("product_mrp"); ?>
              </div>
              <div class="col-md-3" style="display:none;">
                <div class="form-group">
                  <label for="exampleInputEmail1">KH Purchase Price</label>
                  <input type="text" class="form-control" id="kh_purchase_price" placeholder="Enter Purchase Price" name="kh_purchase_price" value="<?php echo set_value('kh_purchase_price'); ?>">
                </div>
                <?php echo form_error("kh_purchase_price"); ?>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Price</label>
                  <input type="text" class="form-control" id="product_price" placeholder="Enter Price" name="product_price" value="<?php echo set_value('product_price'); ?>">
                </div>
                <?php echo form_error("product_price"); ?>
              </div>
              <div class="col-md-3" style="display:none;">
                <div class="form-group">
                  <label for="exampleInputEmail1">Shipping Price</label>
                  <input type="text" class="form-control" id="product_shipping_price" placeholder="Enter Shipping Price" name="product_shipping_price" value="<?php echo set_value('product_shipping_price'); ?>">
                </div>
                <?php echo form_error("product_shipping_price"); ?>
              </div>
              <div class="form-group col-md-3" style="display: none;">
                <label for="exampleInputFile"> Is Subscribe </label>
                <select name="subscribe_status" class="form-control">
                  <option value="0">No</option>
                  <option value="1">Yes</option>
                </select>
              </div>

               <div class="form-group col-md-3">
                <label for="exampleInputFile"> HSN Code </label>
                <input type="text" name="hsncode" placeholder="HSN Code" class="form-control">
              </div>
             

              
        
              <div class="col-md-4">
                <div class="form-group">
                  <label for="exampleInputEmail1">Category Name</label>
                  <select class="form-control" id="product_cat" name="product_cat[]" multiple required >
                     
                    <?php 
                    $categoryList = $this->Admin_Model->getActiveProductCategory();
                    if(count($categoryList)>0) {
                      foreach($categoryList as $category){
                        $subCategoryList = $this->Admin_Model->getActiveProductCategory($category->category_id);
                    ?>
                    <option value="<?php echo $category->category_id; ?>" <?php if(set_value('product_cat')==$category->category_id) echo 'selected'; ?> style="font-weight:normal;border-bottom:1px dotted #000;padding:5px" <?php // if(count($subCategoryList)>0) echo 'disabled'; ?> ><?php echo $category->category_name; ?></option> 
                    
                    <?php 
                    $subCategoryList = $this->Admin_Model->getActiveProductCategory($category->category_id);
                    if(count($subCategoryList)>0) {
                      foreach($subCategoryList as $subCat){
                    ?>
                    <option value="<?php echo $subCat->category_id; ?>" <?php if(set_value('product_cat')==$subCat->category_id) echo 'selected'; ?> style="font-weight:normal;border-bottom:1px dotted #000;padding:5px" >&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $subCat->category_name; ?></option>
                    <?php } } } } ?>
                   
                  </select>
                  
                  
                </div>
                <?php echo form_error( "product_cat"); ?>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                    <label for="exampleInputEmail1">Select Brand</label>
                    <select class="form-control" id="brand_id" name="brand_id" required >
                        <option>Select Brand</option>
                    <?php 
                    $brand = $this->Admin_Model->getActivebrandlist();
                    if(!empty($brand)) {
                      foreach($brand as $bra){ ?>
                        <option value="<?php echo $bra->id; ?>" <?php if(set_value('brand_id')==$bra->id) echo 'selected'; ?>><?php echo $bra->b_name; ?></option> 
                   <?php } } ?>
                   </select>
                </div>
                <?php echo form_error("brand_id"); ?>
              </div>

               <div class="col-md-4">
                <div class="form-group">
                    <label for="exampleInputEmail1">Select GST Slab</label>
                    <select class="form-control" id="gstslab" name="gstslab" required >
                        <option>Select GST Slab</option>
                    <?php 
                    $gstslab = $this->Admin_Model->getgst_slab();
                    if(!empty($gstslab)) {
                      foreach($gstslab as $gst){ ?>
                        <option value="<?php echo $gst->id; ?>" <?php if(set_value('gstslab')==$gst->id) echo 'selected'; ?>><?php echo $gst->slab_name; ?></option> 
                   <?php } } ?>
                   </select>
                </div>
                <?php echo form_error("gstslab"); ?>
              </div>
            
            
              <div class="col-md-12">
                <div class="form-group">
                    <label for="exampleInputEmail1">Product Descrption</label>
                    <textarea class="form-control" id="editor1"  name="product_description"></textarea>
                </div>
                <?php echo form_error("product_description"); ?>
              </div>
             
              
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Small Description</label>
                  <input type="text" class="form-control" id="small_description" placeholder="Enter Small Description" name="small_description" value="<?php echo set_value('small_description'); ?>">
                </div>
                <?php echo form_error("small_description"); ?>
              </div>



              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Meta Tag Title</label>
                  <input type="text" class="form-control" id="meta_title" placeholder="Enter Meta Title" name="meta_title" value="<?php echo set_value('meta_title'); ?>">
                </div>
                <?php echo form_error("meta_title"); ?>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Meta Tag Description</label>
                  <textarea class="form-control" id="meta_description" placeholder="Enter Meta Description" name="meta_description"><?php echo set_value('meta_description'); ?></textarea>
                </div>
                <?php echo form_error("meta_description"); ?>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Meta Tag Keywords</label>
                  <textarea class="form-control" id="meta_keyword" placeholder="Enter Meta Keywords" name="meta_keyword"><?php echo set_value('meta_keyword'); ?></textarea>
                </div>
                <?php echo form_error("meta_keyword"); ?>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Product Tags</label>
                  <input type="text" class="form-control" id="product_tag" placeholder="Enter Product Tags" name="product_tag" value="<?php echo set_value('product_tag'); ?>">
                </div>
                <?php echo form_error("meta_title"); ?>
              </div>
               
              <div class="col-md-6">  
                <div class="form-group">
                  <button type="submit" class="btn btn-info">Submit</button>
                </div>
                            </div>
              
                        </div>
            
          
          
                    </form>
                    </div>
                </div>
                </div>
               </div>
              </div>
          </div>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $this->load->view('admin/components/footer'); ?>
    </div><!-- ./wrapper -->

<script type="text/javascript">
  $(function () {
    CKEDITOR.replace('editor1');
    CKEDITOR.replace('editor2');
    $('.textarea').wysihtml5()
  })
</script>
<?php $this->load->view('admin/components/footer.php'); ?>
<?php $this->load->view('admin/components/footer_js.php'); ?>