<!DOCTYPE html>
<html lang="en">
<head>
<title>Order ID #<?php echo $invid; ?></title>

  <style type="text/css">
    body,div,table,thead,tbody,tfoot,tr,th,td,p { font-family:"Arial"; font-size:x-small; font-size: 15px;}
    a.comment-indicator:hover + comment { background:#ffd; position:absolute; display:block; border:1px solid black; padding:0.5em;  } 
    a.comment-indicator { background:red; display:inline-block; border:1px solid black; width:0.5em; height:0.5em;  } 
    comment { display:none;  } 
  </style>
  
</head>

<body>
 
<table cellspacing="0" id="order_invoice<?php echo $invid;?>" border="0" style="margin-right: auto;margin-left: auto; border: solid 1px #c5c5c5;
    padding: 10px;">
  <colgroup width="120"></colgroup>
  <colgroup width="70"></colgroup>
  <colgroup width="70"></colgroup>
  <colgroup width="70"></colgroup>
  <colgroup width="89"></colgroup>
  <colgroup width="50"></colgroup>
  <colgroup width="80"></colgroup>
  <colgroup width="70"></colgroup>
  <!-- <tr>
    <td height="19" align="left" valign="middle" colspan="10">
      <img src="<?php echo base_url();?>assets/img/logo/logo.jpg" style="width: 80px;">
    </td>
    
    
    
  </tr> -->
    <tr> 
     <td height="19" style="padding-bottom: 15px;font-size: 16px;text-transform: uppercase;font-weight: bold;" align="center" valign="middle" colspan="12">Taxable Invoice</td>
     
    </tr>
    
   
  <tr>
    <td height="19" align="left" valign="middle" colspan="6">YUG BITE & VITTLES PRIVATE LIMITED</td>
    
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=3 align="center" valign=middle bgcolor="#DBDBDB"><b>INVOICE #</b></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="3"><b>ORDER DATE</b></td>

  </tr>
  <tr>
    <td height="19" align="left" valign="middle" colspan="5">Noida - (20-21 B-97, SEC-88, NOIDA</td>
    <td align="left" valign=middle><br></td>
    
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=3 align="center" valign=middle sdval="2034" sdnum="1033;">#<?php echo $invid; ?></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan="3" align="center" valign=middle sdval="43609"><?php echo date("d M, Y", strtotime($getOrderData->order_created)); ?> </td>
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">GSTIN/UIN: 09AABCY0697B1ZA</td>
    <td align="left" valign=middle><br></td> 
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">Pan Number : AABCY0697B</td>
    <td align="left" valign=middle><br></td> 
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">CIN Number : U55101DL2018PTC343228</td>
    <td align="left" valign=middle><br></td> 
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">State Name : Uttar Pradesh, Code : 09</td>
    <td align="left" valign=middle><br></td>

    
  </tr>
  <tr>
    <td height="24" align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
  </tr>
  <tr>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=4 height="24" align="left" valign=middle bgcolor="#DBDBDB"><b>BILL TO</b></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=6 align="left" valign=middle bgcolor="#DBDBDB"><b>SHIP TO</b></td>
    </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="2"> <?php echo $userdata->user_name; ?></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign="middle" colspan="3"> <?php echo $userdata->user_name; ?></td>
  
  </tr>
  <tr>
    <td height="19" align="left" valign="middle" colspan="2"><?php echo $userdata->user_mobile; ?></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign="middle" ><?php echo $userdata->user_mobile; ?></td>
  </tr>
  <tr>
    <td height="26" align="left" valign="middle" colspan="5"><?php echo $userAddressData->user_address.", <br>".$userAddressData->user_state.", ".$userAddressData->user_city." - ".$userAddressData->user_zipcode; ?></td>
    <td align="left" valign=middle><br></td>
    
    <td align="left" valign="middle" colspan="3"><?php echo $userAddressData->user_address.", <br>".$userAddressData->user_state.", ".$userAddressData->user_city." - ".$userAddressData->user_zipcode; ?></td>
  
  </tr>
 
  <tr>
    <td height="19" align="left" valign="bottom" colspan="5"><?php echo $userdata->user_email; ?></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign="bottom" colspan="5"><?php echo $userdata->user_email; ?></td>
    
  </tr>

   <tr>
    <td height="19" align="left" valign="bottom" colspan="5">GSTIN/UIN: <?php echo $userdata->gstnmber; ?> </td>
    <td align="left" valign=bottom><br></td>
     <!--  <td align="left" valign="bottom" colspan="5">GSTIN/UIN: </td>   -->
    
  </tr>

   
<tr>
    <td height="19" align="left" valign="middle" colspan="5">
      <b>Payment Type :-</b> Online    
        </td>
    
  </tr>
  
  <tr>
    <td height="19" align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>

  </tr>
  <tr>
    <td height="19" align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
  </tr>
  <tr>
    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" height="26" align="left" valign=middle bgcolor="#DBDBDB" colspan="3"><b>DESCRIPTION OF GOODS</b></td>

    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="2"><b>HSN Code</b></td>
   

    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="2"><b>UNIT PRICE</b></td>
   
    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB"><b>QTY</b></td>

     <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="1"><b>GST</b></td>
    
    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="1"><b>CODE</b></td>
    
     <!--<td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="1"><b>GST %</b></td>-->

    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" ><b>AMOUNT</b></td>
  </tr>


  
  <tr>
    <?php //print_r($getOrderData); ?>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; font-size: 12px !important;" height="19" align="left" valign="middle" colspan="3">
        <?php  $invName=$this->Admin_Model->getInvNameBydb($getOrderData->inv_type)?>
            <?php echo $invName->inv_name; ?>
    </td>

    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="100" colspan="2">
    <?php echo $invName->hsn ?></td>

    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="100" colspan="2">
        <?php echo $getOrderData->bill_amont; ?>
    </td>



    <?php   $percent= $getOrderData->bill_amont - ($getOrderData->bill_amont * (100 / (100 + 18)));
        $GST_INC = $percent; ?>
     
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="1" sdnum="1033;"> <?php echo $itm->qty; ?></td>


    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="1" sdnum="1033;">  
      <?php $totalGST=$GST_INC *  1;
        //echo $this->cart->format_number($totalGST,2);
        
         // $totalGST=$GST_INC *  $itm->qty;
        //echo $this->cart->format_number($totalGST,2);
       $clintGST="09";
   $getOrderData->gstnmber;
   $GSTmatch = substr($getOrderData->gstnmber, 0, 2) == substr($clintGST, 0, 2);

   if($GSTmatch){
    $new_width = (50 / 100) * $totalGST;

      echo "CGST: ".$this->cart->format_number($new_width,2)."  SGST:".$this->cart->format_number($new_width,2);
      //echo "<br>";
      //echo $itm->user_id;
   }else{
      echo "IGST: ".$this->cart->format_number($totalGST,2);
   }?> 
        
    </td>


    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="18" colspan="1">  <?php echo $itm->code; ?> </td>
    
     <!--<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="18" colspan="1">  <?php echo $itm->gstslab; ?> %</td>-->
    
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="118" > Rs. <?php echo $getOrderData->bill_amont; ?>
    </td>
  </tr>

 


  
  <tr>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=7 height="37" align="center" valign=middle><i>Thank you for Shopping with Us! - rollsking.com</i></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" colspan=3 align="left" valign=middle><b><font size=3 color="#000000">TOTAL AMOUNT</b></td>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="right" colspan=2 valign=middle sdval="733"><b><font size=3 color="#000000"> Rs.
      <?php echo number_format($getOrderData->bill_amont,0); ?>/-</b></td>
  </tr>

   
  <tr>
    <td height="24" align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="right" valign=bottom><br></td>
  </tr>
  <tr>
    <td colspan=9 height="19" align="center" valign=bottom>If you have any questions about this invoice, please contact</td>
    </tr>
  <tr>
    <?php 
$site_settings = $this->Site_Model->getSiteSetting();
?>
  
    <td colspan=9 height="19" align="center" valign=bottom><?php echo @$site_settings->contact_phone; ?> | <?php echo @$site_settings->contact_email; ?></td>
    </tr>
</table>
<div class="print_pdf">
  <a href="javascript:;" class="text-center" onclick="print_pdf()">Generate Invoice</a>
</div> 
<style type="text/css">
  .print_pdf{
    width: 150px;
    background: #4a4646;
    margin: 0 auto;
    padding: 10px 0px;
    text-align: center;
  }
  .print_pdf a{
    color: #fff;
  }
</style>
 
<!-- ************************************************************************** -->

     
</body>
 
 <script>
  function print_pdf(){
     //alert('test');
   //var data = document.getElementById('order_invoice<?php echo $getOrderData->order_unique_code;?>');
   window.print();
  }
     
</script>
  



</html>
