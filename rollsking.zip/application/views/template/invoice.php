<!DOCTYPE html>
<html lang="en">
<head>
<title>Order ID #<?php echo $getOrderData->order_unique_code; ?></title>

  <style type="text/css">
    body,div,table,thead,tbody,tfoot,tr,th,td,p { font-family:"Arial"; font-size:x-small; font-size: 15px;}
    a.comment-indicator:hover + comment { background:#ffd; position:absolute; display:block; border:1px solid black; padding:0.5em;  } 
    a.comment-indicator { background:red; display:inline-block; border:1px solid black; width:0.5em; height:0.5em;  } 
    comment { display:none;  } 
  </style>
  
</head>

<body>
 
<table cellspacing="0" id="order_invoice<?php echo $getOrderData->order_unique_code;?>" border="0" style="margin-right: auto;margin-left: auto; border: solid 1px #c5c5c5;
    padding: 10px;">
  <colgroup width="120"></colgroup>
  <colgroup width="70"></colgroup>
  <colgroup width="70"></colgroup>
  <colgroup width="70"></colgroup>
  <colgroup width="89"></colgroup>
  <colgroup width="50"></colgroup>
  <colgroup width="80"></colgroup>
  <colgroup width="70"></colgroup>
  <!-- <tr>
    <td height="19" align="left" valign="middle" colspan="10">
      <img src="<?php echo base_url();?>assets/img/logo/logo.jpg" style="width: 80px;">
    </td>
    
    
    
  </tr> -->
    <tr> 
     <td height="19" style="padding-bottom: 15px;font-size: 16px;text-transform: uppercase;font-weight: bold;" align="center" valign="middle" colspan="12">Taxable Invoice</td>
     
    </tr>
    
   
  <tr>
    <td height="19" align="left" valign="middle" colspan="6">YUG BITE & VITTLES PRIVATE LIMITED</td>
    
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=3 align="center" valign=middle bgcolor="#DBDBDB"><b>INVOICE #</b></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="3"><b>ORDER DATE</b></td>

  </tr>
  <tr>
    <td height="19" align="left" valign="middle" colspan="5">Noida - (20-21 B-97, SEC-88, NOIDA</td>
    <td align="left" valign=middle><br></td>
    
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=3 align="center" valign=middle sdval="2034" sdnum="1033;">#<?php echo $getOrderData->order_unique_code; ?></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan="3" align="center" valign=middle sdval="43609"><?php echo date("d M, Y", strtotime($getOrderData->order_created)); ?> </td>
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">GSTIN/UIN: 09AABCY0697B1ZA</td>
    <td align="left" valign=middle><br></td> 
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">Pan Number : AABCY0697B</td>
    <td align="left" valign=middle><br></td> 
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">CIN Number : U55101DL2018PTC343228</td>
    <td align="left" valign=middle><br></td> 
  </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="5">State Name : Uttar Pradesh, Code : 09</td>
    <td align="left" valign=middle><br></td>

    
  </tr>
  <tr>
    <td height="24" align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
  </tr>
  <tr>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=4 height="24" align="left" valign=middle bgcolor="#DBDBDB"><b>BILL TO</b></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=6 align="left" valign=middle bgcolor="#DBDBDB"><b>SHIP TO</b></td>
    </tr>
  <tr>
    <td height="24" align="left" valign="middle" colspan="2"> <?php echo $getOrderData->order_firstname; ?></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign="middle" colspan="3"> <?php echo $getOrderData->order_firstname; ?></td>
  
  </tr>
  <tr>
    <td height="19" align="left" valign="middle" colspan="2"><?php echo $getOrderData->order_phone; ?></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign="middle" ><?php echo $getOrderData->order_phone; ?></td>
  </tr>
  <tr>
    <td height="26" align="left" valign="middle" colspan="5"><?php echo $getOrderData->order_address.", <br>".$getOrderData->order_state.", ".$getOrderData->order_city." - ".$getOrderData->order_zipcode; ?></td>
    <td align="left" valign=middle><br></td>
    
    <td align="left" valign="middle" colspan="3"><?php echo $getOrderData->order_address.", <br>".$getOrderData->order_state.", ".$getOrderData->order_city." - ".$getOrderData->order_zipcode; ?></td>
  
  </tr>
 
  <tr>
    <td height="19" align="left" valign="bottom" colspan="5"><?php echo $getOrderData->order_email; ?></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign="bottom" colspan="5"><?php echo $getOrderData->order_email; ?></td>
    
  </tr>

   <tr>
    <td height="19" align="left" valign="bottom" colspan="5">GSTIN/UIN: <?php echo $getOrderData->gstnmber; ?> </td>
    <td align="left" valign=bottom><br></td>
     <!--  <td align="left" valign="bottom" colspan="5">GSTIN/UIN: </td>   -->
    
  </tr>

   
<tr>
    <td height="19" align="left" valign="middle" colspan="5">
      <?php  if($getOrderData->payment_type==1){
             echo "<b>Payment Type :-</b> Cash";
             } else if($getOrderData->payment_type==2) {
             echo "<b>Payment Type :-</b> Online";
             }elseif($getOrderData->payment_type==3){
              echo "<b>Payment Type :-</b> Paytm";
             }else{
             echo "Not Payment Type";
            } ?>      
        </td>
    
  </tr>
  
  <tr>
    <td height="19" align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>

  </tr>
  <tr>
    <td height="19" align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
    <td align="left" valign=middle><br></td>
  </tr>
  <tr>
    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" height="26" align="left" valign=middle bgcolor="#DBDBDB" colspan="3"><b>DESCRIPTION OF GOODS</b></td>

    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="2"><b>HSN Code</b></td>
   

    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="2"><b>UNIT PRICE</b></td>
   
    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB"><b>QTY</b></td>

     <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="1"><b>GST</b></td>
    
    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="1"><b>CODE</b></td>
    
     <!--<td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" colspan="1"><b>GST %</b></td>-->

    <td style="border-top: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" align="center" valign=middle bgcolor="#DBDBDB" ><b>AMOUNT</b></td>
  </tr>


    <?php 
  $k=0;
  $total =0;
  $booking =0;
  $total_gst = 0;
  $total_amount =0;
  $amount_with_taxs = 0;
  foreach($itemList as $itm){ 
  if(($k%2)==0)
  {
    $bgColor ='#F5F5F5;';   
  }else{
    $bgColor ='#FFFFFF;'; 
  } ?>  
  <tr>

    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; font-size: 12px !important;" height="19" align="left" valign="middle" colspan="3"><?php echo $itm->name; ?><br><!-- HSN :-  --><?php //echo $itm->item_hsn; ?></td>

    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="100" colspan="2">
    <?php echo $itm->hsncode;?></td>

    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="100" colspan="2">
    <?php //echo number_format($itm->one_price, 2, '.', ''); 
    $PRICE=$itm->one_price;
    echo $this->cart->format_number($PRICE,2);
    ?></td>


     <?php  $GST_INC= ($itm->gstslab / 100) * $itm->one_price; ?>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="1" sdnum="1033;"> <?php echo $itm->qty; ?></td>


    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="1" sdnum="1033;">  
      <?php $totalGST=$GST_INC *  $itm->qty;
        //echo $this->cart->format_number($totalGST,2);
        
         // $totalGST=$GST_INC *  $itm->qty;
        //echo $this->cart->format_number($totalGST,2);
       $clintGST="09";
   $getOrderData->gstnmber;
   $GSTmatch = substr($getOrderData->gstnmber, 0, 2) == substr($clintGST, 0, 2);

   if($GSTmatch){
    $new_width = (50 / 100) * $totalGST;

      echo "CGST: ".$this->cart->format_number($new_width,2)."  SGST:".$this->cart->format_number($new_width,2);
      //echo "<br>";
      //echo $itm->user_id;
   }else{
      echo "IGST: ".$this->cart->format_number($totalGST,2);
   }?> 
        
    </td>


    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="18" colspan="1">  <?php echo $itm->code; ?> </td>
    
     <!--<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="18" colspan="1">  <?php echo $itm->gstslab; ?> %</td>-->
    
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; text-align: center;" align="right" valign=middle sdval="118" > Rs.<?php
      $TOTLE_AMT=$itm->price + $totalGST; 
    
      echo $this->cart->format_number($TOTLE_AMT,2);
      ?>/- 
    </td>
  </tr>
<?php } ?>

 <?php /* <tr>
   
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=6 height="37" align="center" valign=middle><i><br></i></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" colspan=2 align="left" valign=middle><b><font size=3 color="#000000">SUB TOTAL</b></td>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="right" valign=middle sdval="708"><b><font size=3 color="#000000"> Rs.<?php echo number_format($total_amount,0); ?>/- </b></td>
  </tr> */?>

  <?php /* if($getOrderData->order_delivery>0){ ?>
         
          <tr>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=6 height="37" align="center" valign=middle><i><br></i></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" colspan=2 align="left" valign=middle><b><font size=3 color="#000000">DELIVERY CHARGES</b></td>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="right" valign=middle sdval="25"><b><font face="Cambria" size=3>Rs.  <?php echo $getOrderData->order_delivery; ?>/- </b></td>
  </tr>       
  <?php } */ ?>


<?php if($getOrderData->order_wallet_amount>0){ ?>
     <tr>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=7 height="37" align="center" valign=middle><i><br></i></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" colspan=2 align="left" valign=middle><b><font size=3 color="#000000">WALLET AMOUNT</b></td>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="right" valign=middle sdval="25"><b><font face="Cambria" size=3>Rs.  <?php echo $getOrderData->order_wallet_amount; ?>/- </b></td>
  </tr>           
  <?php } ?>


  
  <tr>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f; border-right: 1px solid #7f7f7f" colspan=7 height="37" align="center" valign=middle><i>Thank you for Shopping with Us! - rollsking.com</i></td>
    <td style="border-top: 1px solid #7f7f7f; border-bottom: 1px solid #7f7f7f; border-left: 1px solid #7f7f7f" colspan=3 align="left" valign=middle><b><font size=3 color="#000000">TOTAL AMOUNT</b></td>
    <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="right" colspan=2 valign=middle sdval="733"><b><font size=3 color="#000000"> Rs.
      <?php echo number_format($getOrderData->order_amount,0); ?>/-</b></td>
  </tr>

   
  <tr>
    <td height="24" align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="left" valign=bottom><br></td>
    <td align="right" valign=bottom><br></td>
  </tr>
  <tr>
    <td colspan=9 height="19" align="center" valign=bottom>If you have any questions about this invoice, please contact</td>
    </tr>
  <tr>
    <?php 
$site_settings = $this->Site_Model->getSiteSetting();
?>
  
    <td colspan=9 height="19" align="center" valign=bottom><?php echo @$site_settings->contact_phone; ?> | <?php echo @$site_settings->contact_email; ?></td>
    </tr>
</table>
<div class="print_pdf">
  <a href="javascript:;" class="text-center" onclick="print_pdf()">Generate Invoice</a>
</div> 
<style type="text/css">
  .print_pdf{
    width: 150px;
    background: #4a4646;
    margin: 0 auto;
    padding: 10px 0px;
    text-align: center;
  }
  .print_pdf a{
    color: #fff;
  }
</style>
 
<!-- ************************************************************************** -->

     
</body>
 
 <script>
  function print_pdf(){
     //alert('test');
   //var data = document.getElementById('order_invoice<?php echo $getOrderData->order_unique_code;?>');
   window.print();
  }
     
</script>
  



</html>
