<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class App extends CI_Controller {

  public function __Construct()
  {
      parent::__construct();
      $this->load->model('App_Model'); 
      $this->load->model('Admin_Model');
      $this->load->model('Site_Model');
      
      header('Access-Control-Allow-Origin: *');
      header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept,Authorization ");
  }
  
  public function index()
  {
    
  }
  public function sendPushNotificationToFCMSevers() {
    
    $userdatafornot=$this->db->select('*')->where('user_id',1)->get('kh_user_list')->row();
        $token=$userdatafornot->fcm_token;
        $message="Hello Hello";
    
    $API_SERVER_KEY = "AAAAtNbFj5U:APA91bFSoUa2kbf6xS1oBBS2gcuZUNdhimpoJjIofgkqY0DFnNrKZ53kJ1LubGZCEDAyPQDZBOpAKVDCuJ1fpxQQfdNlo5NQqSZ_wFDZVTjaATrBPAA72S98oeNIIt5WB4KdfiMF_0LL";
    
        $path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
 
        $fields = array(
            'registration_ids' => array($token),
            'priority' => 1,
            'notification' => array('title' => 'The Kiranewala', 'body' =>  $message ,'sound'=>'Default','image'=>'https://www.The Kiranewala.com/beta/admin_assets/img/icon-logo.jpg','click_action' => 'FCM_PLUGIN_ACTIVITY' ),
        );
        $headers = array(
            'Authorization:key=' .$API_SERVER_KEY,
            'Content-Type:application/json'
        );  
         
        // Open connection  
        $ch = curl_init(); 
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        // Execute post   
        
    $result = curl_exec($ch); 
        // Close connection      
        curl_close($ch);
        echo $result; die;
        //return $result;
    }
    public function sendPushNotificationToFCMSever($token, $message) {
    
    $API_SERVER_KEY = "AAAAtNbFj5U:APA91bFSoUa2kbf6xS1oBBS2gcuZUNdhimpoJjIofgkqY0DFnNrKZ53kJ1LubGZCEDAyPQDZBOpAKVDCuJ1fpxQQfdNlo5NQqSZ_wFDZVTjaATrBPAA72S98oeNIIt5WB4KdfiMF_0LL";
    
        $path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
 
        $fields = array(
            'registration_ids' => array($token),
            'priority' => 10,
            'notification' => array('title' => 'The Kiranewala', 'body' =>  $message ,'sound'=>'Default','image'=>'https://www.thekiranewala.com/admin_assets/img/icon-logo.jpg','click_action' => 'FCM_PLUGIN_ACTIVITY' ),
        );
        $headers = array(
            'Authorization:key=' .$API_SERVER_KEY,
            'Content-Type:application/json'
        );  
         
        // Open connection  
        $ch = curl_init(); 
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        // Execute post   
        
    $result = curl_exec($ch); 
        // Close connection      
        curl_close($ch);
        return $result;
    }
   public function registerAppUser()
  {
    //{"user_name":"Kumar","user_email":"dev.developer@gmail.com","user_mobile":"9874563210","user_state":"1234","user_password":"1234","fcm_token":"","refer_id":""}
     $newcustomer = file_get_contents("php://input");
     file_put_contents('textfile/newcustomer_request.txt', $newcustomer);
      if($newcustomer != null)
      {          
        $customerec = $newcustomer;
        $customer = json_decode($customerec, true);
        $user_name = $customer['user_name'];
        $user_email = $customer['user_email'];
        $user_mobile = $customer['user_mobile'];
        $user_state = $customer['user_state'];
        $user_password = $customer['user_password'];
        $refer_id = $customer['refer_id'];
        @$fcm_token =$customer['fcm_token'];
        
        
        if($user_mobile!="")
        {
        //   $checkEmail = $this->App_Model->getUserEmail($user_email);
        //   if($checkEmail == null)
        //   {
            $checkMobile = $this->App_Model->getUserDetailByMobile($user_mobile);
            if($checkMobile == null){

                  $currentUser =  $this->App_Model->insertregister($user_name,$user_email,$user_mobile,$user_password,$user_state,$fcm_token,$refer_id);  
                  $currentUserDetail = $this->App_Model->getUserDetail($currentUser); 


                  $data["user_id"] = $currentUserDetail->user_id;
                  $data["user_name"] = $currentUserDetail->user_name;
                  $data["user_email"] = $currentUserDetail->user_email;
                  $data["user_mobile"] = $currentUserDetail->user_mobile;
                  $data["user_state"] = $currentUserDetail->user_state;
                 
                  
                
                  $mobileNum=$currentUserDetail->user_mobile;
  
            
                   $otpNum = rand(1111,9999);
                  $this->App_Model->insertOtp($mobileNum , $otpNum);
            
                  $sms="Your The Kiranewala Verification OTP Code is $otpNum. Code valid for 10 minutes only, one time use. Please DO NOT share the OTP with anyone.";
                  //$sms="Your OTP is $otpNum. Valid for 15 minutes.";
                  $otpSMS=urlencode($sms);

                  $curl = curl_init();

                  curl_setopt_array($curl, array(
                  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$otpSMS."&ServiceName=TEMPLATE_BASED",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "GET",
                  ));

                  $response = curl_exec($curl);

                  curl_close($curl);
                    
                  $message="Your Mobile Number ".str_pad(substr($mobileNum, -4 ), strlen($mobileNum), '*', STR_PAD_LEFT)." Please Enter Your OTP and activate your account.";

                  $response = array("status_code" =>200 ,  "status" => "success", "message" => $message,"data" => $data );
                  echo  json_encode($response);
            }else{
               $response = array("status_code" =>201 ,  "status" => "success", "message" => "Mobile Number Already Registered","data" => "" );
              echo  json_encode($response);
            }
        //   }
        //   else
        //   {

        //     $response = array("status_code" =>201 ,  "status" => "success", "message" => "Email ID Already Registered","data" => "" );
        //     echo  json_encode($response);
        //   }
        }
        else
        {
           $response = array("status_code" =>201 ,  "status" => "success", "message" => "Mobile Number Required","data" => "" );
            echo  json_encode($response);
        }
      }
      else
      {
        $response = array("status_code" =>201 ,"status" => "failed", "message" => "Invalid Data","data" => "" );
        echo  json_encode($response);
      } 
  }
  
  
  public function submitOTPVerification()
      {
        //{"user_mobile":"9874563232","otp":"7972"}
         $otpVerification = file_get_contents("php://input");
         //file_put_contents('textfile/otpVerification_request.txt', $otpVerification);
          if($otpVerification != null)
          {
              $otpV = $otpVerification;
              $otpVerfiy = json_decode($otpV, true);
        
              $mobileNum=$otpVerfiy['user_mobile'];
            $otpNum=$otpVerfiy['otp'];
            $checkDb = $this->App_Model->confirmOtp($mobileNum , $otpNum);
        
            if ($checkDb !=0) {
              $this->App_Model->updateotp($mobileNum , $otpNum);
        
              $this->db->set("user_activation",1);
                $this->db->where("user_mobile",$mobileNum);
                $this->db->update("kh_user_list");
                
                $this->db->where("user_activation",1);
                $this->db->where("user_mobile",$mobileNum);
                $currentUser=$this->db->get("kh_user_list")->row();
                
    
                $userid=$currentUser->user_id;
                // if(!empty($userid)){
                //   $this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ '25' WHERE `user_id`= '".$userid."'");
                //   $this->db->select('*');
                //   $this->db->where('user_id',$userid);
                //   $this->db->order_by('transaction_id','desc');
                //   $this->db->limit(1);
                //   $lastEntery=$this->db->get('kh_wallet_transaction')->row();

                //   $credit_amount=25;
                  
                //   if(empty($lastEntery)){
                //       $available_amount=25;
                //   }else{
                //       $available_amount=$lastEntery->transaction_available_amount + 25;
                //   }
                  
                //   $this->db->set('user_id',$userid);     
                //   $this->db->set('transaction_from','Cashback on App Download');
                //   $this->db->set('transaction_credit_amount',$credit_amount);
                //   $this->db->set('transaction_available_amount',$available_amount);
                //   $this->db->set('transaction_status',1);
                //   $this->db->insert('kh_wallet_transaction');

                //   $insertid=$this->db->insert_id();
                //   $transaction_number="KHAQWERTYUIO00".$insertid;
                //   $this->db->set('transaction_number',$transaction_number);
                //   $this->db->where('transaction_id',$insertid);
                //   $this->db->update('kh_wallet_transaction');
                // }
                
                
                $currentUserDetail = $this->App_Model->getUserDetail($userid); 
                    $data["user_id"] = $currentUserDetail->user_id;
                    $data["user_name"] = $currentUserDetail->user_name;
                    $data["user_email"] = $currentUserDetail->user_email;
                    $data["user_mobile"] = $currentUserDetail->user_mobile;
                    $data["user_address"] = $currentUserDetail->user_address;
                    $data["user_state"] = $currentUserDetail->user_state;
                    $data["user_city"] = $currentUserDetail->user_city;
                    $data["user_zipcode"] = $currentUserDetail->user_zipcode;

                $response = array("status_code" =>200 ,  "status" => "success", "message" => "You are Successfully Registered with Us. ","data" => $data );
                    echo  json_encode($response);
            }else{
              $response = array("status_code" =>201 ,"status" => "failed", "message" => "Your OTP Not Match Please Try Again!!","data" => "" );
                    echo  json_encode($response);
            }
          }else{
            $response = array("status_code" =>201 ,"status" => "failed", "message" => "Invalid Data","data" => "" );
            echo  json_encode($response);
          } 
      }
  public function resendotp()
  {
      //{"user_mobile":"9874563232"}
         $resendotp = file_get_contents("php://input");
        // file_put_contents('textfile/resendotp_request.txt', $resendotp);
          if($resendotp != null)
          {
              $otpResend = $resendotp;
              $otpSend = json_decode($otpResend, true);
             

              $mobileNum=$otpSend['user_mobile'];
                $otpSMS=$this->App_Model->getOtpForResend($mobileNum);
              if(!empty($otpSMS)){
                  //$sms="Your The Kiranewala Verification OTP Code is $otpSMS->otp_number. Code valid for 10 minutes only, one time use. Please DO NOT share the OTP with anyone.";
                   $sms="Your OTP is $otpNum. Valid for 15 minutes.";
                  $otpSMS=urlencode($sms);

                  $curl = curl_init();

                  curl_setopt_array($curl, array(
                  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$otpSMS."&ServiceName=TEMPLATE_BASED",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "GET",
                  ));
                  $response = curl_exec($curl);
                  curl_close($curl);

                  $data=$otpSMS;
                  $message="Your Mobile Number ".str_pad(substr($mobileNum, -4 ), strlen($mobileNum), '*', STR_PAD_LEFT)." Please Enter Your OTP and activate your account.";

                  $response = array("status_code" =>200 ,  "status" => "success", "message" => $message,"data" => "" );
                  echo  json_encode($response);
                }else{
                  $response = array("status_code" =>201 ,"status" => "failed", "message" => "Your Mobile Number Not Found","data" => "" );
                  echo  json_encode($response);
                }
          }else{
            $response = array("status_code" =>201 ,"status" => "failed", "message" => "Invalid Data","data" => "" );
            echo  json_encode($response);
          } 
  }
  public function AppUserLogin()
  {
     //{"user_email":"dev.developer@gmail.com","user_password":"123456","fcm_token":""}
     $UserLogin = file_get_contents("php://input");
     file_put_contents('textfile/user_login.txt', $UserLogin);
      if($UserLogin != null)
      {
        // echo $UserLogin;
        $loginUser = json_decode($UserLogin, true);
        $user_emailid = $loginUser['user_email'];
        $user_passwords = $loginUser['user_password'];
        @$fcm_token = $loginUser['fcm_token'];
      
        if($user_emailid!="" && $user_passwords!="")
        {
          
            $logingUserdata=$this->App_Model->getSiteLogin($user_emailid);

            if (!empty($logingUserdata)) {
              
                $getDbPaas = $logingUserdata->user_password;
                $getUserPaas = md5($user_passwords);
              
              if($getDbPaas == $getUserPaas)
              {

               
                    
                  $todayDate = date("Y-m-d h:i:s");
                  $this->db->set("fcm_token",$fcm_token);
                  $this->db->set("user_updated",$todayDate);
                  $this->db->where("user_id",$logingUserdata->user_id);
                  $this->db->update("kh_user_list");    
                    
                    
                  $data["user_id"] = $logingUserdata->user_id;
                  $data["user_name"] = $logingUserdata->user_name;
                  $data["user_mobile"] = $logingUserdata->user_mobile;
                  $data["user_email"] = $logingUserdata->user_email;
                  $data["user_age"] = $logingUserdata->user_age;
                  $data["user_gender"] = $logingUserdata->user_gender;
                  $data["user_state"] = $logingUserdata->user_state;
                  $data["user_city"] = $logingUserdata->user_city;
                  $data["user_address"] = $logingUserdata->user_address;
                  $data["user_zip"] = $logingUserdata->user_zipcode;
                  $data['user_source'] = $logingUserdata->user_source;
                  
        
                  $response = array("status_code" =>200 ,  "status" => "success", "message" => "User Login Successfully.","data" => $data );
                  echo  json_encode($response);
                
              }else{
                $response = array("status_code" =>201 ,  "status" => "failed", "message" =>"Your Password is incorrect","data" => "" );
              echo  json_encode($response);
              } 
            }else{
              
              $response = array("status_code" =>201 ,  "status" => "failed", "message" => "We cannot find an account with that email address","data" => "" );
              echo  json_encode($response);
            }
        }
        else
        {
          $response = array("status_code" =>201 ,  "status" => "failed", "message" => "Please Enter All Fild.","data" => "" );
            echo  json_encode($response);
        }
      }
      else
      {
        $response = array("status_code" =>201 ,"status" => "failed", "message" => "Invalid Data","data" => "" );
        echo  json_encode($response);
     
      } 
  }
  
  
  public function getUserProfile()
  {
    //{"user_id":"1"}
    $userProfile = file_get_contents("php://input");
    file_put_contents('textfile/user_login_profile.txt', $userProfile);
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $userId=$user['user_id'];
      $profile_detail = $this->App_Model->getUserDetailForProfile($userId);
        
        
        $data['user_id'] = $profile_detail->user_id;
        $data['username'] = $profile_detail->username;
        $data['user_name'] = $profile_detail->user_name;
        $data['user_email'] = $profile_detail->user_email;
        $data['user_mobile'] = $profile_detail->user_mobile;
        $data['user_gender'] = $profile_detail->user_gender;
        $data['user_state'] = $profile_detail->user_state;
        $data['user_city'] = $profile_detail->user_city;
        $data['user_zipcode'] = $profile_detail->user_zipcode;
        $data['user_address'] = $profile_detail->user_address;
        $data['user_source'] = $profile_detail->user_source;

        
      $datas['profile_detail']= $data;
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "User Profile","data" => $datas);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }

  public function updateUserProfile()
  {
    //{"user_id":"1","user_name":"Kumar","user_email":"dev.developer@gmail.com","user_mobile":"9874563210","user_address":"","user_gender":"","user_city":"","user_state":"","user_zipcode":"","fcm_token":"1234"}
    $userDetail=file_get_contents("php://input");
    file_put_contents('textfile/user_login_update.txt', $userDetail);
    if(!empty($userDetail)){
      $user=json_decode($userDetail, true);
      $userid=  $this->App_Model->getUserDetail($user['user_id']);
      if ($userid !=null) 
      {
        $user_id = $user['user_id'];
        $user_name = $user['user_name'];
        $user_email = $user['user_email'];
        $user_mobile = $user['user_mobile'];
        $user_gender = $user['user_gender'];
        $address = $user['user_address'];
        $state = $user['user_state'];
        $city = $user['user_city'];
        $zipcode = $user['user_zipcode'];
        
        $this->App_Model->updateUserProfile($user_id,$user_name, $user_email, $user_mobile, $address,$user_gender,$city,$state,$zipcode);
        
        $data['profile_detail']=$this->App_Model->getUserDetailForProfile($user_id);
 
        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"User Profile Updated Successfully.","data"=> $data );
        echo  json_encode($response);

      } else {
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid User ID","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
      echo  json_encode($response);
    }
  }

  public function changePassword()
  {
    //{"user_id":"1","user_password":"Kumar","user_confirm_password":"Kumar"}
    $userDetail=file_get_contents("php://input");
    file_put_contents('textfile/user_login_change_password.txt',$userDetail);
    if(!empty($userDetail)){
      $user=json_decode($userDetail, true);
      $userid=  $this->App_Model->getUserDetail($user['user_id']);
      if ($userid !=null) 
      {
        $user_id = $user['user_id'];
        $user_password = $user['user_password'];
        $user_confirm_password = $user['user_confirm_password'];
        
        $user = $this->db->where("user_id",$user_id)->get("kh_user_list")->row();
        if($user->user_mobile == "1122334455"){ // special user
            $response=array('status_code' =>200 , "status" => "success" ,"message"=>"User Password Updated Successfully.","data"=> "" );
            echo  json_encode($response);
        }else{
        
        if($user_password == $user_confirm_password){
            $this->App_Model->changpass($user_id,$user_password);
      
            $response=array('status_code' =>200 , "status" => "success" ,"message"=>"User Password Updated Successfully.","data"=> "" );
            echo  json_encode($response);
        }else{
          $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Password & Confirm Password Not Match","data" => "" );
          echo  json_encode($response);
        }
        }    
    
        
      } else {
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid User ID","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
      echo  json_encode($response);
    }
  }
  public function sendEmail($to,$subject,$body)
   {
    $this->load->library('email');
    
    $config['protocol'] = 'sendmail';
    $config['mailpath'] = '/usr/sbin/sendmail';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['mailtype'] = 'html';
    $this->email->set_mailtype("html");
    $this->email->initialize($config);
    $this->email->from('support@The Kiranewala.com', 'The Kiranewala.com');
    $this->email->to($to);
    $this->email->cc('report@infutive.com');
    $this->email->subject($subject);
    $this->email->message($body);
    $this->email->send();
   }

   public function getMainCatListForSiteall()
   {
      $catlist_detail = $this->App_Model->getCatListForSiteall();
      
      foreach ($catlist_detail as $key => $ae) {

          $data['category_id']=$ae->category_id;
          $data['category_parent_id']=$ae->category_parent_id;
          $data['category_name']=$ae->category_name;
          $data['category_url']=$ae->category_url;
          $data['category_menu_active']=$ae->category_menu_active;

          if(!empty($ae->category_image)){
            $data['category_image']=base_url().'uploads/category/'.$ae->category_image;
          }else{
              $data['category_image']=base_url().'admin_assets/img/no-image-icon.png';
          }
          $data['category_desc']=$ae->category_desc;
          $data['category_article']=$ae->category_article;
          $catdata[]=$data;
      }

        $datas['all_detail']= $catdata;

      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Main Cat List","data" => $datas);
      echo  json_encode($response);
   }
   
   
   public function getSubCatListForSiteall()
   {
        //{"category_id":"1"}
        $catdata = file_get_contents("php://input");
        file_put_contents('textfile/get_sub_category.txt',$catdata);
        if($catdata != null) {
          $cat=json_decode($catdata, true);
          $category_id=$cat['category_id'];
          $catlist_detail = $this->App_Model->getsubCatListForSiteall($category_id);
          if(!empty($catlist_detail)){
              
          
              foreach ($catlist_detail as $key => $ae) {
        
                  $data['category_id']=$ae->category_id;
                  $data['category_parent_id']=$ae->category_parent_id;
                  $data['category_name']=$ae->category_name;
                  $data['category_url']=$ae->category_url;
                  $data['category_menu_active']=$ae->category_menu_active;
        
                  if(!empty($ae->category_image)){
                    $data['category_image']=base_url().'uploads/category/'.$ae->category_image;
                  }else{
                      $data['category_image']=base_url().'admin_assets/img/no-image-icon.png';
                  }
                  $data['category_desc']=$ae->category_desc;
                  $data['category_article']=$ae->category_article;
                  $catdatas[]=$data;
               }
        
              $datas['all_sub_detail']= $catdatas;
        
              $response = array("status_code" =>200 ,  "status" => "success", "message" => "Sub Cat List","data" => $datas);
              echo  json_encode($response);
          }else{
               $datas['all_sub_detail']=array();
             
              $response = array("status_code" =>200 ,  "status" => "success" ,"message" => "Data Not Found","data" => $datas );
             echo  json_encode($response);
          }
          
        }else{
          $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
          echo  json_encode($response);
        }
   }
   
   
  public function getcategoryProduct()
  {
    //{"category_id":"1","pincode":"800001"}
    
     $limit=$this->input->get('limit');
     $page=$this->input->get('page');
    $catdata = file_get_contents("php://input");
    file_put_contents('textfile/getcatproduct.txt',$catdata);
    if($catdata != null) {
      $cat=json_decode($catdata, true);
     $category_id=$cat['category_id'];
      $product_detail = $this->App_Model->getCategoryProductForcolumn($category_id,$limit,$page);
      if (!empty($product_detail)) {
            foreach ($product_detail as $key => $ae) {

                $data['product_id']=$ae->product_id;
                $data['parent_product']=$ae->parent_product;
                $data['product_code']=$ae->product_code;
                $data['product_qty']=$ae->product_qty;
                $data['purchase_qty']=$ae->purchase_qty;
                $data['product_url']=$ae->product_url;
                $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
                $data['product_desc']=$ae->product_desc;
                $data['product_price']=$ae->product_price;
                $data['product_available']="Available";
                //  if (!empty($cat['pincode'])) {
                //   $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$cat['pincode']);
                //   if (!empty($pricebypincode)) {
                //     $data['product_price']=$pricebypincode->product_price;
                //     $data['product_available']="Available";
                //   } else {
                //     $data['product_price']=$ae->product_price;
                //     $data['product_available']="Not Available";
                //   }
                // }else{
                //   $data['product_available']="Available";
                //   $data['product_price']=$ae->product_price;
                // }
                $data['product_mrp']=$ae->product_mrp;
                $data['product_shipping_price']=$ae->product_shipping_price;
                if(!empty($ae->product_img)){
                  $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
                }else{
                  $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
                }
                $data['product_status']=$ae->product_status;
                $data['featured_status']=$ae->featured_status;
                $data['discounted_products']=$ae->discounted_products;
                $data['new_products']=$ae->new_products;
                if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
                } else {
                    $data['stock_status']="Out of Stock";
                }
                $data['small_description']=$ae->small_description;
                $data['meta_title']=$ae->meta_title;
                $data['meta_desc']=$ae->meta_desc;
                $data['meta_keyword']=$ae->meta_keyword;
                
                $prodata[]=$data;
            }
            $datas['product_by_cat_detail']= $prodata;
            
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Category Product List","data" => $datas);
            echo  json_encode($response);
       }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Child Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }



  public function getallProduct()
  {
    //{"product_name":"product name"}
    //  $limit=$this->input->get('limit');
    //  $page=$this->input->get('page');
    $catdata = file_get_contents("php://input");
    file_put_contents('textfile/getcatproduct.txt',$catdata);
     
      $cat=json_decode($catdata, true);
      //$category_id=$cat['product_name'];
      $product_detail = $this->App_Model->getAllproduct();
      if (!empty($product_detail)) {
            foreach ($product_detail as $key => $ae) {

                $data['product_id']=$ae->product_id;
                $data['parent_product']=$ae->parent_product;
                $data['product_code']=$ae->product_code;
                $data['product_qty']=$ae->product_qty;
                $data['purchase_qty']=$ae->purchase_qty;
                $data['product_url']=$ae->product_url;
                $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
                $data['product_desc']=$ae->product_desc;
                $data['product_price']=$ae->product_price;
                $data['product_available']="Available";
                $data['product_mrp']=$ae->product_mrp;
                $data['product_shipping_price']=$ae->product_shipping_price;
                if(!empty($ae->product_img)){
                  $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
                }else{
                  $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
                }
                $data['product_status']=$ae->product_status;
                $data['featured_status']=$ae->featured_status;
                $data['discounted_products']=$ae->discounted_products;
                $data['new_products']=$ae->new_products;
                if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
                } else {
                    $data['stock_status']="Out of Stock";
                }
                $data['small_description']=$ae->small_description;
                $data['meta_title']=$ae->meta_title;
                $data['meta_desc']=$ae->meta_desc;
                $data['meta_keyword']=$ae->meta_keyword;
                
                $prodata[]=$data;
            }
            $datas['allproduct']= $prodata;
            
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Product List","data" => $datas);
            echo  json_encode($response);
       }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    
  }



  public function getchildProduct()
  {
    //{"product_id":"1","pincode":"800001"}
    $prodatas = file_get_contents("php://input");
    if($prodatas != null) {
      $pro=json_decode($prodatas, true);
     $product_id=$pro['product_id'];
      $product_detail = $this->App_Model->getChildProductForProductDetails($product_id);
      if (!empty($product_detail)) {
          foreach ($product_detail as $key => $ae) {

              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
            //   if (!empty($pro['pincode'])) {
            //       $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
            //       if (!empty($pricebypincode)) {
            //         $data['product_price']=$pricebypincode->product_price;
            //         $data['product_available']="Available";
            //       } else {
            //         $data['product_price']=$ae->product_price;
            //         $data['product_available']="Not Available";
            //       }
            //     }else{
            //       $data['product_available']="Available";
            //       $data['product_price']=$ae->product_price;
            //     }
                $data['product_price']=$ae->product_price;
                $data['product_available']="Available";
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
              if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              
              $prodata[]=$data;
          }
          $datas['get_child_product_detail']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Child Product list","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Child Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function getProductDetail()
  {
    //{"product_id":"1"}
    $prodatas = file_get_contents("php://input");
    if($prodatas != null) {
      $pro=json_decode($prodatas, true);
     $product_id=$pro['product_id'];
      $product_detail = $this->App_Model->getProductDetailbyid($product_id);
      if(!empty($product_detail)){
           $ae=$product_detail;
              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
              /* if (!empty($pro['pincode'])) {
                  $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
                  if (!empty($pricebypincode)) {
                    $data['product_price']=$pricebypincode->product_price;
                    $data['product_available']="Available";
                  } else {
                    $data['product_price']=$ae->product_price;
                    $data['product_available']="Not Available";
                  }
                }else{
                  $data['product_available']="Available";
                  $data['product_price']=$ae->product_price;
                }*/
              $data['product_price']=$ae->product_price;
              $data['product_available']="Available";
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
               if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              

          
          $datas['product_detail']= $data;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Product Detail","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function getProductGallery()
  {
    //{"product_id":"1","pincode":"800001"}
    $prodatas = file_get_contents("php://input");
    if($prodatas != null) {
      $pro=json_decode($prodatas, true);
     $product_id=$pro['product_id'];
      $product_photo = $this->App_Model->getProductPhoto($product_id);
      if(!empty($product_photo)){
          foreach ($product_photo as $key => $ae) {
            if(!empty($ae->image_name)){
              $data['product_img']=base_url().'uploads/product/'.$ae->image_name;
            }else{
              $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
            }
            $prodata[]=$data;
          }
          $datas['product_photo']=$prodata;

          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Product Gallery","data" => $datas);
          echo  json_encode($response);
      }else{
          $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Gallery Not Found","data" => "" );
          echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function getRelatedProduct()
  {
    //{"product_id":"1","pincode":"800001"}
    $prodatas = file_get_contents("php://input");
    if($prodatas != null) {
      $pro=json_decode($prodatas, true);
     $product_id=$pro['product_id'];
      $product_detail = $this->App_Model->getRelatedProduct($product_id);
      if(!empty($product_detail)){
           foreach ($product_detail as $key => $ae) {

              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
            //   if (!empty($pro['pincode'])) {
            //       $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
            //       if (!empty($pricebypincode)) {
            //         $data['product_price']=$pricebypincode->product_price;
            //         $data['product_available']="Available";
            //       } else {
            //         $data['product_price']=$ae->product_price;
            //         $data['product_available']="Not Available";
            //       }
            //     }else{
            //       $data['product_available']="Available";
            //       $data['product_price']=$ae->product_price;
            //     }
            $data['product_price']=$ae->product_price;
                    $data['product_available']="Available";
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
               if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              
              $prodata[]=$data;
          }
          $datas['related_product']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Related Product list","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function getNewProdict()
  {
     //{"pincode":"800001"}
      $prodatas = file_get_contents("php://input");
      $pro=json_decode($prodatas, true);


      $product_detail = $this->App_Model->getNewProdict();
      if(!empty($product_detail)){
           foreach ($product_detail as $key => $ae) {

              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
            //   if (!empty($pro['pincode'])) {
            //       $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
            //       if (!empty($pricebypincode)) {
            //         $data['product_price']=$pricebypincode->product_price;
            //         $data['product_available']="Available";
            //       } else {
            //         $data['product_price']=$ae->product_price;
            //         $data['product_available']="Not Available";
            //       }
            //     }else{
            //       $data['product_available']="Available";
            //       $data['product_price']=$ae->product_price;
            //     }
                $data['product_price']=$ae->product_price;
                    $data['product_available']="Available";
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
               if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              
              $prodata[]=$data;
          }
          $datas['new_product']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "New Product List","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
  }
  public function getDiscountedProdict()
  {
     //{"pincode":"800001"}
      $prodatas = file_get_contents("php://input");
      $pro=json_decode($prodatas, true);
      $product_detail = $this->App_Model->getDiscountedProdict();
      if(!empty($product_detail)){
           foreach ($product_detail as $key => $ae) {

              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
             
            //   if (!empty($pro['pincode'])) {
            //       $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
            //       if (!empty($pricebypincode)) {
            //         $data['product_price']=$pricebypincode->product_price;
            //         $data['product_available']="Available";
            //       } else {
            //         $data['product_price']=$ae->product_price;
            //         $data['product_available']="Not Available";
            //       }
            //     }else{
            //       $data['product_available']="Available";
            //       $data['product_price']=$ae->product_price;
            //     }
              $data['product_price']=$ae->product_price;
                    $data['product_available']="Not Available";
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
               if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              
              $prodata[]=$data;
          }
          $datas['discounted_product']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Discounted Product List","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
  }
  public function getSalesProdict()
  {
      //{"pincode":"800001"}
      $prodatas = file_get_contents("php://input");
      $pro=json_decode($prodatas, true);
      $product_detail = $this->App_Model->getSalesProdict();
      if(!empty($product_detail)){
           foreach ($product_detail as $key => $ae) {

              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
            //   if (!empty($pro['pincode'])) {
            //       $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
            //       if (!empty($pricebypincode)) {
            //         $data['product_price']=$pricebypincode->product_price;
            //         $data['product_available']="Available";
            //       } else {
            //         $data['product_price']=$ae->product_price;
            //         $data['product_available']="Not Available";
            //       }
            //     }else{
            //       $data['product_available']="Available";
            //       $data['product_price']=$ae->product_price;
            //     }
            $data['product_available']="Available";
                  $data['product_price']=$ae->product_price;
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
               if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              
              $prodata[]=$data;
          }
          $datas['sales_product']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Sales Product List","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
  }
  public function addpincodeForSearch()
  {
      //{"pincode":"800001"}
    $pincode = file_get_contents("php://input");
    if($pincode != null) {
        $pin=json_decode($pincode, true);
        $pincode=$pin['pincode'];
        if(!empty($pincode)){
          $data=$this->db->select('*')->where('bra_zip',$pincode)->get('kh_branch')->row();
          if(!empty($data)){
              $this->session->set_userdata('pincode',$pincode);
              $response = array("status_code" =>200 ,  "status" => "success" ,"message" => "Pincode Service Available","data" => $pincode );
              echo json_encode($response);
          }else{
            $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "The pincode ".$pincode." is not servicable.","data" => "" );
            echo json_encode($response);
          }
        }else{
           $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Please Enter Pincode","data" => "" );
          echo  json_encode($response);
        }
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
        echo  json_encode($response);
        
      }
  }
  public function searchProduct()
  {
    //{"product_name":"name"}
    $prodatas = file_get_contents("php://input");
    file_put_contents('textfile/searchsingle_product.txt',$prodatas);
    if($prodatas != null) {
      $pro=json_decode($prodatas, true);
      @$search=$pro['product_name'];
 
       $product_detail = $this->App_Model->getProductBySearch($search);
      if(!empty($product_detail)){
           foreach ($product_detail as $key => $ae) {

              $data['product_id']=$ae->product_id;
              $data['parent_product']=$ae->parent_product;
              $data['product_code']=$ae->product_code;
              $data['product_qty']=$ae->product_qty;
              $data['purchase_qty']=$ae->purchase_qty;
              $data['product_url']=$ae->product_url;
              $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
              $data['product_desc']=$ae->product_desc;
              $data['product_available']="Available";
                  $data['product_price']=$ae->product_price;
              $data['product_mrp']=$ae->product_mrp;
              $data['product_shipping_price']=$ae->product_shipping_price;
              if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              $data['product_status']=$ae->product_status;
              $data['featured_status']=$ae->featured_status;
              $data['discounted_products']=$ae->discounted_products;
              $data['new_products']=$ae->new_products;
               if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
              } else {
                    $data['stock_status']="Out of Stock";
              }
              $data['small_description']=$ae->small_description;
              $data['meta_title']=$ae->meta_title;
              $data['meta_desc']=$ae->meta_desc;
              $data['meta_keyword']=$ae->meta_keyword;
              
              $prodata[]=$data;
          }
          $datas['searchProductData']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Search Product list","data" => $datas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
   public function productsuggestions()
  {
    //{"product_name":"name"}
    $prodatas = file_get_contents("php://input");
    if($prodatas != null) {
      $pro=json_decode($prodatas, true);
      @$search=$pro['product_name'];
      $product_detail = $this->App_Model->getSuggestions($search);
      
      if(!empty($product_detail)){
           foreach ($product_detail as $key => $ae) {
              $data['product_name']=$ae->product_name;
              
               if(!empty($ae->product_img)){
                $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
              }else{
                $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
              
              $prodata[]=$data;
            }
          $dataaaaas['product_suggestions']= $prodata;
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Search Product list","data" => $dataaaaas);
          echo  json_encode($response);
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  ///// user checkout address///////////
  public function getsaveAddress_checkout()
  {
    //{"user_id":"1"}

     $limit=$this->input->get('limit');
    $page=$this->input->get('page');
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $userId=$user['user_id'];
    //   $pincode=$user['pincode'];
      $profile_detail = $this->App_Model->getSaveAddress($userId,$limit,$page);
      
      $data['save_address']= $profile_detail;
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "User Save Address","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }


  /////////////user profile////////////////
  public function getsaveAddress()
  {
    //{"user_id":"1"}
     $limit=$this->input->get('limit');
    $page=$this->input->get('page');
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $userId=$user['user_id'];
    //   $pincode=$user['pincode'];
      $profile_detail = $this->App_Model->getSaveAddress($userId,$limit,$page);
      
      $data['save_address']= $profile_detail;
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "User Save Address","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }

   public function deletesaveaddress()
  {
    //{"address_id":"1"}
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $addressid=$user['address_id'];
      $this->db->where('id',$addressid);
      $this->db->delete('kh_save_address');
        
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Address Delete Successfully!!","data" => "");
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function addAddress()
  {
    //{    "user_id": "1",    "firstname": "Infutive",    "phone": "8851075293",    "email": "test.developer@gmail.com",    "state": "Delhi",    "city": "New Delhi",    "address": "Dwarka, New Delhi, Delhi, India",    "zipcode": "800001",    "usergst": "123test",    "usershop": "test"}
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $userid=$user['user_id'];
      $firstname=$user['firstname'];
      $phone=$user['phone'];
      $email=$user['email'];
      $state=$user['state'];
      $city=$user['city'];
      $address=$user['address'];
      $zipcode=$user['zipcode'];
      $usergst=$user['usergst'];
      $usershop=$user['usershop'];
      $id=$this->App_Model->adduseraddress($userid,$firstname,$phone,$email,$state,$city,$address,$zipcode,$usergst,$usershop);
      $this->db->where('id',$id);
      $query=$this->db->get('kh_save_address')->row();

      $data['address']=$query;
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Address Added Successfully!!","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
   public function updateSaveAddress()
  {
    //{"address_id":"10","firstname":"Infutive","phone":"8851075293","email":"dev.developer@gmail.com","state":"Delhi","city":"New Delhi","address":"Dwarka, New Delhi, Delhi, India","zipcode":"800001"}
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $firstname=$user['firstname'];
      $phone=$user['phone'];
      $email=$user['email'];
      $state=$user['state'];
      $city=$user['city'];
      $address=$user['address'];
      $zipcode=$user['zipcode'];
      $usergst=$user['usergst'];
      $usershop=$user['usershop'];
      $address_id=$user['address_id'];
      $this->App_Model->updateEditaddress($firstname,$phone,$email,$state,$city,$address,$zipcode,$usergst,$usershop,$address_id);
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Address Updated Successfully!!","data" => $user);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function applyCouponCode()
  {
    //{"coupon_code":"10","totalAmount":"1000"} 
    $couponCodes = file_get_contents("php://input");
    if($couponCodes != null) {

          $couCode=json_decode($couponCodes, true);
          $couponCode = $couCode['coupon_code']; 

          if($couponCode!=NULL && $couponCode!="")
          {
            $responseData = $this->App_Model->getCouponInfo($couponCode);
            
            if($responseData!=NULL)
            {
            
                 $totalAmount=$couCode['totalAmount']; 
              if($responseData->coupon_discount_type==0)
              {
                //echo $totalAmount; die();
                if($responseData->coupon_minimun_limit > $totalAmount)
                {
                    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Coupon Code Not Valid !!","data" => "");
                     echo  json_encode($response);
                }else{
                    $calDiscountAmount = round(($totalAmount * $responseData->coupon_discount_value) / 100);
                    $finalAmount = round(($totalAmount - $calDiscountAmount));
                     
                  
    
                    $couponDiscountAmount = $responseData->coupon_discount_value;

                    $data['discountCouponAmount']  = $calDiscountAmount;                    
                    $data['discountAmount']  = $finalAmount;                    
                    $data['applied_coupon']  = $couponCode;
                    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Coupon $couponCode Applied Successfully !!","data" => $data);
                    echo  json_encode($response);
                }
              }
              else
              {
                  
                if($responseData->coupon_minimun_limit > $totalAmount)
                {
                    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Coupon Code Not Valid !!","data" => "");
                    echo  json_encode($response);
                }else{
                    $finalAmount = round($totalAmount - $responseData->coupon_discount_value);
                    
                    $couponDiscountAmount = $responseData->coupon_discount_value;
                    
                    $data['discountCouponAmount']  = $couponDiscountAmount;                    
                    $data['discountAmount']  = $finalAmount;                    
                    $data['applied_coupon']  = $couponCode;
                    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Coupon $couponCode Applied Successfully !!","data" => $data);
                    echo  json_encode($response);
                }
               
              }
            }
            else
            {
               $response = array("status_code" =>200 ,  "status" => "success", "message" => "Coupon Code Not Valid !!","data" => "");
                    echo  json_encode($response);
            }
             
          }
          
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
   public function deletecartitem()
  {
    //{"user_id":"10","product_id":"1"}
    $delete = file_get_contents("php://input");
    if($delete != null) {
       $de=json_decode($delete, true);
      $this->db->where('user_id',$de['user_id']);
      $this->db->where('product_id',$de['product_id']);
      $this->db->delete('kh_cart');
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Data Delete Successfully!!","data" => "");
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function getcarttotal()
  {
      //{"user_id":"1"}
    $gettotal = file_get_contents("php://input");
    if($gettotal != null) {
       $total=json_decode($gettotal, true);
      $this->db->select_sum('price');
      $this->db->where('user_id',$total['user_id']);
      $this->db->where('cart_status',1);
      $sumdata=$this->db->get('kh_cart')->row();
      
      $data['cart_total']=$sumdata->price;
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Total Amount","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
  
  public function getcarttotalgst()
  {
      //{"user_id":"1"}
    $gettotalgst = file_get_contents("php://input");
    if($gettotalgst != null) {
       $total=json_decode($gettotalgst, true);
      $this->db->select_sum('gst');
      $this->db->where('user_id',$total['user_id']);
      $this->db->where('cart_status',1);
      $sumdata=$this->db->get('kh_cart')->row();
      
      $data['cart_total_gst']=number_format($sumdata->gst,2);
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Total GST Amount","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }

  public function getcartorderamount()
  {
      //{"user_id":"1"}
    $gettotalprice = file_get_contents("php://input");
    if($gettotalprice != null) {
       $total=json_decode($gettotalprice, true);
      $this->db->select_sum('price');
      $this->db->where('user_id',$total['user_id']);
      $this->db->where('cart_status',1);
      $sumdata=$this->db->get('kh_cart')->row();
      
      $data['cart_total_order_price']=number_format($sumdata->price,2);
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Total Order Amount","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }


   public function addtocart()
  {
   
    $cartData = file_get_contents("php://input");
    //file_put_contents('textfile/addtocarta.txt', $cartData);
    if($cartData != null) {
      $carts=json_decode($cartData, true);
       $this->db->where('user_id',$carts['data'][0]['user_id']);
       $this->db->where('cart_status',1);
       $this->db->delete('kh_cart');
      
     // print_r($carts['data']); die();
      foreach ($carts['data'] as $key => $cart) {
            $id=$cart['product_id']; 
            $product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $cart['product_name']);
            //$amount=$cart['product_price'];
            $pricebypincode=$this->App_Model->getPriceBypinCode($cart['product_id'],$cart['pincode']); 
             if(!empty($pricebypincode)){ 
              $amount=$pricebypincode->product_price; 
            }else{  
                //$product_price=$items['price'];
                $propriceforcart=$this->App_Model->getproductpriceforcart($cart['product_id']);
                $amount=$propriceforcart->product_price;
            }
            
            if (!empty($cart['quantity'])) {
              $quantity= $cart['quantity'];
            }else{
              $quantity=  "1";
            }
            
            $gst= (18 /100) * $amount * $quantity;
            $price=$amount * $quantity;
            $user_id=$cart['user_id'];
            
            $amountwithgst= $amount + $gst;
            $data = array( 
              'product_id'  => $id,
              'qty'         => $quantity,
              'name'      => $product_name,
              'price'       => $price,
              'one_price'   => $amount,
              'gst'       => $gst,
              'amountwithgst' => $amountwithgst,
              'user_id'       => $user_id
            );
            $this->db->insert('kh_cart',$data);
      }
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Add To Cart Successfully","data" => "");
      echo  json_encode($response);
    }
  }
  
  
 public function addtocartas()
  {
    //{"user_id":"539","product_id":"244","pincode":"800001","quantity":"1","product_price":"78","product_name":"Stayfree Secure Regular Cotton 20 Pads 1 Pc"}

   // {"status_code":200,"status":"success","message":"Insert Cart Data","data":[{"user_id":"539","product_id":"244","pincode":"800001","quantity":"1","product_price":"78","product_name":"Stayfree Secure Regular Cotton 20 Pads 1 Pc"},{"user_id":"539","product_id":"244","pincode":"800001","quantity":"1","product_price":"78","product_name":"Stayfree Secure Regular Cotton 20 Pads 1 Pc"}]}
    
    $cartData = file_get_contents("php://input");
    file_put_contents('textfile/addtocart.txt', $cartData);
    if($cartData != null) {
      $carts=json_decode($cartData, true);
     // print_r($carts['data']); die();
  foreach ($carts['data'] as $key => $cart) {
      if ($cart['user_id'] != null) {
          $this->db->where('product_id',$cart['product_id']);
          $this->db->where('user_id',$cart['user_id']);
          $this->db->where('cart_status',1);
          $cartid=$this->db->get('kh_cart')->row();
          
          
        // $productstock=$this->db->where('product_id',$cart['product_id'])->where('stock_status',1)->get('kh_product')->row();
          

        // if(!empty($productstock)){
        
          if(!empty($cartid)){
            @$zipcode=$cart['pincode'];
                  $pricebypincode=$this->App_Model->getPriceBypinCode($cart['product_id'],$zipcode); 

                  if(!empty($pricebypincode)  AND $pricebypincode->offerQty != 0){ 
                    //$checkquantity= $cartid->qty + $cart['quantity']; 
                      if ($cart['quantity'] > $pricebypincode->offerQty) {
                         $response = array("status_code" =>200 ,  "status" => "success", "message" => "We're sorry! Only ".$pricebypincode->offerQty." unit(s) for each customer","data" => "");
                          echo  json_encode($response);
                      }else{
                        //$quantity= $cartid->qty + $cart['quantity'];
                        $quantity=$cart['quantity'];
                        $amount = $cartid->one_price * $quantity;

                        $gst= (18 /100) * $amount;
                      
                        $amountwithgst= $amount + $gst;
                        $this->db->set('price',$amount);
                        $this->db->set('gst',$gst);
                        $this->db->set('amountwithgst',$amountwithgst);
                        $this->db->set('qty',$quantity);
                        $this->db->where('product_id',$cart['product_id']);
                        $this->db->where('user_id',$cart['user_id']);
                        $this->db->where('cart_status',1);
                        $this->db->update('kh_cart');
                        $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Update Successfully","data" => "");
                        echo  json_encode($response);
                      }
                  }else{
                    //$quantity= $cartid->qty + $cart['quantity']; 
                    $quantity= $cart['quantity']; 
                    $amount = $cartid->one_price * $quantity;

                    $gst= (18 /100) * $amount;
                  
                    $amountwithgst= $amount + $gst;
                    $this->db->set('price',$amount);
                    $this->db->set('gst',$gst);
                    $this->db->set('amountwithgst',$amountwithgst);
                    $this->db->set('qty',$quantity);
                    $this->db->where('product_id',$cart['product_id']);
                    $this->db->where('user_id',$cart['user_id']);
                    $this->db->where('cart_status',1);
                    $this->db->update('kh_cart');

                    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Update Successfully","data" => "");
                    echo  json_encode($response);
                  }
          } else{
            @$zipcode=$cart['pincode'];
                  $pricebypincode=$this->App_Model->getPriceBypinCode($cart['product_id'],$zipcode); 

                  if(!empty($pricebypincode)  AND $pricebypincode->offerQty != 0){ 
                    $checkquantity=$cart['quantity'];  
                      if ($checkquantity > $pricebypincode->offerQty) {
                     
                           $response = array("status_code" =>200 ,  "status" => "success", "message" => "We're sorry! Only ".$pricebypincode->offerQty." unit(s) for each customer","data" => "");
                          echo  json_encode($response);
                      }else{
                        $id=$cart['product_id']; 
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $cart['product_name']);
                        $amount=$cart['product_price'];
                        if (!empty($cart['quantity'])) {
                          $quantity= $cart['quantity'];
                        } else {
                          $quantity=  "1";
                        }
                        
                        $gst= (18 /100) * $amount * $quantity;
                        $price=$amount * $quantity;
                        $user_id=$cart['user_id'];

                        $amountwithgst= $amount + $gst;
                        $data = array( 
                          'product_id'  => $id,
                                'qty'         => $quantity,
                                'name'      => $product_name,
                                'price'       => $price,
                                'one_price'   => $amount,
                                'gst'       => $gst,
                                'amountwithgst' => $amountwithgst,
                                'user_id'       => $user_id
                        );
                        $this->db->insert('kh_cart',$data);
                        $response = array("status_code" =>200 ,  "status" => "success", "message" => "Add To Cart Successfully","data" => "");
                        echo  json_encode($response);
                      }
                  }else{
                    $id=$cart['product_id'];
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $cart['product_name']);
                    $amount=$cart['product_price'];
                    if (!empty($cart['quantity'])) {
                      $quantity= $cart['quantity'];
                    } else {
                      $quantity=  "1";
                    }
                    
                    $gst= (18 /100) * $amount * $quantity;
                    $price=$amount * $quantity;
                    $user_id=$cart['user_id'];

                    $amountwithgst= $amount + $gst;
                    $data = array( 
                            'product_id'  => $id,
                            'qty'         => $quantity,
                            'name'        => $product_name,
                            'price'       => $price,
                            'one_price'   => $amount,
                            'gst'         => $gst,
                            'amountwithgst' => $amountwithgst,
                            'user_id'       => $user_id
                    );
                    $this->db->insert('kh_cart',$data);
                    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Add To Cart Successfully","data" => "");
                    echo  json_encode($response);
                  }
          }
        //}

      } else {
           $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "User ID Send User Id","data" => "" );
          echo  json_encode($response); 
      }


    }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  


public function checkproductstock()
  {
       // {"data":[{"product_id":"244","qty":"1"},{"product_id":"248","qty":"1"}]}

            $cartData = file_get_contents("php://input");
        if($cartData != null) {
              $carts=json_decode($cartData, true);
             // print_r($carts['data']); die();
            foreach ($carts['data'] as $key => $cart) {
                 $productstock=$this->db->where('product_id',$cart['product_id'])->where('stock_status',1)->get('kh_product')->row();
                 $data['product_id']=$cart['product_id'];
                 if(!empty($productstock)){
                     $data['stock_status']="In Stock";
                 }else{
                     $data['stock_status']="Out Of Stock";
                 }
                $cartDataa[]=$data;
            } 

            $cartsss=$cartDataa;
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Check Product Stock","data" => $cartsss);
            echo  json_encode($response);
        }else{
          $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
          echo  json_encode($response);
        }
          
  }
  
  
  public function getCartData()
  {
    //{"user_id":"1","pincode":"800001"}
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);

        $userid=$user['user_id'];
        // $dataasdfs['cartDataa']=$this->App_Model->getCartList($userid);
        // $cartdata=$dataasdfs['cartDataa'];

        // foreach ($cartdata as $key => $ae) {
        //   @$zipcode=$user['pincode'];
        //           $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$zipcode); 
        //           if(!empty($pricebypincode)){ 
        //             $product_price=$pricebypincode->product_price; 
        //           }else{  
        //             $product_price=$ae->one_price;
        //           }

        //           $gst= (18 /100) * $product_price * $ae->qty;
        //           $amountwithgst=$product_price * $ae->qty;

        //               $this->db->set('product_id',$ae->product_id);
        //               $this->db->set('qty',$ae->qty);
        //               $this->db->set('name',$ae->name);
        //               $this->db->set('price',$product_price * $ae->qty);
        //               $this->db->set('one_price',$product_price);
        //               $this->db->set('gst',$gst);
        //               $this->db->set('amountwithgst',$amountwithgst);
        //               $this->db->where('user_id',$userid);
        //           $this->db->where('cart_id',$ae->cart_id);
        //           $this->db->update('kh_cart');

        //           $checkOutofstaock=$this->App_Model->getProductStatusforOutOfstork($ae->product_id);
        //           if($checkOutofstaock->stock_status == 0){
        //             $this->db->where('product_id',$ae->product_id);
        //             $this->db->where('user_id',$userid);
        //             $this->db->delete('kh_cart');
        //           }
        // }
        $allcartdata=$this->App_Model->getCartList($userid);

        foreach ($allcartdata as $key => $value) {
            $data['cart_id'] = $value->cart_id;
            $data['user_id'] = $value->user_id;
            $data['product_id'] =$value->product_id;
            $product_detail = $this->App_Model->getProductDetailbyid($value->product_id);
            if(!empty($product_detail->product_img)){
              $data['product_img']=base_url().'uploads/product/'.$product_detail->product_img;
            }else{
              $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
            }
            $data['qty'] =$value->qty;
            $data['name'] =$product_detail->product_name;
            $data['purchase_qty'] =$product_detail->purchase_qty;
            $data['price'] =$value->price;
            $data['one_price'] =$value->one_price;
            $data['gst'] =$value->gst;
            $data['amountwithgst'] =$value->amountwithgst;
            $data['cart_status'] =$value->cart_status;
            $data['status'] =$value->status;
            $data['created'] =$value->created;
            
            $cartData[]=$data;
        } 

      $carts=$cartData;
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Get Uesr Cart Data","data" => $carts);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }


  public function insertordernow()
  {
    //{"delivery": "0","gstnmber":"","firstname": "fvb","address": "fjjk","city": "fhk","zipcode": "800001","totalAmount": "1257.0","payment_type": "1","user_id": "1","phone": "8899585869","state": "fgo","email": "test@test.com","order_product": [{"user_id": "1","product_id": "3","quantity": "1","product_price": "185","product_name": "Aashirvaad Chakki Atta 5 kg"}]}
    $orderdata=file_get_contents("php://input");
    file_put_contents('textfile/new_order.txt', $orderdata);
    if($orderdata != null)
    {
      //echo $orderdata; die();
      $order=json_decode($orderdata, true);
      //print_r($order['user_id']); die;
      if (!empty($order['user_id']) AND  !empty($order['totalAmount']) AND !empty($order['firstname']) AND !empty($order['email']) AND !empty($order['payment_type'])){

        // print_r($order['order_product']); die;

        $orderid = $this->App_Model->insertorder($order['user_id'],$order['delivery'],$order['totalAmount'],$order['firstname'],$order['email'],$order['phone'],$order['state'],$order['city'],$order['address'],$order['zipcode'],$order['payment_type'],$order['order_product'],$order['gstnmber']);
          if ($order['payment_type'] == 1) {
                
                ////////////////////mail /////////////////////////


                $data['getOrderData']=$this->App_Model->getOrderData($orderid);
                $data['itemList']=$this->App_Model->getOrderItemFromCheckout($orderid);
                $mailBox = $this->load->view('template/checkoutinvoice',$data,true);
                
                $email=$data['getOrderData']->order_email;
                $amount=$data['getOrderData']->order_amount;
                $orderuniquecode=$data['getOrderData']->order_unique_code;
                $name=$data['getOrderData']->order_firstname;
                $mobileNum=$data['getOrderData']->order_phone;
                // ///////////////////////mail//////////////////
                // $config['protocol'] = 'sendmail';
                // $config['mailpath'] = '/usr/sbin/sendmail';
                // $config['charset'] = 'utf-8';
                // $config['wordwrap'] = TRUE;
                // $config['mailtype'] = 'html';
               
                // $this->email->initialize($config);
                
                // $this->load->library('email');
                
                // $this->email->reply_to('contact@rollsking.com', 'rollsking.com');
                 
                // $this->email->from('contact@rollsking.com', 'rollsking.com');
                // $this->email->to($email);
                // $this->email->cc('contact@rollsking.com');
                // $this->email->bcc('report@infutive.com');
                // $this->email->subject("Order Invoice: rollsking.com");
                // $this->email->message($mailBox);
                // $this->email->send();



                $sms="order Create Successfully";


                $this->db->set('user_id',$order['user_id']);
                $this->db->set('notification',$sms);
                $this->db->set('status',1);
                $this->db->insert('kh_notification');
                
                
                $userdatafornot=$this->db->select('*')->where('user_id',$order['user_id'])->get('kh_user_list')->row();
                $fcm_tokenss=$userdatafornot->fcm_token;
                $message=$sms;
                $fcmdata=$this->sendPushNotificationToFCMSever($fcm_tokenss, $message);
                //file_put_contents('textfile/fcm.txt', $fcmdata);
                
             
                
                // $this->db->where('user_id',$order['user_id']);
                // $this->db->delete('kh_cart');
             
             
                ////////////////End SMS/////////////////////

                $data['order_id']=$orderid;
                $data['order_unique_code']=$orderuniquecode;

                $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Order Created Successfully, Thank you","data"=> $data );
                echo  json_encode($response);
              }elseif ($order['payment_type']== 2) {
                $data['getOrderData']=$this->App_Model->getOrderData($orderid);
                $data['itemList']=$this->App_Model->getOrderItem($orderid);
                $orderuniquecode=$data['getOrderData']->order_unique_code;
                $data['order_id']=$orderid;
                $data['order_unique_code']=$orderuniquecode;
                $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Order Created Successfully, Thank you","data"=> $data );
                echo  json_encode($response);
              }
              elseif($order['payment_type']== 3){
                    $data['getOrderData']=$this->App_Model->getOrderData($orderid);
                    $data['itemList']=$this->App_Model->getOrderItem($orderid);
                    $orderuniquecode=$data['getOrderData']->order_unique_code;
                    $data['order_id']=$orderid;
                    $data['order_unique_code']=$orderuniquecode;
                    $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Order Created Successfully, Thank you","data"=> $data );
                    echo  json_encode($response);
              }
              else{
                
              }
      }
      else
      {
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "");
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
  ///checksumm genrate//////////
  public function makeOrderPaymentpaytm_checksum()
	{
	    
	  //  {
    // "orderId": "119",
    // "orderAmount": "7.93",
    // "user_id": "1",
    // "mobile_no": "1234567890",
    // "email": "dev.developer@gmail.com"
    // }
	     $PayTmValue = file_get_contents("php://input");
	     $valuespay=json_decode($PayTmValue, true);

	      require_once("assets/paytm/lib/config_paytm.php");
        require_once("assets/paytm/lib/encdec_paytm.php");
        $checkSum = "";
        
        // below code snippet is mandatory, so that no one can use your checksumgeneration url for other purpose .
        $checkSum = "";
        $paramList = array();
        
        $ORDER_ID = $valuespay['orderId'];
        $CUST_ID = $valuespay['user_id'];
        $INDUSTRY_TYPE_ID = "Retail";
        $CHANNEL_ID = "WAP";
        $TXN_AMOUNT = $valuespay['orderAmount'];
        
        // Create an array having all required parameters for creating checksum.
        $paramList["MID"] = 'YUGBIT86450645116329';
        $paramList["ORDER_ID"] = $ORDER_ID;
        $paramList["CUST_ID"] = $CUST_ID;
        $paramList["INDUSTRY_TYPE_ID"] = $INDUSTRY_TYPE_ID;
        $paramList["CHANNEL_ID"] = $CHANNEL_ID;
        $paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
        //$paramList["WEBSITE"] = 'DEFAULT';
        $paramList["WEBSTAGING"] = 'DEFAULT';
        
        
        $paramList["CALLBACK_URL"] = "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID=".$valuespay['orderId'];
        //$paramList["CALLBACK_URL"] = "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=".$valuespay['orderId'];
        $paramList["MSISDN"] = $valuespay['mobile_no']; //Mobile number of customer
        $paramList["EMAIL"] = $valuespay['email']; //Email ID of customer
        /*$paramList["VERIFIED_BY"] = "EMAIL"; //
        $paramList["IS_USER_VERIFIED"] = "YES"; //
        
        */
        //print_r($paramList);
        //Here checksum string will return by getChecksumFromArray() function.
        $checkSum = getChecksumFromArray($paramList,'eEIWp_J4zd&OhoCs');
        //print_r($_POST);
         echo json_encode(array("CHECKSUMHASH" => $checkSum,"ORDER_ID" => $valuespay['orderId'], "payt_STATUS" => "1"),JSON_UNESCAPED_SLASHES);
	}
	
	
  public function makeOrderPayment()
  {
    //{
    //     "merchant_order_id": "1",
    //     "merchant_trans_id": "1",
    //     "merchant_product_info_id": "1",
    //     "card_holder_name_id": "asdf",
    //     "merchant_amount": "7010"
    // }
    $orderpayment=file_get_contents("php://input");
    file_put_contents('textfile/makeOrderPayment.txt',$orderpayment);
    if(!empty($orderpayment)){
      $payment=json_decode($orderpayment, true);
      if ($payment !=null) 
      {
    
		$data= array(
			'order_id' => $payment['merchant_order_id'],
			'trans_id' => $payment['merchant_trans_id'],
			'product_info_id' => $payment['merchant_product_info_id'],
			'card_holder_name_id' => $payment['card_holder_name_id'],
			'merchant_amount' => $payment['merchant_amount'],
			'payment_status' => 1
		);
		 $this->db->insert('kh_order_payment',$data);
   //print_r($data);die;

    $this->db->set("order_payment_status",1);
		$this->db->where('order_payment_id',$payment['merchant_trans_id']);
		$this->db->update("kh_order_tb");
    //  print_r($data);die;

		// $this->db->set("order_payment_status",1);
		// $this->db->where('order_id',$payment['merchant_order_id']);
		// $this->db->update("kh_order_checkout_tb");
		
		
		            $orderid=$payment['merchant_order_id'];
		
	        	    $data['getOrderData']=$this->App_Model->getOrderData($orderid);
                $data['itemList']=$this->App_Model->getOrderItemFromCheckout($orderid);
                $mailBox = $this->load->view('template/checkoutinvoice',$data,true);
                
                $email=$data['getOrderData']->order_email;
                $amount=$data['getOrderData']->order_amount;
                $orderuniquecode=$data['getOrderData']->order_unique_code;
                $name=$data['getOrderData']->order_firstname;
                $mobileNum=$data['getOrderData']->order_phone;
                ///////////////////////mail//////////////////
                // $config['protocol'] = 'sendmail';
                // $config['mailpath'] = '/usr/sbin/sendmail';
                // $config['charset'] = 'utf-8';
                // $config['wordwrap'] = TRUE;
                // $config['mailtype'] = 'html';
               
                // $this->email->initialize($config);
                
                // $this->load->library('email');
                
                // $this->email->reply_to('contact@rollsking.com', 'rollsking.com');
                 
                // $this->email->from('contact@rollsking.com', 'rollsking.com');
                // $this->email->to($email);
                // $this->email->cc('contact@rollsking.com');
                // $this->email->bcc('report@infutive.com');
                // $this->email->subject("Order Invoice: rollsking.com");
                // $this->email->message($mailBox);
                // $this->email->send();




	
      
        $data['order_id']=$payment['merchant_order_id'];

        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Payment Add Successfully.","data"=> $data );
        echo  json_encode($response);
      } else {
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
      echo  json_encode($response);
    }
  }

  public function getorderlist()
  {
    //{"user_id":"1"}
    
     $limit=$this->input->get('limit');
    $page=$this->input->get('page');
    $userid=file_get_contents("php://input");
    file_put_contents('textfile/getorderlist.txt',$userid);
    if($userid != null){
      $userid=json_decode($userid, true);
      $orderlist=$this->App_Model->orderDatas($userid['user_id'],$limit,$page);

      if (!empty($orderlist)) {
      $k=0;
      foreach($orderlist as $order) 
      {
        
        $orderLoad = (array) $order;
       
        $orderLoad['order_id']=  $order->order_id;
        $orderLoad['order_unique_code']=  $order->order_unique_code;
        $orderLoad['order_payment_id']=  $order->order_payment_id;
        $orderLoad['order_userid']=  $order->order_userid;
        $orderLoad['order_applied_coupon']=  $order->order_applied_coupon;
        $orderLoad['order_discount_amount']=  $order->order_discount_amount;
        $orderLoad['order_delivery']=  $order->order_delivery;
        $orderLoad['order_collection_type']=  $order->order_collection_type;
        $orderLoad['order_amount']=  $order->order_amount;
        $orderLoad['gstnmber']=  $order->gstnmber;
        // $orderLoad['order_amount_with_tax']=  $order->order_amount_with_tax;
        $orderLoad['order_wallet_amount']=  $order->order_wallet_amount;
        $orderLoad['order_firstname']=  $order->order_firstname;
        $orderLoad['order_lastname']=  $order->order_lastname;
        $orderLoad['order_email']=  $order->order_email;
        $orderLoad['order_phone']=  $order->order_phone;
        $orderLoad['order_state']=  $order->order_state;
        $orderLoad['order_city']=  $order->order_city;
        $orderLoad['order_address']=  $order->order_address;
        $orderLoad['order_zipcode']= $order->order_zipcode;
      
        if($order->order_payment_status ==0){
           $orderLoad['payment_status']="Pending";
        }else{
           $orderLoad['payment_status']="Paid";
        }
        if ($order->payment_type == 1) {
           $orderLoad['payment_type']= "COD";
        } else {
           $orderLoad['payment_type']= "Online";
        }
      
        if($order->order_status == 0){
          $orderLoad['order_status']= "Cancelled By User";
        }elseif ($order->order_status == 1) {
          $orderLoad['order_status']= "Order Process";
        }elseif ($order->order_status == 2) {
          $orderLoad['order_status']= "Order Packed";
        }elseif ($order->order_status == 3) {
          $orderLoad['order_status']= "Order Shipped";
        }elseif ($order->order_status == 4) {
          $orderLoad['order_status']= " Order Delivered";
        }elseif ($order->order_status == 5) {
          $orderLoad['order_status']= "Order Done";
        }elseif ($order->order_status == 6) {
          $orderLoad['order_status']= "Cancelled By Admin";
        }else{
          $orderLoad['order_status']= "Not Status";
        }
        $orderLoad['order_created']= $order->order_created; 

        $k++;
        $orderitem=$this->App_Model->getOrderItemForOrderList($userid['user_id'],$order->order_id);
        
        
        //$orderLoad['orderItem'] = $orderitem;
        
        foreach($orderitem as $orderit){
            $orderL['item_id']=$orderit->item_id;
            $orderL['order_id']=$orderit->order_id;
            //$orderL['cart_id']=$orderit->cart_id;
            $orderL['user_id']=$orderit->user_id;
            $orderL['product_id']=$orderit->product_id;
            $product=$this->App_Model->getProductDetailbyid($orderit->product_id);
            if(!empty($product->product_img)){
                $orderL['product_img']=base_url().'uploads/product/'.$product->product_img;
              }else{
                $orderL['product_img']=base_url().'admin_assets/img/no-image-icon.png';
              }
            $orderL['one_price']=$orderit->one_price;
            $orderL['qty']=$orderit->qty;
            $orderL['name']=$orderit->name;
            $orderL['code']=$orderit->code;
            $orderL['price']=$orderit->price;
            // $orderL['gst']=$orderit->gst;
            // $orderL['amountwithgst']=$orderit->amountwithgst;
            $orderL['status']=$orderit->status;
            $orderL['created']=$orderit->created;
            
            $orderLoad['orderItem'][] = $orderL;
        }
        
        
        
        // $orderlistArray[] = array($orderLoad, "orderItem" => $orderitem);
        $orderlistArray[] = $orderLoad;
        // $orderlistArray[$k]["orderItem"]=$orderitem;
      }
      
        $data["orderlist"] = $orderlistArray;

        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"User Order List","data"=> $data );
        echo  json_encode($response);
      } else {
        $response = array("status_code" =>201 ,  "status" => "success", "message" => "Order List Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
  public function reorder()
  {
    //{"order_id":"1","pincode":"800001"}
    $orderdata=file_get_contents("php://input");
    if($orderdata != null){
      $order=json_decode($orderdata, true);
      $orderlist=$this->App_Model->getOrderItemForProductList($order['order_id']);
        //print_r($orderlist); die;
     
          foreach($orderlist as $orders) 
          {
            $ae = $this->App_Model->getProductDetailbyid($orders->product_id);
                  $datai['product_id']=$ae->product_id;
                  $datai['parent_product']=$ae->parent_product;
                  $datai['product_code']=$ae->product_code;
                  $datai['product_qty']=$ae->product_qty;
                  $datai['purchase_qty']=$ae->purchase_qty;
                  $datai['product_url']=$ae->product_url;
                  $datai['product_name']=$ae->product_name.' '.$ae->purchase_qty;
                  $datai['product_desc']=$ae->product_desc;
                //   if (!empty($pro['pincode'])) {
                //       $pricebypincode=$this->App_Model->getPriceBypinCode($ae->product_id,$pro['pincode']);
                //       if (!empty($pricebypincode)) {
                //         $datai['product_price']=$pricebypincode->product_price;
                //         $datai['product_available']="Available";
                //       } else {
                //         $datai['product_price']=$ae->product_price;
                //         $datai['product_available']="Not Available";
                //       }
                //     }else{
                //       $datai['product_available']="Available";
                //       $datai['product_price']=$ae->product_price;
                //     }
                  $datai['product_available']="Available";
                  $datai['product_price']=$ae->product_price;
                  $datai['product_mrp']=$ae->product_mrp;
                  $datai['product_shipping_price']=$ae->product_shipping_price;
                  if(!empty($ae->product_img)){
                    $datai['product_img']=base_url().'uploads/product/'.$ae->product_img;
                  }else{
                    $datai['product_img']=base_url().'admin_assets/img/no-image-icon.png';
                  }
                  $datai['product_status']=$ae->product_status;
                  $datai['featured_status']=$ae->featured_status;
                  $datai['discounted_products']=$ae->discounted_products;
                  $datai['new_products']=$ae->new_products;
                   if ($ae->stock_status == 1) {
                        $datai['stock_status']="In Stock";
                  } else {
                        $datai['stock_status']="Out of Stock";
                  }
                  $datai['small_description']=$ae->small_description;
                  $datai['meta_title']=$ae->meta_title;
                  $datai['meta_desc']=$ae->meta_desc;
                  $datai['meta_keyword']=$ae->meta_keyword;
                  
                  
                  $datas[]= $datai;
          }
        
        $data["product_list"] = $datas;

        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Order Product List","data"=> $data );
        echo  json_encode($response);
     
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }


  public function cancelOrder()
  {
    //{"order_id":"833","user_id":"1"}
    $orderid=file_get_contents("php://input");
    if($orderid != null){
      $order=json_decode($orderid, true);
      if ($order['order_id'] && $order['user_id']) {
          $orderid=json_decode($orderid, true);
    
          $getOrderData=$this->App_Model->getOrderData($order['order_id']);
          $orderuniquecode=$getOrderData->order_unique_code;
          $mobileNum=$getOrderData->order_phone;

          
  
          //$orderId = base64_decode($orderId);
          $this->db->set("order_status",0);
          $this->db->where("order_id",$order['order_id']);
          $this->db->where("order_userid",$order['user_id']);
          $this->db->update("kh_order_tb");
    

        $data['order_id']=$order['order_id'];
        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Order Cancel Successfully","data"=> "" );
          echo  json_encode($response);
      } else {
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
      echo  json_encode($response);
    }
  }
 public function getOfferCouponcode()
   {
      $offerlist = $this->App_Model->getDiscountOffers();
      foreach ($offerlist as $key => $ae) {
          $data['coupon_title']=$ae->coupon_title;
          $data['coupon_description']=$ae->coupon_description;
          $data['coupon_code']=$ae->coupon_code;
          $offerdata[]=$data;
      }
      
      if(!empty($offerdata)){
          $datas['offer_list']= @$offerdata;
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Offer List","data" => $datas);
          echo  json_encode($response);
      }else{
          $response = array("status_code" =>201 ,  "status" => "failed", "message" => "Offer List Not Found","data" => "");
          echo  json_encode($response);
      }
      
   }
public function notification()
  {
    //{"user_id":"1"}
    $userid=file_get_contents("php://input");
    file_put_contents('textfile/notification.txt',$userid);
    if($userid != null){
      $userid=json_decode($userid, true);
      $notification=$this->App_Model->getNotificationData($userid['user_id']);

      if (!empty($notification)) {
        $data["notification_list"] = $notification;
        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Notification List","data"=> $data );
        echo  json_encode($response);
      } else {
        $response = array("status_code" =>201 ,  "status" => "success", "message" => "Notification Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
  public function transaction()
  {
    //{"user_id":"1"}
    $userid=file_get_contents("php://input");
    if($userid != null){
      $userid=json_decode($userid, true);
      $amount_transaction=$this->App_Model->amount_transaction($userid['user_id']);
      if (!empty($amount_transaction)) {
        $data["amount_transaction"] = $amount_transaction;
        $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Amount Transaction List","data"=> $data );
        echo  json_encode($response);
      } else {
        $response = array("status_code" =>201 ,  "status" => "success", "message" => "Amount Transaction Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function getmembershipPack()
   {
      $memlist = $this->App_Model->getmembershipPack();
      foreach ($memlist as $key => $ae) {
          $data['pack_id']=$ae->pack_id;
          $data['pack_name']=$ae->pack_name;
          $data['pack_price']=$ae->pack_price;
          
        if($ae->pack_time_duration == 12){ $duration= "1 Year";}else{ $duration=$ae->pack_time_duration.' '.'Months';}
          
          $data['pack_time_duration']=$duration;
          $data['pack_desc']=$ae->pack_desc;
          $data['super_pack']=$ae->super_pack;
          $offerdata[]=$data;
      }
        $datas['offer_list']= $offerdata;
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Membership List","data" => $datas);
      echo  json_encode($response);
   }
    
  public function delivery_amount()
  {
    //{"user_id":"1","total_amount":"100"}
    $userid=file_get_contents("php://input");
    if($userid != null){
      $userid=json_decode($userid, true);
      $totalforgst=$userid['total_amount'];
      $site_settings = $this->App_Model->getSiteSetting();
      $memberStatus=$this->App_Model->getMemberShipStatus($userid['user_id']);
      if (!empty($memberStatus) and $totalforgst >= 299) {
          $data['delivery_amount']=0; 
      }else{
          if($totalforgst >= 499) {
            $data['delivery_amount']=$site_settings->second_delivery_amount; 
          }else{
                $data['delivery_amount']=$site_settings->delivery_amount; 
          }
      }
      $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Amount Transaction List","data"=> $data );
      echo  json_encode($response);
      
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
  public function purchasemembership()
  {
    //{"pack_id":"1","user_id":"1"}
    $member=file_get_contents("php://input");
    if($member != null){
        $members=json_decode($member, true);
        $purchase_id=$this->App_Model->purchasemembership($members['pack_id'],$members['user_id']);
        if (!empty($purchase_id)) {
            
        $this->db->select('*');
        $this->db->where('pack_id',$members['pack_id']);
        $this->db->where('pack_status',1);
        $getResult = $this->db->get('kh_membership_pack')->row(); 
            
          $data['purchase_id']=$purchase_id;
          $data['pack_price']=$getResult->pack_price;
          $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Purchase ID","data"=> $data );
          echo  json_encode($response);
        } else {
            $response = array("status_code" =>201 ,  "status" => "success", "message" => "Data Error","data" => "" );
            echo  json_encode($response);
        }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  public function membershipPayment()
  {
    //{"merchant_order_id":"16","merchant_trans_id":"pay_GC3cBanyHMNoJI","merchant_product_info_id":"","card_holder_name_id":"","merchant_amount":"100.0"}
    $orderpayment=file_get_contents("php://input");
    if(!empty($orderpayment)){
      $payment=json_decode($orderpayment, true);
      if ($payment !=null) 
      {
           	$data= array(
    			'order_id' => $payment['merchant_order_id'],
    			'trans_id' => $payment['merchant_trans_id'],
    			'product_info_id' => $payment['merchant_product_info_id'],
    			'card_holder_name_id' => $payment['card_holder_name_id'],
    			'merchant_amount' => $payment['merchant_amount'],
    			'payment_status' => 1
    		);
    		$this->db->insert('kh_membership_payment',$data);
    
            $this->db->set("payment_status",1);
            $this->db->set("membership_exp",1);
            $this->db->where('purchase_id',$payment['merchant_order_id']);
            $this->db->update("kh_purchase_membership");
        
            $this->db->where('purchase_id',$payment['merchant_order_id']);
            $membershipdata=$this->db->get("kh_purchase_membership")->row();

            $data['userdata']=$this->App_Model->getUserDataForMembership($membershipdata->user_id);

            //print_r($data['userdata']); die();
            
            $mobileNum = $data['userdata']->user_mobile;
            $username = $data['userdata']->user_name;
            $sms="Dear $username, Congratulations, you are a member of The Kiranewala Family. You will get exciting offers and free deliveries as applicable. To know more visit our website www.The Kiranewala.com/membership.html";
            $orderSMS=urlencode($sms);

            $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
            ));

            $response = curl_exec($curl);
            curl_close($curl); 
            
            
             $this->db->set('user_id',$data['userdata']->user_id);
             $this->db->set('notification',$sms);
             $this->db->set('status',1);
             $this->db->insert('kh_notification');
             
            $dataa['membership']=$membershipdata;

            $response=array('status_code' =>200 , "status" => "success" ,"message"=>"Payment Add Successfully.","data"=> $dataa );
            echo  json_encode($response);
        
      } else {
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Fields Required","data" => "" );
      echo  json_encode($response);
    }
  }
    
    
    
    public function apphomepage()
   {

      //{ "delivery": "Same day delivery","slider": 1,"bank_card": "http://localhost/rollking/assets/images/payment-method.png","contact_us": "8795227766"}
      $prodatas = file_get_contents("php://input");
      $pro=json_decode($prodatas, true);


      $datass['delivery']="Same day delivery";
          
       $slider= $this->App_Model->getAppHomePage(1);
       if(!empty($slider)){
           foreach ($slider as $key => $sli) {
          $dataslider['image_id'] = $sli->image_id;
          $dataslider['image_name'] = base_url("uploads/app_home")."/".$sli->image_name;
          $dataslider['image_link'] = $sli->image_link;
          
          if(empty($sli->image_link)){
              $categoryData=$this->db->select()->where('category_id',$sli->image_link)->get('kh_category')->row();
              $dataslider['name'] = $categoryData->category_name;
          }else{
              $dataslider['name'] = "";
          }
          
          $sliders[]=$dataslider;
        }
        $datass['slider']=$sliders;
       }else{
          $datass['slider'] = "";
       }
       
            

      

      $datass['bank_card']=base_url('assets/images/payment-method.png');
      $datass['contact_us']="8795227766";

     // print_r($datass); die();

      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Home Page","data" => $datass);
      echo  json_encode($response);
   }
   
   public function getProductdetailsbanner()
   {
       $product_details_page_banner= $this->App_Model->getAppHomePage(10);
       foreach ($product_details_page_banner as $key => $sl) {
        $data['image_id'] = $sl->image_id;
        $data['image_name'] = base_url("uploads/app_home")."/".$sl->image_name;
        $data['image_link'] = $sl->image_link;
        if(!empty($sl->image_link)){
            $categoryData=$this->db->select()->where('category_id',$sl->image_link)->get('kh_category')->row();
            $data['name'] = $categoryData->category_name;
        }else{
            $data['name'] = "";
        }
        $product_details_page_banners[]=$data;
      }

      $datass['product_details_page_banner']=$product_details_page_banners;
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Product Details Banner","data" => $datass);
      echo  json_encode($response);
   }
   public function sendMail($to,$subject,$body)
  {
    // $this->load->library('email');
    // $config['protocol'] = 'sendmail';
    // $config['mailpath'] = '/usr/sbin/sendmail';
    // $config['charset'] = 'iso-8859-1';
    // $config['wordwrap'] = TRUE;
    // $config['mailtype'] = 'html';
    // $this->email->set_mailtype("html");
    // $this->email->initialize($config);
    // $this->email->from('accounts@rollsking.in', 'rollsking.in');
    // $this->email->to($to);
    // $this->email->cc('accounts@rollsking.in');
    // $this->email->bcc('report@infutive.com');
    // $this->email->subject($subject);
    // $this->email->message($body);
    // $this->email->send();
         $headers = "MIME-Version: 1.0" . "\r\n"; 
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
         mail($to, $subject, $body, $headers);
  }
   public function forgetPassword()
   {
      //{"email_id":"dev.developer@gmail.com"}
      $userProfile = file_get_contents("php://input");
      if($userProfile != null) {
        $user=json_decode($userProfile, true);
        $userEmail=$this->App_Model->forgetPasswordEmail($user['email_id']);
        if($userEmail->user_email=='test@rollsking.in'){
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Your change password has been sent to your registered mobile number and email id.","data" => $user);
          echo  json_encode($response);
        }else{
        
          if ($userEmail) {
             @$dbEmail=$userEmail->user_email;
             $enterEmail=$user['email_id'];

             $to=$userEmail->user_email;
            $name=$userEmail->user_name;
            $mobileNum=$userEmail->user_mobile;
            $user_id=$userEmail->user_id;
            $password=$userEmail->user_password_text;
            $password = rand(9999,999999);
            $mdPassword = md5($password);
                
         
            $this->db->set("user_password",$mdPassword);
            $this->db->set("user_password_text",$password);
            $this->db->where('user_id',$user_id);
            $this->db->update('kh_user_list');
            
                
            
            $message = '<p>Hello '.$name.',</p>';
            $message .= '<p>Welcome to The Rollsking.in Thanks for Reset Password Request </p>';
            $message .= '<p>Username : '.$to.'</p>';
            $message .= '<p>Password : '.$password.'</p>';
            $message .= '<p> </p>';
            $message .= '<p>It looks like you requested a new password </p>';
            
            // echo $message;die();
            $body = mailerHtml($message);
            
            $subject = "Rollsking.com : Reset Password Request";
            
            $this->sendMail($to, $subject, $body);
       
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Your change password has been sent to your registered email id.","data" => $user);
          echo  json_encode($response);
        } else {
         $response = array("status_code" =>200 ,  "status" => "success", "message" => " We cannot find an account with that email address","data" => $user);
          echo  json_encode($response);
        }
        }
        
      }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
        echo  json_encode($response);
      }
   }
   
   
   
  public function productreview()
  {
    //{"user_id":"1","product_id":"1","star":"4","comment":"Hello Product"}
    $reviewdata = file_get_contents("php://input");
    if($reviewdata != null) {
      $review=json_decode($reviewdata, true);
      if (!empty($review['user_id']) AND !empty($review['product_id']) AND !empty($review['star']) AND !empty($review['comment'])) {
          
          $reviewAlreadySubmi=$this->db->select('*')->where('product_id',$review['product_id'])->where('user_id',$review['user_id'])->get('kh_reviews')->row();
          
          if (empty($reviewAlreadySubmi)) {
              $this->db->set('product_id',$review['product_id']);
              $this->db->set('user_id',$review['user_id']);
              $this->db->set('star',$review['star']);
              $this->db->set('status',1);
              $this->db->set('comment',$review['comment']);
              $this->db->insert('kh_reviews');
              $riviewid=$this->db->insert_id();
              if (!empty($riviewid)) {
                  $response = array("status_code" =>200 ,  "status" => "success", "message" => "Review Submitted Successfully !!","data" => "");
                  echo  json_encode($response);
              } else {
                $response = array("status_code" =>201 ,  "status" => "success", "message" => "Review Not Submitted Successfully !! Please Try Again","data" => "");
                echo  json_encode($response);
              }
          } else {
             $response = array("status_code" =>201 ,  "status" => "success", "message" => "Review Already Submitted on this Product.","data" => "");
                echo  json_encode($response);
          }
       }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "ALL Fields Required","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }

  public function getreview()
  {
    //{"product_id":"1"}
    $reviewdata = file_get_contents("php://input");
    if($reviewdata != null) {
      $review=json_decode($reviewdata, true);
      if (!empty($review['product_id'])) {
          $reviewAlreadySubmi=$this->db->select('*')->where('product_id',$review['product_id'])->get('kh_reviews')->result();
         
          if(!empty($reviewAlreadySubmi)){
              foreach ($reviewAlreadySubmi as $key => $ae) {

                $data['product_id']=$ae->product_id;
                $userdata=$this->db->select('*')->where('user_id',$ae->user_id)->get('kh_user_list')->row();
                $data['user_name']=$userdata->user_name;
                $data['star']=$ae->star;
                $data['comment']=$ae->comment;
                $prodata[]=$data;
            }
            $response = array("status_code" =>200 ,  "status" => "success" ,"message" => "All Product Review","data" => $prodata );
            echo  json_encode($response);
          }else{
            $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Product Review Not Found","data" => "" );
            echo  json_encode($response);
          }
       }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "ALL Fields Required","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
   public function getTimeSlotForBooking()
   {
      $slottime=$this->App_Model->getTimeSlotForBooking();
       foreach ($slottime as $key => $slot) {
        $data['slot_id'] = $slot->slot_id;
        
        $slotabalable=$this->App_Model->getAbalableDeliverySlot($slot->slot_id);
        if($slot->slot_id == 1){ 
            if($slotabalable >= 11){
                $checkslot="Not Available"; 
                $values="Full";
            }else{
                $checkslot="Available"; 
                 $values="";
            }
        }else{ $checkslot="Available"; $values=""; }
        $data['slot_name'] = date("d M Y").' - '.$slot->slot_name.' '.$values;
        $data['Available']= $checkslot;
        $slottimes[]=$data;
      }

      $datass['available_slot']=$slottimes;
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "Available Available","data" => $datass);
      echo  json_encode($response);
   }


   public function getbillingaddress()
  {
    //{"user_id":"1"}
    $userProfile = file_get_contents("php://input");
    if($userProfile != null) {
      $user=json_decode($userProfile, true);
      $userId=$user['user_id'];
      $profile_detail = $this->App_Model->getsave_More_address_chk_biling($userId);
      
      $data['save_address']= $profile_detail;
      
      $response = array("status_code" =>200 ,  "status" => "success", "message" => "User Save Address","data" => $data);
      echo  json_encode($response);
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
  
   public function displaysingleaddress()
   {
       //{"id":"1"}
        $displaysingleaddress = file_get_contents("php://input");
        
        $user=json_decode($displaysingleaddress, true);
        $userId=$user['id'];
        $profiledetail = $this->App_Model->displaysingle_address($userId);
        if(!empty($profiledetail)) {
        
        $data['displaysingle_address']= $profiledetail;
        
        $response = array("status_code" =>200 ,  "status" => "success", "message" => "Address Found","data" => $data);
        echo  json_encode($response);
        }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
        echo  json_encode($response);
        }
   } 
   
   
   public function brandlist(){
      $getbrandlist = file_get_contents("php://input");
        
        $user=json_decode($getbrandlist, true);
       
        $brandlistimg =$this->db->select('*')->get('kh_brand')->result();           
        if(!empty($brandlistimg)) {
           foreach($brandlistimg as $brandlist){
            $data['bid']=$brandlist->id;
            $data['bname']=$brandlist->b_name;

            if(!empty($brandlist->b_img)){
              $data['brandimg']=base_url().'uploads/product/'.$brandlist->b_img;
            }else{
              $data['brandimg']=base_url().'admin_assets/img/no-image-icon.png';
            }

            $brandata[]=$data;
          }
          
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Brand List Found","data" => $brandata);
          echo  json_encode($response);
        }else{
          $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
          echo  json_encode($response);
        }

    }


 public function brandlistproduct()
  {
    //{"brand_id":"1"}
    
     $limit=$this->input->get('limit');
     $page=$this->input->get('page');
    $catdata = file_get_contents("php://input");
    file_put_contents('textfile/getcatproduct.txt',$catdata);
    if($catdata != null) {
      $cat=json_decode($catdata, true);
      $brand_id=$cat['brand_id'];
      $product_detail = $this->db->select('*')->where('brand_id',$brand_id)->where('stock_status',1)->where('product_status',1)->limit($limit,$page)->get('kh_product')->result();
      if (!empty($product_detail)) {
            foreach ($product_detail as $key => $ae) {
                $data['product_id']=$ae->product_id;
                $data['parent_product']=$ae->parent_product;
                $data['product_code']=$ae->product_code;
                $data['product_qty']=$ae->product_qty;
                $data['purchase_qty']=$ae->purchase_qty;
                $data['product_url']=$ae->product_url;
                $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
                $data['product_desc']=$ae->product_desc;
               
                $data['product_mrp']=$ae->product_price;
                $data['product_mrp']=$ae->product_mrp;
                $data['product_shipping_price']=$ae->product_shipping_price;
                if(!empty($ae->product_img)){
                  $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
                }else{
                  $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
                }
                $data['product_status']=$ae->product_status;
                $data['featured_status']=$ae->featured_status;
                $data['discounted_products']=$ae->discounted_products;
                $data['new_products']=$ae->new_products;
                if ($ae->stock_status == 1) {
                    $data['stock_status']="In Stock";
                } else {
                    $data['stock_status']="Out of Stock";
                }
                $data['small_description']=$ae->small_description;
                $data['meta_title']=$ae->meta_title;
                $data['meta_desc']=$ae->meta_desc;
                $data['meta_keyword']=$ae->meta_keyword;
                
                $prodata[]=$data;
            }
            $datas['product_by_cat_detail']= $prodata;
            
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Brand Product List","data" => $datas);
            echo  json_encode($response);
       }else{
        $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Brand Product Not Found","data" => "" );
        echo  json_encode($response);
      }
    }else{
      $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Invalid Data","data" => "" );
      echo  json_encode($response);
    }
  }
  
    public function recentorder(){
    //{"userid":"3"}
    $catdata = file_get_contents("php://input");
    file_put_contents('textfile/getrecenetorder.txt',$catdata);
     
    $cat=json_decode($catdata, true);
    $user_id=$cat['userid'];


    $recentORDER = $this->db->select('*')->where('order_userid',$user_id)->order_by('order_id','DESC')->get('kh_order_tb')->row();
    //print_r($recentORDER->order_id);die;
    $item_recentORDERrr = $this->db->select('*')->where('order_id',$recentORDER->order_id)->order_by('item_id','DESC')->limit(3)->get('kh_order_items')->result();

    foreach($item_recentORDERrr as $ad){
    $proda[] =  $ad->product_id;
    
    }
    $datanew = array_unique($proda);
    //print_r($newdata);
    
    $product_detail = $this->db->select('*')->where_in('product_id',$datanew)->get('kh_product')->result();
    //print_r($product_detail);
    if(!empty($product_detail)){
    foreach($product_detail as $ae){ 
    //print_r($new_data); 
    
    $data['product_id']=$ae->product_id;
    $data['parent_product']=$ae->parent_product;
    $data['product_code']=$ae->product_code;
    $data['product_qty']=$ae->product_qty;
    $data['purchase_qty']=$ae->purchase_qty;
    $data['product_url']=$ae->product_url;
    $data['product_name']=$ae->product_name.' '.$ae->purchase_qty;
    $data['product_desc']=$ae->product_desc;
    $data['product_mrp']=$ae->product_price;
    $data['product_mrp']=$ae->product_mrp;
    $data['product_shipping_price']=$ae->product_shipping_price;
    if(!empty($ae->product_img)){
    $data['product_img']=base_url().'uploads/product/'.$ae->product_img;
    }else{
    $data['product_img']=base_url().'admin_assets/img/no-image-icon.png';
    }
    $data['product_status']=$ae->product_status;
    $data['featured_status']=$ae->featured_status;
    $data['discounted_products']=$ae->discounted_products;
    $data['new_products']=$ae->new_products;
    if ($ae->stock_status == 1) {
    $data['stock_status']="In Stock";
    } else {
    $data['stock_status']="Out of Stock";
    }
    $data['small_description']=$ae->small_description;
    $data['meta_title']=$ae->meta_title;
    $data['meta_desc']=$ae->meta_desc;
    $data['meta_keyword']=$ae->meta_keyword;
    
    $prodata[]=$data;
    
    
    }
    $datas['recentproduct']= $prodata;
    $response = array("status_code" =>200 ,  "status" => "success", "message" => "Recent order List","data" => $datas);
    echo  json_encode($response);
    
    }else{
    $response = array("status_code" =>201 ,  "status" => "failed", "message" => "Recent order Not Fount","data" => "");
    echo  json_encode($response);
    }
        
        
    }
    
    public function allowed_cod(){
      $getbrandlist = file_get_contents("php://input");
        
        $user=json_decode($getbrandlist, true);
        $email=$user['email'];
        $brandlistimg =$this->db->select('*')->where('user_email',$email)->where('ch_payment_status',1)->get('kh_user_list')->result();           
        if(!empty($brandlistimg)) {
           foreach($brandlistimg as $brandlist){
            $data['email']=$brandlist->user_email;
            $data['ch_payment_status']=true;
             
            $brandata[]=$data;
          }
         
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Allowed Cod","data" => $brandata);
          echo  json_encode($response);
        }else{
          $response = array("status_code" =>201 ,  "status" => "failed" ,"message" => "Not Allowed Cod","data" => "" );
          echo  json_encode($response);
        }

    }
    
     public function cartadd()
    {
     
      $cartData = file_get_contents("php://input");
      //file_put_contents('textfile/addtocarta.txt', $cartData);
      if($cartData != null) {
        $carts=json_decode($cartData, true);
        
        $productid=$carts['product_id'];
        $userid=$carts['user_id']; 
        $qty=$carts['qty'];
        $cartQtyplusadd= $qty;
        $cartCheckData=$this->db->where('user_id',$userid)->where('product_id',$productid)->get('kh_cart')->row();
        // print_r($cartCheckData);die();
        if(empty($cartCheckData)){
         
          $propriceforcart=$this->App_Model->getproductpriceforcart($productid);
  
          if($propriceforcart->product_qty >= $cartQtyplusadd){
            $product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $propriceforcart->product_name);
            $amount=$propriceforcart->product_price;
         
          if (!empty($qty)) {
            $quantity= $qty;
          }else{
            $qty=  "1";
          }
          
           $gst= ($propriceforcart->slab /100) * $amount * $qty;
          //echo "<br>";
           $price=$amount * $quantity;
          $user_id=$userid;
          
          $amountwithgst= $price + $gst;
          $data = array( 
            'product_id'  => $productid,
            'qty'         => $qty,
            'name'        => $product_name,
            'price'       => $price,
            'one_price'   => $amount,
            'gst'         => $gst,
            'amountwithgst' => $amountwithgst,
            'user_id'       => $user_id
          );
          // print_r($data);die();
          $this->db->insert('kh_cart',$data);
         // $data['insertcart']=$data;
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Add To Cart Successfully","data" => $data);
          echo  json_encode($response);
          }else{
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Only $propriceforcart->product_qty quantity Available ","data" => "");
            echo  json_encode($response);
          }
          
        } 
        elseif(!empty($cartCheckData)){
          // echo 'qty';
          // print_r($cartCheckData->cart_id);
          $propriceforcart=$this->App_Model->getproductpriceforcart($productid);
          $amount=$propriceforcart->product_price;
          if($propriceforcart->product_qty >= $cartQtyplusadd){


           
          $qtyadded=$cartCheckData->qty + $cartQtyplusadd;

          if($qtyadded > $propriceforcart->product_qty){
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Only $propriceforcart->product_qty quantity Available","data" => "");
            echo  json_encode($response);
           }else{
             
            $productGSTAmt = ($propriceforcart->slab / 100) * $propriceforcart->product_price;  
            $totalGST=$productGSTAmt * $qtyadded;
    
            $price=$amount * $qtyadded;
            $totlewithamount=$totalGST + $price;
                        
            $data = array( 
              'qty'         => $cartCheckData->qty + $qty,
              'price'       => $price,
              'one_price'   => $amount,
              'gst'         => $totalGST,
              'amountwithgst' => $totlewithamount
            );
            // print_r($data);die();
            $this->db->where('user_id',$userid);
            $this->db->where('product_id',$cartCheckData->product_id);
            $this->db->update('kh_cart',$data);
            //$data['insertcartupdateqty']=$data;
            $response = array("status_code" =>200 ,  "status" => "success", "message" => "Cart Update Successfully","data" => $data);
            echo  json_encode($response);
           }
          
        }
        else{
          $response = array("status_code" =>200 ,  "status" => "success", "message" => "Only $propriceforcart->product_qty quantity Available","data" => "");
          echo  json_encode($response);
        }
        
      }
      else{
       
      }
         
      }
    }
    
  
  
  
}