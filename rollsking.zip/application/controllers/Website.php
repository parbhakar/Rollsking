<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website extends CI_Controller {
	public function __Construct()
	{
		parent::__construct();
		$this->load->model('Admin_Model');
		$this->load->model('Site_Model');
		
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="font-size:14px;font-style: italic;margin-top:5px;margin-bottom:20px;">', '</div>');
        
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');('Cache-Control: no-Store, no-cache, must-revalidate, post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        
	
	}
	public function checkSession()
	{
		$Logged_in=$this->session->userdata('isUserLogged_in'); 	
 	    if ($Logged_in == 0) { 		
 	        redirect(base_url('user-login.html'));
		}
	}
	
	public function page404()
	{
	    $data["meta_title"] = "404 Page Not Found";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url();
		$data["meta_author"] = base_url();
		$this->load->view('site/404',$data);
	}
public function index()
	{
	
		//echo $this->uri->segment(2); die;
        $this->checkSession();
		$data["meta_title"] = "Rolls King";
		$data["meta_description"] = "Rolls King";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url();
		$data["meta_author"] = base_url();

		$config = array();
        $config["base_url"] = base_url()."index";
        $config["total_rows"] = $this->Site_Model->getallproduct_count();
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;

        $config['enable_query_strings'] = TRUE;
		$config['reuse_query_string'] = TRUE;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data['productpage'] = $this->Site_Model->getallproduct_count_start($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();

		///////////////////pagination/////////////////////////
		$this->load->view('site/index',$data);
	}
	public function searchProduct()
	{
		$data['product_count']=$this->Site_Model->getProductBySearchcount();
        $config = array();
        $config["base_url"] = base_url()."search.html";
        $config["total_rows"] = count($data['product_count']);
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;
        $config['enable_query_strings'] = TRUE;
		$config['reuse_query_string'] = TRUE;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data["links"] = $this->pagination->create_links();
		$data['searchProductData']=$this->Site_Model->getProductBySearch($config["per_page"],$page);
		///////////////////pagination/////////////////////////
		$this->load->view('site/search',$data);
	}
	public function productlist($url)
	{
	
	
		
		$catInfo = $this->Site_Model->getCatDetail($url);
		$data['cat_info'] = $catInfo;
		 
		$data['product_count'] = $this->Site_Model->getCategoryProduct($catInfo->category_id);


		//print_r($data['product_count']); die();
		
		$data['meta_title'] =  $catInfo->meta_title;
		$data['meta_description'] =  $catInfo->meta_desc;
		$data['meta_keywords'] =  $catInfo->meta_keyword;
		$data["canonical_url"] = base_url().'category/'.$url;

		if(!empty($data['product_count'])){
			$productcount= count($data['product_count']); 
		}else{
			$productcount= "0"; 
		}

		///////////////////pagination/////////////////////////
		$this->load->library('pagination');
		$config['base_url'] = base_url().'category/'.$url;
		$config['total_rows'] = $productcount;
		$config['per_page'] = 12;
		$config['enable_query_strings'] = TRUE;
		$config['page_query_string'] = TRUE;
		// integrate bootstrap pagination
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
		$this->pagination->initialize($config);
		// $page = $this->uri->segment(3);
		$page = $this->input->get('per_page');
		$data['page'] = $page;
		$data['product_list']=$this->Site_Model->getCategoryProducts($config["per_page"],$page,$catInfo->category_id);
		$data['link']=$this->pagination->create_links();
		///////////////////pagination/////////////////////////
		$this->load->view('site/category_product_list',$data);
	}
	
	public function checkproductqty($pro_id)
	{
		$proarray=$this->cart->contents();
		foreach ($proarray as $key => $value) {
			if($value['id'] == $pro_id){
				return $value['qty'];
			}
		}
		return 0;
	}
	
	/*public function addtocartajax()
	{
			$id=$this->input->post('product_id');
			$productQtys=$this->checkproductqty($this->input->post('product_id'));
			$cartQtyplusadd= $productQtys + $this->input->post('quantity');

			$pro_qty = $this->Site_Model->getallProduct_m_p($this->input->post('product_id'));
			if($pro_qty->product_qty >= $cartQtyplusadd){
				$product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $this->input->post('product_name'));
				$amount=$this->input->post('product_price');
				if (!empty($this->input->post('quantity'))) {
					$quantity= $this->input->post('quantity');	
				} else {
					$quantity=  "1";
				}
				$price=$amount * $quantity;
				$data = array( 
					   'id'      => $id,
		               'qty'     => $quantity,
		               'price'   => $amount,
		               'name'    => $product_name
					);
				$this->cart->insert($data);
				$response = "Add To Cart Successfully";
				echo json_encode($response);
			}else{
				$response = "Only $pro_qty->product_qty quantity Available ";
				echo json_encode($response);
			}
	}*/
	public function addtocartajax()
	{
		
			$id=$this->input->post('product_id');
			$productQtys=$this->checkproductqty($this->input->post('product_id'));
			$cartQtyplusadd= $productQtys + $this->input->post('quantity');
			$productData = $this->Site_Model->getallProduct_m_p($this->input->post('product_id'));
			if($productData->product_qty >= $cartQtyplusadd){
				$product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $this->input->post('product_name'));
				$amount=$this->input->post('product_price');

				if (!empty($this->input->post('quantity'))) {
					$quantity= $this->input->post('quantity');	
				} else {
					$quantity=  "1";
				}
				$userid = $this->session->userdata('activeUserId');					 

				$cartCheckData=$this->db->where('user_id',$userid)->where('product_id',$this->input->post('product_id'))->get('kh_cart')->row();
				if(empty($cartCheckData)){
					$productGSTAmt = ($productData->slab / 100) * $productData->product_price;  
	        		$totalGST=$productGSTAmt * $cartQtyplusadd;

					$price=$amount * $quantity;
					$totlewithamount=$totalGST + $price;
					$this->db->set('user_id',$userid);
					$this->db->set('product_id',$this->input->post('product_id'));
					$this->db->set('qty',$this->input->post('quantity'));
					$this->db->set('name',$product_name); 
					$this->db->set('one_price',$amount);
					$this->db->set('price',$price);  
					$this->db->set('gst',$totalGST);
					$this->db->set('amountwithgst',$totlewithamount); 
					$this->db->insert('kh_cart');
				}else{
					$qtyadded=$cartCheckData->qty + $cartQtyplusadd;
					$productGSTAmt = ($productData->slab / 100) * $productData->product_price;  
	        		$totalGST=$productGSTAmt * $qtyadded;

					$price=$amount * $qtyadded;
					$totlewithamount=$totalGST + $price;


					$this->db->set('qty',$cartCheckData->qty + $cartQtyplusadd);
					$this->db->set('one_price',$amount);
					$this->db->set('price',$price);  
					$this->db->set('gst',$totalGST);
					$this->db->set('amountwithgst',$totlewithamount); 
					$this->db->where('user_id',$userid);
					$this->db->where('product_id',$productData->product_id);
					$this->db->update('kh_cart');
				}
				
				$response = "Add To Cart Successfully";
				echo json_encode($response);
			}else{
				$response = "Only $pro_qty->product_qty quantity Available ";
				echo json_encode($response);
			}
	}
	
	

	public function returnorderajax(){

		 // print_r($_POST);die;
		  $this->checkSession();
		  $itemid = $this->input->post('itemid');
		  $this->db->select('*');
		  $this->db->where('item_id',$itemid);
		  $this->db->set('status',0);
		  $this->db->update('kh_order_items'); 
		  $response = "Request Return Successfully";
		  echo json_encode($response);
		  //redirect($_SERVER['HTTP_REFERER']); 


		  
		
	}

	/* function do_upload($fileName,$path)
	{
		$this->checkSession();
		$config['upload_path'] = './uploads/'.$path;
		$config['allowed_types'] = 'gif|jpg|jpeg|png|pdf|svg';
		$config['max_size']	= '20000000000000';
	//	$config['max_width']  = '160';
	//	$config['max_height']  = '190';
		$this->load->library('upload', $config); 
        if($this->upload->do_upload("file")){
            $data = array('upload_data' => $this->upload->data());
 
            $title= $this->input->post('title');
            $image= $data['upload_data']['file_name']; 
             
            $result= $this->upload_model->save_upload($title,$image);
            echo json_decode($result);
        }
	}*/

	public function reorder_order_item(){
		// print_r($_POST);
		 $ida = $this->uri->segment(3);
		$getorder = $this->Site_Model->getOrderItem($ida);
		// print_r($getorder);die;
		foreach($getorder as $order_product)
		{
			$productQtys=$this->checkproductqty($order_product->product_id);
			$cartQtyplusadd= $productQtys + $order_product->qty;
			$productData = $this->Site_Model->getallProduct_m_p($order_product->product_id);
			// print_r($productData->product_qty);die;
			if($productData->product_qty >= $cartQtyplusadd){
				$product_name = preg_replace('/[^A-Za-z0-9\-]/',' ', $order_product->name);
		    	$amount=$productData->product_price;

				if (!empty($order_product->qty)) {
					$quantity= $order_product->qty;	
				} else {
					$quantity=  "1";
				}
				$userid = $order_product->user_id;	

				$cartCheckData=$this->db->where('user_id',$userid)->where('product_id',$order_product->product_id)->get('kh_cart')->row();
				// print_r($cartCheckData);die;
				if(empty($cartCheckData)){
				    $productGSTAmt = ($productData->slab / 100) * $amount;  
	        		$totalGST=$productGSTAmt * $order_product->qty;

					$price=$amount * $quantity;
					$totlewithamount=$totalGST + $price;
					$this->db->set('user_id',$userid);
					$this->db->set('product_id',$order_product->product_id);
					$this->db->set('qty',$order_product->qty);
					$this->db->set('name',$product_name); 
					$this->db->set('one_price',$amount);
					$this->db->set('price',$price);  
					$this->db->set('gst',$totalGST);
					$this->db->set('amountwithgst',$totlewithamount); 
					$this->db->insert('kh_cart');
				}else{
					$qtyadded=$order_product->qty + $cartCheckData->qty;
				    $productGSTAmt = ($productData->slab / 100) * $productData->product_price;  
	        		$totalGST=$productGSTAmt * $qtyadded;

					$price=$amount * $qtyadded;
					$totlewithamount=$totalGST + $price;


					$this->db->set('qty',$qtyadded);
					$this->db->set('one_price',$amount);
					$this->db->set('price',$price);  
					$this->db->set('gst',$totalGST);
					$this->db->set('amountwithgst',$totlewithamount); 
					$this->db->where('user_id',$userid);
					$this->db->where('product_id',$productData->product_id);
					$this->db->update('kh_cart');
				}
				
				// $response = "Add To Cart Successfully";
				// echo json_encode($response);
			}
		}
		redirect($_SERVER['HTTP_REFERER']);
	}

	
	/*public function updateCart()
	{
		$pro_id = $this->input->post('product_id');
		$pro_qty = $this->Site_Model->getallProduct_m_p($pro_id);

		//print_r($PRO_QTY->product_qty); die;
		if($pro_qty->product_qty >= $this->input->post('quantity')){
			$data = array(
	       		'rowid' => $this->input->post('rowid'),
	       		'qty'   => $this->input->post('quantity')
        	);
			$this->cart->update($data);
			$sessionData['message'] = "<span class='alert alert-success'>Cart Updated Successfully.</span>";
			$this->session->set_userdata($sessionData);
			redirect("shopping-cart.html");
		}elseif($this->input->post('quantity') < 1){ 
			$data = array(
	       		'rowid' => $this->input->post('rowid'),
	       		'qty'   => $this->input->post('quantity')
        	);
			$this->cart->update($data);
			$sessionData['message'] = "<span class='alert alert-success'>Cart Updated Successfully.</span>";
			$this->session->set_userdata($sessionData);
			redirect("shopping-cart.html");
		}else{
			$sessionData['message'] = "<span class='alert alert-success'>Only $pro_qty->product_qty Stock Left To Order.</span>";
			$this->session->set_userdata($sessionData);
			redirect("shopping-cart.html");
		}
		 
	}
	public function deletecartItem($cart_id)
	{
			//echo $cart_id; die();
			$data = array('rowid'   => $cart_id,'qty' => 0);
			$this->cart->update($data);
			$sessionData['message'] = "<span class='alert alert-success'>Cart Item Delete Successfully.</span>";
			$this->session->set_userdata($sessionData);
			// $this->cart->insert($data);
			redirect("shopping-cart.html");
		
	} */
	
		public function updateCart()
	{
		 
		
		$pro_id = $this->input->post('product_id');
		$pro_qty = $this->Site_Model->getallProduct_m_p($pro_id);
		$calculate_price=$pro_qty->product_price*$this->input->post('quantity');
		$productQtys=$this->checkproductqty($this->input->post('product_id'));
		$cartQtyplusadd= $productQtys + $this->input->post('quantity');
		//echo '<br>';
		  $productGSTAmt = ($pro_qty->slab / 100) * $pro_qty->product_price; 
		  $totalGST=$productGSTAmt * $cartQtyplusadd; 

		  echo $price=$pro_qty->product_price * $this->input->post('quantity');
		  $totlewithamount=$totalGST + $price;

		//print_r($PRO_QTY->product_qty); die;
		if($pro_qty->product_qty >= $this->input->post('quantity')){
			$data = array(
	       		'rowid' => $this->input->post('rowid'),
	       		'qty'   => $this->input->post('quantity')
        	);
			$this->db->select('*');
			$this->db->where('cart_id',$this->input->post('rowid'));
			$this->db->set('qty',$this->input->post('quantity'));
			$this->db->set('price',$calculate_price);
			$this->db->set('gst',$totalGST);
			$this->db->set('amountwithgst',$totlewithamount);
			$this->db->update('kh_cart');
			//$this->cart->update($data);
			$sessionData['message'] = "<span class='alert alert-success'>Cart Updated Successfully.</span>";
			$this->session->set_userdata($sessionData);
			redirect("shopping-cart.html");
		}elseif($this->input->post('quantity') < 1){ 
			$data = array(
	       		'rowid' => $this->input->post('rowid'),
	       		'qty'   => $this->input->post('quantity')
        	);
			$this->db->select('*');
			$this->db->where('cart_id',$this->input->post('rowid'));
			$this->db->set('qty',$this->input->post('quantity'));
			$this->db->set('price',$calculate_price);
			$this->db->update('kh_cart');
			//$this->cart->update($data);
			$sessionData['message'] = "<span class='alert alert-success'>Cart Updated Successfully.</span>";
			$this->session->set_userdata($sessionData);
			redirect("shopping-cart.html");
		}else{
			$sessionData['message'] = "<span class='alert alert-success'>Only $pro_qty->product_qty Stock Left To Order.</span>";
			$this->session->set_userdata($sessionData);
			redirect("shopping-cart.html");
		}
		 
	}
	public function deletecartItem($cart_id)
	{
			// echo $cart_id; die();
			$this->db->select('*');
			$this->db->where('cart_id',$cart_id);
			$this->db->delete('kh_cart');
			// $data = array('rowid'   => $cart_id,'qty' => 0);
			// $this->cart->update($data);
			$sessionData['message'] = "<span class='alert alert-success'>Cart Item Delete Successfully.</span>";
			$this->session->set_userdata($sessionData);
			// $this->cart->insert($data);
			redirect("shopping-cart.html");
		
	}
    public function shoppingcart()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('shopping-cart.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/shopping-cart',$data);	
	}

    public function checkoutBilling()
	{
		$this->checkSession();
		$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('billing-details.html');
		$data["meta_author"] = base_url();
		$data["saveaddress"]=$this->Site_Model->getSaveAddress();
		$this->load->view('site/checkout-billing',$data);
	}
	public function billing_checkout()
	{
		 
	   $this->checkSession();
		$userid=$this->session->userdata('activeUserId');
		

	    $cart_item=count($this->Site_Model->getCartItem());
		 
		if($cart_item == 0){
			redirect(base_url());
		}

		$addressid=$this->uri->segment(3);
		
			
			$query = $this->db->select('*')->where('id',$addressid)->where('status',2)->get('kh_save_address')->row();
			$data['billing'] = 0;
			$sessionData['firstname'] = $query->user_name;
			$sessionData['email'] = $query->user_email;
			$sessionData['phone'] =$query->user_mobile;
			$sessionData['state'] =$query->user_state;
			$sessionData['address'] =$query->user_address;
			$sessionData['city'] = $query->user_city;
			$sessionData['zipcode'] =$query->pin_code;
			$sessionData['user_gst'] =$query->user_gst;
			$sessionData['useraddressid'] =$query->id;
			//print_r($sessionData);die;
			$this->session->set_userdata($sessionData);
			//$this->load->view('site/checkout',$data);
			redirect(base_url('checkout.html'));
	}


	public function deletesaveaddress()
	{
		$this->checkSession();
		$id=$this->uri->segment(3);
		$this->db->where('id',$id);
		$this->db->delete('kh_save_address');

		$sessionData['message'] = "<span class='alert alert-success'>Save Address Delete Successfully !!</span>";
		$this->session->set_userdata($sessionData);
		redirect("user-profile.html");
	}

	public function editbillingaddress()
	{
		$this->checkSession();
		$addressid=$this->uri->segment(2);
		$data['edit_address']=$this->Site_Model->getEditAddressData($addressid);
		$this->load->view('site/edit-billing-address',$data);
	}
	public function submiteditbillingadress()
	{
			//print_r($_POST);die;
			$this->Site_Model->updateEditaddress();

			$sessionData['message'] = "<span class='alert alert-success'> Address Update Successfully !!</span>";
			$this->session->set_userdata($sessionData);
			//redirect("checkout-billing.html");
			redirect(base_url('user-profile.html'));

		// $this->load->library('form_validation');
		// $this->form_validation->set_rules('firstname','First Name','trim|required|xss_clean');
		// $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
		// $this->form_validation->set_rules('phone','Phone No.','trim|required|xss_clean');
		// $this->form_validation->set_rules('state','State Name','trim|required|xss_clean');
		// $this->form_validation->set_rules('address','Address','trim|required|xss_clean');
		// $this->form_validation->set_rules('city','City','trim|required|xss_clean');
		// $this->form_validation->set_rules('zipcode','Zipcode','trim|required|xss_clean');
	
		// if (($this->form_validation->run() == FALSE))
		// {
		// 	$data['edit_address']=$this->Site_Model->getEditAddressData($this->input->post('id'));
		// 	$this->load->view('site/edit-billing-address',$data);
		// }
		// else
		// {
		
		// 	$this->Site_Model->updateEditaddress();

		// 	$sessionData['message'] = "<span class='alert alert-success'> Address Update Successfully !!</span>";
		// 	$this->session->set_userdata($sessionData);
		// 	redirect("checkout-billing.html");
		// 	redirect(base_url('checkout-billing.html'));
		// }
	}

	public function checkoutData()
	{
	    $this->checkSession();
		$userid=$this->session->userdata('activeUserId');
		$data['cartData']=$this->Site_Model->getCartList($userid);
		$cartdata=$data['cartData'];
		foreach ($cartdata as $key => $ae) {
			$checkOutofstaock=$this->Site_Model->getProductStatusforOutOfstork($ae->product_id);
			if($checkOutofstaock->stock_status == 0){
				$this->db->where('product_id',$ae->product_id);
				$this->db->where('user_id',$userid);
				$this->db->delete('kh_cart');
			}
		}

		$this->load->view('site/checkout');
	}
	public function packagedetail($url)
	{
		$productInfo = $this->Site_Model->getProductDetailbyUrl($url);
		$data['meta_title'] =  $productInfo->meta_title;
		$data['meta_description'] =  $productInfo->meta_desc;
		$data['meta_keywords'] =  $productInfo->meta_keyword;
		$data["canonical_url"] = base_url().'product/'.$url;
		$data['productInfo'] = $productInfo;
		$this->load->view('site/product_details',$data);
	}
	public function subscribe($url)
	{
		$productInfo = $this->Site_Model->getProductDetailbyUrl($url);
		if ($productInfo->subscribe_status != 1){
            echo "<script>alert('This Product Not For Subscription. Please click ok and you redirect home page automatically!!');</script>";
			echo"<script>window.location.href='".base_url()."'</script>";
        }
		$data['meta_title'] =  $productInfo->meta_title;
		$data['meta_description'] =  $productInfo->meta_desc;
		$data['meta_keywords'] =  $productInfo->meta_keyword;
		$data["canonical_url"] = base_url().'product/'.$url;
		$data['productInfo'] = $productInfo;
		$this->load->view('site/subscribe_details',$data);
	}

	public function getAddress($lat,$long)
	{
		 // $lat='28.6051681';
		 // $long='77.0489918';
		$geocodeFromLatLong = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?latlng='.trim(@$lat).','.trim(@$long).'&sensor=true_or_false&key=AIzaSyA5H3QyDBKmq8guZphzXJP_33eh5aA94wA'); 
	        $output = json_decode($geocodeFromLatLong);
		$status = $output->status;
	        //Get address from json data
	    $address= ($status=="OK")?$output->results[1]->formatted_address:'';
	    echo json_encode($address);
	}
	public function discountedproducts()
	{
	    $data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('discounted-products.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/discounted-products',$data);
	}
	public function popularproducts()
	{
	    $data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('popular-products.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/popular-products',$data);
	}
	public function aboutus()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('about-us.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/about-us',$data);
	}
	public function privacy()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('privacy.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/privacy',$data);
	}
	public function terms_and_conditions()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('terms-and-conditions.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/privacy',$data);
	}
	
	public function discountoffers()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('discount-offers.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/discount-offers',$data);
	}
	
	public function faq()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('terms-and-conditions.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/faq',$data);
	}
	
	public function contactUs()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('contact-us.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/contact-us',$data);
	}
		public function submitQuickform()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
		$this->form_validation->set_rules('phone', 'Mobile Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('subject', 'Subject', 'trim|xss_clean');
		$this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
			$sessionData = array('message'=>'<span class="text-success">Form Not Submit Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect($_SERVER['HTTP_REFERER']);
		}else{ 
		    
        			//$this->Site_Model->insertQuickInquery();
        			$to = $this->input->post("email");
        			$name = $this->input->post("name");
        			$messages = $this->input->post("message");
        			$subject = $this->input->post("subject");
        			$phone = $this->input->post("phone");
        
        			$message = '<p>Hello '.$name.',</p>';
        			$message .= '<p>Welcome to rollsking.com.</p>';
        			$message .= '<p>Name : '.$name.'</p>';
        			$message .= '<p>Email : '.$to.'</p>';
        			$message .= '<p>Phone : '.$phone.'</p>';
        			if(!empty($subject)){
        			    $message .= '<p>Subject : '.$subject.'</p>';
        			}
        			$message .= '<p>Message : '.$messages.'</p>';
        			$message .= '<p> </p>';
        
        			$body = mailerHtml($message);
        			$subject = "rollsking.com : Thanks for Quick Contact with us.";
        			$this->sendMail($to, $subject, $body);
        
        
        			$sessionData = array('message'=>'<span class="text-success">Your Form Submit Successfully !!</span>');
        			$this->session->set_userdata($sessionData);
        			redirect($_SERVER['HTTP_REFERER']);
           
		}
	}
	public function applyCouponCode()
	{
		$couponCode = $this->input->post("coupon_code");
		$couponSubmit = $this->input->post("coupon_submit");
		 
		if($couponCode!=NULL && $couponCode!="" && $couponSubmit=="Apply Code")
		{
			$responseData = $this->Site_Model->getCouponInfo($couponCode);
			 
		    //print_r($responseData); die;
			if($responseData!=NULL)
			{
				
				   $totalAmount=$this->cart->total();
							 
							
				if($responseData->coupon_discount_type==0)
				{
					//echo $totalAmount; die();
					
					if($responseData->coupon_minimun_limit > $totalAmount)
					{
					   	$sessionData = array('message_alert'  => '<span class="alert alert-danger">Coupon Code Not Valid !!</span>');
				        $this->session->set_userdata($sessionData);
					}else{
					    $calDiscountAmount = round(($totalAmount * $responseData->coupon_discount_value) / 100);
    					$finalAmount = round(($totalAmount - $calDiscountAmount));
    					 
    					$sessionData = array('message_alert'  => '<span class="alert alert-success" style="font-size: 12px;">Coupon '.$couponCode.' Applied Successfully !!</span>');
    					$this->session->set_userdata($sessionData);
    					
    					$couponDiscountAmount = $responseData->coupon_discount_value;
    					$sessionData = array('discountCouponAmount'  => $calDiscountAmount);
    					$this->session->set_userdata($sessionData);
    					
    					$sessionData = array('discountAmount'  => $calDiscountAmount);
    					$this->session->set_userdata($sessionData);
    					
    					$sessionData = array('applied_coupon'  => $couponCode);
    					$this->session->set_userdata($sessionData);
					}
				}
				else
				{
				 		
				 	if($responseData->coupon_minimun_limit > $totalAmount)
					{
					   	$sessionData = array('message_alert'  => '<span class="alert alert-danger">Coupon Code Not Valid !!</span>');
				        $this->session->set_userdata($sessionData);
					}else{
    					$finalAmount = round($totalAmount - $responseData->coupon_discount_value);
    					
    					$sessionData = array('message_alert'  => '<span class="alert alert-success" style="font-size: 12px;">Coupon '.$couponCode.' Applied Successfully !!</span>');
    					$this->session->set_userdata($sessionData);
    					$couponDiscountAmount = $responseData->coupon_discount_value;
    					$sessionData = array('discountCouponAmount'  => $couponDiscountAmount);
    					$this->session->set_userdata($sessionData);
    					
    					$sessionData = array('discountAmount'  => $finalAmount);
    					$this->session->set_userdata($sessionData);
    					
    					$sessionData = array('applied_coupon'  => $couponCode);
    					$this->session->set_userdata($sessionData);
					}
				}
			}
			else
			{
				$sessionData = array('message_alert'  => '<span class="alert alert-danger">Coupon Code Not Valid !!</span>');
				$this->session->set_userdata($sessionData);
			}
			 
		}
		if($couponCode!=NULL && $couponCode!="" && $couponSubmit=="Remove Code")
		{
			$sessionData = array('message_alert'  => '<span class="alert alert-success">Coupon Removed Successfully !!</span>');
			$this->session->set_userdata($sessionData);

			$sessionData = array('discountAmount'  => "");
			$this->session->set_userdata($sessionData);

			$sessionData = array('applied_coupon'  => "");
			$this->session->set_userdata($sessionData);
		}
		
		redirect(base_url('order-now.html'));
	 
	}	

	public function userLogout()
	{
	    
// 	    $this->db->where('user_id',$this->session->userdata('activeUserId'));
// 		$this->db->where('cart_status',1);
// 		$this->db->delete('kh_cart');
	    
		 $removeData = array(
                   'activeUserMail'  => "",
                   'activeUserId'  => "",
                   'isUserLogged_in' => "",
               );
		$this->session->unset_userdata($removeData);
		$this->session->sess_destroy();
		redirect(base_url());
	}

	public function orderNow()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('firstname','First Name','trim|required|xss_clean');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('phone','Phone No.','trim|required|xss_clean');
		$this->form_validation->set_rules('state','State Name','trim|required|xss_clean');
		$this->form_validation->set_rules('address','Address','trim|required|xss_clean');
		$this->form_validation->set_rules('city','City','trim|required|xss_clean');
		$this->form_validation->set_rules('zipcode','Zipcode','trim|required|xss_clean');
		if (($this->form_validation->run() == FALSE))
		{
			$data['billing'] =0;
			$this->load->view('site/checkout',$data);
		}
		else
		{
			$data['billing'] = 1;
			$this->load->view('site/checkout-billing',$data);
			
		}
		
	}
	
	public function makePayment()
	{
		//print_r($_POST);die;
	    $cart_item=count($this->Site_Model->getCartItem());
		 
		if($cart_item == 0){
			redirect(base_url());
		}
		
		
	    $sessionData = array('discountAmount'  => "");
		$this->session->set_userdata($sessionData);

		$sessionData = array('applied_coupon'  => "");
		$this->session->set_userdata($sessionData);
			
			
		$orderid = $this->Site_Model->insertorder();
		if ($this->input->post('payment_type') == 1) {


			$data['getOrderData']=$this->Site_Model->getOrderData($orderid);

			//print_r($data['getOrderData']); die;
			$data['itemList']=$this->Site_Model->getOrderItemFromCheckout($orderid);
			//print_r($data['itemList']);die;

			$mailBox = $this->load->view('template/checkoutinvoice',$data,true);
		 	
			$email=$data['getOrderData']->order_email;
			$amount=$data['getOrderData']->order_amount;
			$orderuniquecode=$data['getOrderData']->order_unique_code;
			$name=$data['getOrderData']->order_firstname;
			$mobileNum=$data['getOrderData']->order_phone;
			///////////////////////mail//////////////////
			 $config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'utf-8';
			$config['wordwrap'] = TRUE;
			$config['mailtype'] = 'html';
		 
			$this->email->initialize($config);
			
			$this->load->library('email');
			
			$this->email->reply_to('contact@rollsking.com', 'rollsking.com');
			 
			$this->email->from('contact@rollsking.com', 'rollsking.com');
			$this->email->to($email);
			$this->email->cc('contact@rollsking.com');
			$this->email->bcc('report@infutive.com');
			$this->email->subject("Order Invoice: rollsking.com");
			$this->email->message($mailBox);
			$this->email->send();

			//////////////////////End Mail///////////////////////

		/*	$this->db->set('user_id',$data['getOrderData']->order_userid);
			$this->db->set('notification',$sms);
			$this->db->set('status',1);
			$this->db->insert('kh_notification'); */
			 

			////////////////End SMS/////////////////////
 			$product_qty_mins = $data['itemList'];
			foreach($product_qty_mins as $ad){
				$this->db->query("UPDATE `kh_product` SET `product_qty`=`product_qty`- ".$ad->qty." WHERE `product_id`= '".$ad->product_id."'");

				$productdata=$this->db->select('*')->where('product_id',$ad->product_id)->get('kh_product')->row();
				if($productdata->product_qty < 3){
					$this->db->set('stock_status',0);
					$this->db->where('product_id',$ad->product_id);
					$this->db->update('kh_product');
				}
			}
			
			$this->db->select('*');
			$this->db->where('user_id',$this->session->userdata("activeUserId"));
			$this->db->delete('kh_cart');

			$data['order_id']=$orderuniquecode;
			$this->load->view('site/payment/payment-successful',$data);
		}
// 		elseif ($this->input->post('payment_type') == 2) {
// 			$data['title'] = 'Checkout Payment | The Rollsking';
// 	        $data['getOrderData']=$this->Site_Model->getOrderData($orderid);
// 	        $data['order_id']=$orderid;
// 	        $data['order_amount_with_tax']=number_format((float)$data['getOrderData']->order_amount, 2, '.', '');
// 	        $data['order_firstname']=$data['getOrderData']->order_firstname;
// 	        $data['order_email']=$data['getOrderData']->order_email;
// 	        $data['order_phone']=$data['getOrderData']->order_phone;
// 	        $data['productinfo']=$data['getOrderData']->order_unique_code;
// 	        $data['return_url'] = site_url().'payment-success.html';
// 	        $data['surl'] = site_url().'payment-success.html';
// 	        $data['furl'] = site_url().'Website/paymentFailure';
// 	        $data['currency_code'] = 'INR';
// 	        $this->load->view('site/payment/razorpay',$data);
// 		}
		elseif ($this->input->post('payment_type') == 3) {
		
			$data['title'] = 'Checkout Payment | The Rollsking';
	        $data['getOrderData']=$this->Site_Model->getOrderData($orderid);
			$data['itemList']=$this->Site_Model->getOrderItemFromCheckout($orderid);
			$orderuniquecode=$data['getOrderData']->order_unique_code;
			$product_qty_mins = $data['itemList'];
			foreach($product_qty_mins as $ad){
				$this->db->query("UPDATE `kh_product` SET `product_qty`=`product_qty`- ".$ad->qty." WHERE `product_id`= '".$ad->product_id."'");

				$productdata=$this->db->select('*')->where('product_id',$ad->product_id)->get('kh_product')->row();
				if($productdata->product_qty < 3){
					$this->db->set('stock_status',0);
					$this->db->where('product_id',$ad->product_id);
					$this->db->update('kh_product');
				}
			}
			
			$this->db->select('*');
			$this->db->where('user_id',$this->session->userdata("activeUserId"));
			$this->db->delete('kh_cart');
			
	        $data['order_id']=$orderid;
			$rand_orderid = rand(1000,10000);

			$this->db->set('orderid',$orderid);
			// $this->db->set('rand_orderid',$rand_orderid);
			$this->db->set('order_uid',$orderuniquecode);
			$this->db->insert('kh_ptym_orderid');
			$randorderid=$this->db->where('orderid',$orderid)->get('kh_ptym_orderid')->row();

	       // $data['order_amount_with_tax']=number_format((float)$data['getOrderData']->order_amount, 2, '.', '');
            $data['order_amount_with_tax']=round($data['getOrderData']->order_amount, 2);
	        $data['order_firstname']=$data['getOrderData']->order_firstname;
	        $data['order_email']=$data['getOrderData']->order_email;
	        $data['order_phone']=$data['getOrderData']->order_phone;
	        $data['productinfo']=$randorderid->id;
	        $data['return_url'] = site_url().'pgRedirect.html';
	        $data['surl'] = site_url().'pgResponse.html';
	        $data['furl'] = site_url().'Website/paymentFailure';
	        $data['currency_code'] = 'INR';
	        $this->load->view('site/payment/paytm',$data);
		}else{

		}
		
	}
	
		////payment pytm
	
	public function paytmpgRedirect(){
		 $this->load->view('site/payment/pgRedirect');
	}
    public function paytmpgResponse(){ 
	    if ($_POST["STATUS"] == "TXN_SUCCESS") {
			// print_r($_POST['ORDERID']);die();
			 
			$randorderid=$this->db->select('*')->where('id',$_POST['ORDERID'])->get('kh_ptym_orderid')->row();
				$this->db->set("order_payment_status",1);
				$this->db->where('order_id',$randorderid->orderid);
				$this->db->update("kh_order_tb");


				// $this->db->set('orderid',$_POST['CUST_ID']);
				$this->db->set('orderid',$_POST['ORDERID']);
				$this->db->set('mid',$_POST['MID']);
				$this->db->set('txid',$_POST['TXNID']);
				$this->db->set('txn_amount',$_POST['TXNAMOUNT']);
				$this->db->set('payment_mode',$_POST['PAYMENTMODE']);
				$this->db->set('curency',$_POST['CURRENCY']);
				$this->db->set('txn_date',$_POST['TXNDATE']);
				$this->db->set('status',$_POST['STATUS']);
				$this->db->set('bank_txnid',$_POST['BANKTXNID']);
				$this->db->set('bankname',$_POST['BANKNAME']);
				$this->db->set('chksume',$_POST['CHECKSUMHASH']);
				$this->db->set('resocode',$_POST['RESPCODE']);
				$this->db->set('respmsg',$_POST['RESPMSG']);
				$this->db->insert('kh_order_payment_paytm');
			}else{
				$randorderid=$this->db->select('*')->where('id',$_POST['ORDERID'])->get('kh_ptym_orderid')->row();
				$this->db->where('order_id',$randorderid->orderid);
				$this->db->set("order_payment_status",0);
				$this->db->set("order_status",0);
				$this->db->update("kh_order_tb");
				
				$this->db->set('orderid',$_POST['ORDERID']);
				$this->db->set('mid',$_POST['MID']);
				$this->db->set('txn_amount',$_POST['TXNAMOUNT']);
				$this->db->set('curency',$_POST['CURRENCY']);
				$this->db->set('status',$_POST['STATUS']);
				$this->db->set('bank_txnid',$_POST['BANKTXNID']);
				$this->db->set('chksume',$_POST['CHECKSUMHASH']);
				$this->db->set('resocode',$_POST['RESPCODE']);
				$this->db->set('respmsg',$_POST['RESPMSG']);
				$this->db->insert('kh_order_payment_paytm');
			} 
       	   
		 $this->load->view('site/payment/pgResponse');
	}

	public function paytmTxnStatus(){
		 $this->load->view('site/payment/TxnStatus');
	}
	
    //repayment paytm
	public function repayment_paytm()
	{
		
		$orderid=$this->uri->segment(3);
		// print_r($orderid); die;
		$data['title'] = 'Checkout Payment | The Rollsking';
		$data['getOrderData']=$this->Site_Model->getOrderData($orderid);
		$data['itemList']=$this->Site_Model->getOrderItemFromCheckout($orderid);
		
		$orderuniquecode=$data['getOrderData']->order_unique_code;
		$this->db->set('orderid',$orderid);
		$this->db->set('order_uid',$orderuniquecode);
		$this->db->insert('kh_ptym_orderid');

		$randorderid=$this->db->select('*')->where('orderid',$orderid)->get('kh_ptym_orderid')->row();
		
        $data['order_id']=$randorderid->id;		
        $data['order_amount_with_tax']=round($data['getOrderData']->order_amount, 2);
		$data['order_firstname']=$data['getOrderData']->order_firstname;
		$data['order_email']=$data['getOrderData']->order_email;
		$data['order_phone']=$data['getOrderData']->order_phone;
		$data['productinfo']=$randorderid->id;
		$data['return_url'] = site_url().'repaytmpgRedirect.html';
		$data['surl'] = site_url().'repaytmpgResponse.html/';
		$data['furl'] = site_url().'Website/paymentFailure';
		$data['currency_code'] = 'INR';
		$this->load->view('site/payment/repaytm',$data);
	}
	public function repaytmpgRedirect(){
		// print_r($_POST);die();
		 $this->load->view('site/payment/repaytmpgRedirect');
	}
    public function repaytmpgResponse(){
// 		 print_r($_POST);die;
		if ($_POST["STATUS"] == "TXN_SUCCESS") {
			$randorderid=$this->db->select('*')->where('id',$_POST['ORDERID'])->get('kh_ptym_orderid')->row();
			$this->db->set("order_payment_status",1);
			$this->db->where('order_id',$randorderid->orderid);
			$this->db->update("kh_order_tb");

			$this->db->set('orderid',$_POST['ORDERID']);
			$this->db->set('mid',$_POST['MID']);
			$this->db->set('txid',$_POST['TXNID']);
			$this->db->set('txn_amount',$_POST['TXNAMOUNT']);
			$this->db->set('payment_mode',$_POST['PAYMENTMODE']);
			$this->db->set('curency',$_POST['CURRENCY']);
			$this->db->set('txn_date',$_POST['TXNDATE']);
			$this->db->set('status',$_POST['STATUS']);
			$this->db->set('bank_txnid',$_POST['BANKTXNID']);
			$this->db->set('bankname',$_POST['BANKNAME']);
			$this->db->set('chksume',$_POST['CHECKSUMHASH']);
			$this->db->set('resocode',$_POST['RESPCODE']);
			$this->db->set('respmsg',$_POST['RESPMSG']);
			$this->db->insert('kh_order_payment_paytm');
		} else{
			$randorderid=$this->db->select('*')->where('id',$_POST['ORDERID'])->get('kh_ptym_orderid')->row();
			
			
			$this->db->where('order_id',$randorderid->orderid);
			$this->db->set('mid',$_POST['MID']); 
			$this->db->set('txn_amount',$_POST['TXNAMOUNT']); 
			$this->db->set('curency',$_POST['CURRENCY']); 
			$this->db->set('status',$_POST['STATUS']);
			$this->db->set('bank_txnid',$_POST['BANKTXNID']); 
			$this->db->set('chksume',$_POST['CHECKSUMHASH']);
			$this->db->set('resocode',$_POST['RESPCODE']);
			$this->db->set('respmsg',$_POST['RESPMSG']);
			$this->db->insert('kh_order_payment_paytm');
		}
		  
		$this->load->view('site/payment/repaytmpgResponse');
	}


	////////// revnue and share ///////////////
	
	public function revnue_paytm()
	{
		$orderid=$this->uri->segment(3);
		$time = time();
		// print_r($orderid); die;
		$data['title'] = 'Checkout Payment | The Rollsking';
		$data['getOrderData']=$this->Site_Model->getrevnue_paytm($orderid); 
		$this->db->set('userid',$data['getOrderData']->userid);
		$this->db->set('inv_id',$orderid);
		$this->db->set('order_uid',$time);
		$this->db->insert('kh_genrate_orderid');

		$randorderid=$this->db->insert_id();
		// print_r($randorderid);die();
		// $randorderid=$this->db->select('*')->where('inv_id',$orderid)->get('kh_genrate_orderid')->row();
		
        $data['order_id']=$randorderid;		
        $data['order_amount_with_tax']=round($data['getOrderData']->bill_amont, 2);
		$data['order_firstname']=$data['getOrderData']->username;
		$data['order_email']=$data['getOrderData']->useremail;
		$data['order_phone']=$data['getOrderData']->userphone;
		$data['productinfo']=$randorderid;
		$data['return_url'] = site_url().'revnuepgRedirect.html';
		$data['surl'] = site_url().'revnuepgResponse.html/';
		$data['furl'] = site_url().'Website/paymentFailure';
		$data['currency_code'] = 'INR';
		$this->load->view('site/revnueand_share/revnuepaytm',$data);
	}

	public function revnuepgRedirect(){
		// print_r($_POST);die();
		 $this->load->view('site/revnueand_share/revnuepgRedirect');
	}

	public function revnuepgResponse(){
	// 		 print_r($_POST);die;
		if ($_POST["STATUS"] == "TXN_SUCCESS") {
			$randorderid=$this->db->select('*')->where('genrate_orderid',$_POST['ORDERID'])->get('kh_genrate_orderid')->row();
			$this->db->set("status",0);
			$this->db->where('inv_id',$randorderid->inv_id);
			$this->db->update("kh_genrate_inv");

			$this->db->set('orderid',$_POST['ORDERID']);
			$this->db->set('mid',$_POST['MID']);
			$this->db->set('txid',$_POST['TXNID']);
			$this->db->set('txn_amount',$_POST['TXNAMOUNT']);
			$this->db->set('payment_mode',$_POST['PAYMENTMODE']);
			$this->db->set('curency',$_POST['CURRENCY']);
			$this->db->set('txn_date',$_POST['TXNDATE']);
			$this->db->set('status',$_POST['STATUS']);
			$this->db->set('bank_txnid',$_POST['BANKTXNID']);
			$this->db->set('bankname',$_POST['BANKNAME']);
			$this->db->set('chksume',$_POST['CHECKSUMHASH']);
			$this->db->set('resocode',$_POST['RESPCODE']);
			$this->db->set('respmsg',$_POST['RESPMSG']);
			$this->db->insert('kh_revenu_payment_paytm');
		} else{
			
			$randorderid=$this->db->select('*')->where('genrate_orderid',$_POST['ORDERID'])->get('kh_genrate_orderid')->row();
			
			
			$this->db->where('order_id',$randorderid->inv_id);
			$this->db->set('mid',$_POST['MID']); 
			$this->db->set('txn_amount',$_POST['TXNAMOUNT']); 
			$this->db->set('curency',$_POST['CURRENCY']); 
			$this->db->set('status',$_POST['STATUS']);
			$this->db->set('bank_txnid',$_POST['BANKTXNID']); 
			$this->db->set('chksume',$_POST['CHECKSUMHASH']);
			$this->db->set('resocode',$_POST['RESPCODE']);
			$this->db->set('respmsg',$_POST['RESPMSG']);
			$this->db->insert('kh_revenu_payment_paytm');
		}
			
		$this->load->view('site/revnueand_share/revnuepgResponse');
	}



	public function paymentsuccess()
	{
			// echo "<pre>";
			// print_r($_POST); die();
			$orderid=$_POST['merchant_order_id'];
			$this->Site_Model->insertPayment();
			$data['getOrderData']=$this->Site_Model->getOrderData($orderid);
			$data['itemList']=$this->Site_Model->getOrderItemFromCheckout($orderid);
			$mailBox = $this->load->view('template/checkoutinvoice',$data,true);
		 	
			$email=$data['getOrderData']->order_email;
			$amount=$data['getOrderData']->order_amount;
			$orderuniquecode=$data['getOrderData']->order_unique_code;
			$name=$data['getOrderData']->order_firstname;
			$mobileNum=$data['getOrderData']->order_phone;
			//$testdate=$data['getOrderData']->test_date;


			$this->db->select('*');
			$this->db->where('user_id',$this->session->userdata("activeUserId"));
			$this->db->delete('kh_cart');
		$data['order_id']=$data['getOrderData']->order_unique_code;
		$this->load->view('site/payment/payment-successful',$data);
	}

	public function paymentFailure()
	{
		//$this->Site_Model->insertPayment();
		$this->load->view('site/payment/payment-failed');
	}



//////////////////////////////////Payment End////////////////////////////////
	
	public function registerNow()
	{
	    $redirect=$this->session->userdata('redirect');
		if (!empty($redirect)) {
			$newdata = array('redirect' => $redirect);
			$this->session->set_userdata($newdata);
		}else{
			$newdata = array('redirect' => $_SERVER['HTTP_REFERER']);
			$this->session->set_userdata($newdata);
		}


		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('user-register.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/register-now',$data);
	}
	public function httpPost($url,$params)
	{
	  $postData = '';
	   //create name value pairs seperated by &
	   foreach($params as $k => $v) 
	   { 
		  $postData .= $k . '='.$v.'&'; 
	   }
	   $postData = rtrim($postData, '&');
		$ch = curl_init();  
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POST, strlen($postData));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
	 
		$output=curl_exec($ch);
	 
		curl_close($ch);
		return $output;
	 
	}
	public function registerForm()
	{
		//print_r($_POST); die();
		$this->form_validation->set_message('is_unique', 'This Email is Already Registered');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('full_name','Name','trim|required|xss_clean');
		$this->form_validation->set_rules('email','Email','trim|required|xss_clean|valid_email|is_unique[kh_user_list.user_email]');
		$this->form_validation->set_rules('state','state','trim|required|xss_clean');
		$this->form_validation->set_rules('mobile_number','Phone','trim|required|xss_clean');
		$this->form_validation->set_rules('password','Password','trim|required|xss_clean|matches[confirm_password]');
		$this->form_validation->set_rules('confirm_password','Password','trim|required|xss_clean');
		
		if (($this->form_validation->run() == FALSE))
		{
			$this->session->set_flashdata('message','All Fields Are Mandatory');
			$this->load->view('site/register-now');
		}else{
			$userid=$this->Site_Model->insertregister();
	
			$to = $this->input->post("email");
			$name = $this->input->post("name");
			$mobileNum = $this->input->post("mobile_number");
			//$otpNum="1234";
			$otpNum = rand(1111,9999);
			$this->Site_Model->insertOtp($mobileNum , $otpNum);
            
            $sms="Your Rollsking Verification OTP Code is $otpNum. Code valid for 10 minutes only, one time use. Please DO NOT share the OTP with anyone.";
			
			$otpSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$otpSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);

			curl_close($curl);
			//echo $response;
			
			if ($response!=""){

				$sessionData['msg'] = "Your Mobile Number ".str_pad(substr($this->input->post("mobile_number"), -4 ), strlen($this->input->post("mobile_number")), '*', STR_PAD_LEFT)." Please Enter Your OTP and activate your account.";
				$sessionData['mobile_number'] = $this->input->post("mobile_number");
				$this->session->set_userdata($sessionData);
				redirect(base_url('verify-otp.html'));
			}else{
				$this->session->set_flashdata('message','All Fields Are Mandatory');
				$this->load->view('site/register-now');
			}		 	
		}
	}
	public function OTPVerification()
	{
		$this->load->view('site/otp');
	}
	public function submitOTPVerification()
	{
        if($this->input->post('submit') == "Resend OTP"){
            
            $mobileNum=$this->input->post('mobile_number');
            $otpSMS=$this->Site_Model->getOtpForResend($mobileNum);
            //$sms="Your Rollsking Verification OTP Code is $otpSMS->otp_number. Code valid for 10 minutes only, one time use. Please DO NOT share the OTP with anyone.";
             $sms="Your OTP is $otpSMS->otp_number. Valid for 15 minutes.";
			$otpSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$otpSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));
			$response = curl_exec($curl);
			curl_close($curl);
			redirect($_SERVER['HTTP_REFERER']);
        }else{
            //print_r($_POST); die();
    		$mobileNum=$this->input->post('mobile_number');
    		$otpNum=$this->input->post('otp');
    		$checkDb = $this->Site_Model->confirmOtp($mobileNum , $otpNum);
    
    		if ($checkDb !=0) {
    			$this->Site_Model->updateotp($mobileNum , $otpNum);
    
    			$this->db->set("user_activation",1);
    		  	$this->db->where("user_mobile",$mobileNum);
    		  	$this->db->update("kh_user_list");
    		  	
    		  	
    		  	$currentUserDetail=$this->Site_Model->getLoginByMobileNumber($mobileNum);

    			$newdata = array(
					'activeUserMail' => $currentUserDetail->user_email,
					'activeUserId'  => $currentUserDetail->user_id,
					'isUserLogged_in' => 1);
				$this->session->set_userdata($newdata);
    		  	
    		  	
    			$this->session->set_flashdata('message','<span class="text-success">You are Successfully Registered with Us. </span>');
    			redirect(base_url('register-successfully.html'));
    		}else{
    			$this->session->set_flashdata('msg','Your OTP Not Match Please Try Again!!');
    			redirect(base_url('verify-otp.html'));
    		}
        }
		
	}

	
    
    public function checkRedirect()
	{
		if($this->session->userdata("redirect"))
		{
			$redirectTo = $this->session->userdata("redirect");
			$removeData = array('redirect'  => "");
			$this->session->unset_userdata($removeData);
			redirect($redirectTo);
		}else{
			redirect(base_url());
		}
	}

    
	public function accountactivationlink()
	{
		$id=$this->uri->segment(3);
		$userid=base64_decode($id);
		$this->db->where("user_id",$userid);
		$userdata=$this->db->get("kh_user_list")->row();
		if ($userdata == 0) {
			$this->session->set_flashdata('message','<span class="text-success"><h2>Opss!!</h2><br>
					<p>We cannot find an account with that email address</p></span>');
			header("Location:".base_url('account-activation.html'));
		}else{
			$this->db->set("user_activation",1);
			$this->db->where("user_id",$userid); 
			$this->db->update("kh_user_list");
			$this->session->set_flashdata('message','<span class="text-success"><h2>Thank you for registering at rollsking.com !!</h2><br>
					<p>Your Account Activated Successfully !!</p></span>');
			header("Location:".base_url('account-activation.html'));
		}		
	}
	public function accountactivation()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('account-activation.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/allconfirm',$data);
	}
	public function sendMail($to,$subject,$body)
	{
// 		$this->load->library('email');
// 		$config['protocol'] = 'sendmail';
// 		$config['mailpath'] = '/usr/sbin/sendmail';
// 		$config['charset'] = 'iso-8859-1';
// 		$config['wordwrap'] = TRUE;
// 		$config['mailtype'] = 'html';
// 		$this->email->set_mailtype("html");
// 		$this->email->initialize($config);
// 		$this->email->from('accounts@rollsking.in', 'rollsking.com');
// 		$this->email->to($to);
// // 		$this->email->cc('contact@rollsking.com');
// // 		$this->email->bcc('report@infutive.com');
// 		$this->email->subject($subject);
// 		$this->email->message($body);
// 		$this->email->send();

        $headers = "MIME-Version: 1.0" . "\r\n"; 
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
        mail($to, $subject, $body, $headers);
	
	}
	public function login()
	{
	    if (@$_SERVER['HTTP_REFERER'] == base_url('user-login.html')) {
			
		}else if(@$_SERVER['HTTP_REFERER'] == base_url('forget-password.html')){
			$newdata = array('redirect' => "dashboard.html");
			$this->session->set_userdata($newdata);
		}else{
		    $newdata = array('redirect' => @$_SERVER['HTTP_REFERER']);
			$this->session->set_userdata($newdata);
		}
		
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('user-login.html');
		$data["meta_author"] = base_url();
		//$data['login_url'] = $this->googleplus->loginURL();
		$this->load->view('site/login',$data);
	}
	public function loginForm()
	{
		//print_r($_POST); die();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('user_email','Email','trim|required|xss_clean');
		$this->form_validation->set_rules('user_password','Password','trim|required|xss_clean');
 
		if (($this->form_validation->run() == FALSE))
		{
			//$data['login_url'] = $this->googleplus->loginURL();
			//$this->load->view('site/login',$data);
			$this->load->view('site/login');
		}else{
			$currentUserDetail = $this->Site_Model->getSiteLogin();
			if($currentUserDetail)
				{
				 	$getDbPaas = $currentUserDetail->user_password;
					$getUserPaas = md5($this->input->post('user_password'));
	                $getbduser = $currentUserDetail->user_email;	
					$getUsername = $this->input->post('user_email');
					if($getUserPaas == $getDbPaas)
					{
						$newdata = array(
							'activeUserMail' => $currentUserDetail->user_email,
							'activeUserId'  => $currentUserDetail->user_id,
							'isUserLogged_in' => 1);
						$this->session->set_userdata($newdata);
						
				// 		if($this->session->userdata("redirect"))
				// 		{
				// 			$redirectTo = $this->session->userdata("redirect");
				// 			$removeData = array('redirect'  => "");
				// 			$this->session->unset_userdata($removeData);
				// 			redirect($redirectTo);
				// 		}
				// 		else
				// 		{
				// 			$this->session->set_flashdata('message','<span class="text-success">User Login Successfully</span>');
				// 			redirect(base_url());
				// 		}
				//$this->session->set_flashdata('message','<span class="text-success">User Login Successfully</span>');
							redirect(base_url());
					}
					else
					{
						$this->session->set_flashdata('message','<span class="text-danger">Your Password is incorrect</span>');
						$this->load->view('site/login');
					}
				}	
				else
				{
				    
				    $this->session->set_flashdata('message','<span class="text-danger">We cannot find an account with that email address</span>');
					$this->load->view('site/login');
				}
			
		}
	}

	public function show_add_sub_address(){
		$this->checkSession();
		$this->load->view('site/user/add_sub_user_address');
	}
	public function add_sub_user_address(){
		$this->checkSession();
		//print_r($_POST);die;
		$userid = $this->input->post('save_address_id');
		$this->db->set('user_id',$userid);
		$this->db->set('user_name',$this->input->post('first_name'). " " .$this->input->post('last_name'));
		$this->db->set('user_mobile',$this->input->post('phone'));
		$this->db->set('user_email',$this->input->post('email'));
		$this->db->set('user_shop',$this->input->post('outletname'));
		$this->db->set('user_gst',$this->input->post('gstnumber'));
		$this->db->set('user_state',$this->input->post('state'));
		$this->db->set('user_city',$this->input->post('city'));
		$this->db->set('user_address',$this->input->post('address'));
		$this->db->set('pin_code',$this->input->post('pincode'));
		$this->db->set('status',2);
		$sessionData = array('message'  => '<span class="text-success">Address Add Successfully !!</span>');
		  $this->session->set_userdata($sessionData);
		$this->db->insert('kh_save_address');
		
		
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function show_multi_address_edit(){

		$this->checkSession();
		$this->load->view('site/user/multi_address_edit');
	}
	

	public function dashboard()
	{
		$this->checkSession();
		$this->load->view('site/user/dashboard');
	}
	public function orderHistory()
	{
		$this->checkSession();
		$this->load->view('site/user/order-history');
	}
	public function membership()
	{
		if($this->session->userdata("isUserLogged_in")!=1){
			$newdata = array('redirect' => base_url('membership.html'));
			$this->session->set_userdata($newdata);
			redirect(base_url('user-login.html'));
		}
		$this->load->view('site/user/membership');
	}
	public function membershipbenefits()
	{
		$this->load->view('site/membership-benefits');
	}
	public function referandEarn()
	{
		$this->checkSession();
		$this->load->view('site/user/refer-and-earn');
	}

	public function notification()
	{
		if($this->session->userdata("isUserLogged_in")!=1){
			$newdata = array('redirect' => base_url('notification.html'));
			$this->session->set_userdata($newdata);
			redirect(base_url('user-login.html'));
		}
		$data['notification']=$this->Site_Model->getNotificationData();
		$this->load->view('site/user/notification',$data);
	}
	public function transaction()
	{
		$this->checkSession();
		$data['amount_transaction_list'] = $this->Site_Model->amount_transaction($this->session->userdata("activeUserId"));
		$this->load->view('site/user/transaction',$data);	
	}
	
	public function cancleOrder($orderId,$status)
	 {
	     
	       $getOrderData=$this->Site_Model->getOrderData($orderId);
	       $orderuniquecode=$getOrderData->order_unique_code;
	       $mobileNum=$getOrderData->order_phone;
	   
	     
	       
			$sms="Cancelled: Your order with order ID $orderuniquecode has been cancelled successfully.For more details visit www.rollsking.com/order-history.html";
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			//echo $response; die;
			
		   $this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
		   
		   
		   
		   
		        $walletMAmount=$getOrderData->order_discount_amount;
		        $userid=$getOrderData->order_userid;
		    
		        if($walletMAmount > 0){
                    $this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`- ".$walletMAmount." WHERE `user_id`= '".$userid."'");
        
    				$this->db->select('*');
    				$this->db->where('user_id',$userid);
    				$this->db->order_by('transaction_id','desc');
    				$this->db->limit(1);
    				$lastEntery=$this->db->get('kh_wallet_transaction')->row();
    
    				$debit_amount=$walletMAmount;
    				$available_amount=$lastEntery->transaction_available_amount - $walletMAmount;
    
    				$this->db->set('user_id',$userid);			
    				$this->db->set('transaction_from','Cashback Deduction');
    				$this->db->set('transaction_debit_amount',$debit_amount);
    				$this->db->set('transaction_available_amount',$available_amount);
    				$this->db->set('transaction_status',1);
    				$this->db->insert('kh_wallet_transaction');
    
    				$insertid=$this->db->insert_id();
    				$transaction_number="KHAQWERTYUIO00".$insertid;
    				$this->db->set('transaction_number',$transaction_number);
    				$this->db->where('transaction_id',$insertid);
    				$this->db->update('kh_wallet_transaction');
		        }
			
			
			 
	        //$orderId = base64_decode($orderId);
    	  $this->db->set("order_status",$status);
    	  $this->db->where("order_id",$orderId);
    	  $this->db->where("order_userid",$this->session->userdata("activeUserId"));
    	  $this->db->update("kh_order_tb");
		
		  $sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
		  $this->session->set_userdata($sessionData);
		redirect($_SERVER['HTTP_REFERER']);
	 }
	 public function subcancleOrder($orderId,$status)
	 {
	     
	       $getOrderData=$this->Site_Model->getOrderDatasub($orderId);
	       $orderuniquecode=$getOrderData->order_unique_code;
	       $mobileNum=$getOrderData->order_phone;
	       
	       
	       
	     
	       
			$sms="Cancelled: Your order with order ID $orderuniquecode has been cancelled successfully.For more details visit www.rollsking.com/order-history.html";
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			//echo $response; die;
			
		   $this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
		   
		   
		   
		   
		        $walletMAmount=$getOrderData->order_discount_amount;
		        $userid=$getOrderData->order_userid;
		    
		        if($walletMAmount > 0){
                    $this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`- ".$walletMAmount." WHERE `user_id`= '".$userid."'");
        
    				$this->db->select('*');
    				$this->db->where('user_id',$userid);
    				$this->db->order_by('transaction_id','desc');
    				$this->db->limit(1);
    				$lastEntery=$this->db->get('kh_wallet_transaction')->row();
    
    				$debit_amount=$walletMAmount;
    				$available_amount=$lastEntery->transaction_available_amount - $walletMAmount;
    
    				$this->db->set('user_id',$userid);			
    				$this->db->set('transaction_from','Cashback Deduction');
    				$this->db->set('transaction_debit_amount',$debit_amount);
    				$this->db->set('transaction_available_amount',$available_amount);
    				$this->db->set('transaction_status',1);
    				$this->db->insert('kh_wallet_transaction');
    
    				$insertid=$this->db->insert_id();
    				$transaction_number="KHAQWERTYUIO00".$insertid;
    				$this->db->set('transaction_number',$transaction_number);
    				$this->db->where('transaction_id',$insertid);
    				$this->db->update('kh_wallet_transaction');
		        }
			
			
			 
	        //$orderId = base64_decode($orderId);
    	  $this->db->set("order_status",$status);
    	  $this->db->where("order_id",$orderId);
    	  $this->db->where("order_userid",$this->session->userdata("activeUserId"));
    	  $this->db->update("kh_subscribe_order_tb");
		
		  $sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
		  $this->session->set_userdata($sessionData);
		redirect($_SERVER['HTTP_REFERER']);
	 }
	
	public function userProfile()
	{
		$this->checkSession();
		$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
		$this->load->view('site/user/user-profile',$data);
	}
	public function userOrderSubscription()
	{
		$this->checkSession();
		$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
		$this->load->view('site/user/order-subscription',$data);
	}

	
	public function editProfile()
	{
		$this->checkSession();
		$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
		$this->load->view('site/user/edit-profile',$data);
	}
	public function editSubmitProfile()
	{
		//print_r($_POST);
		//$this->checkSession();
	 	$this->load->library('form_validation');
		$this->form_validation->set_rules('name','Name','trim|required|xss_clean');
		//$this->form_validation->set_rules('email','Email','trim|required|xss_clean');
		$this->form_validation->set_rules('phone','Phone','trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('state','State','trim|required|xss_clean');
		$this->form_validation->set_rules('city','City','trim|required|xss_clean');
		$this->form_validation->set_rules('zipcode','Zipcode','trim|required|xss_clean');
		$this->form_validation->set_rules('address','Address','trim|required|xss_clean');

		//$this->form_validation->set_rules('gender','Gender','trim|required|xss_clean');
		if (($this->form_validation->run() == FALSE))
		{
			$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
			$this->load->view("site/user/edit-profile",$data);
		}
		else
		{
			$this->Site_Model->updateprofile();
			$message = array('message'=>'<span class="text-success">Profile Updated Successfully !!</span>');
			$this->session->set_userdata($message);
			redirect(base_url('user-profile.html'));
		}
	}
 /////////////Change Password ////////////////////////
	public function changepassword()
	{
		$this->checkSession();
		$this->load->view('site/user/change-password');
	}
	public function changepassworddata()
	{
		$this->checkSession();
		$this->form_validation->set_rules('pass','Password','trim|required|xss_clean|matches[co_pass]');
		$this->form_validation->set_rules('co_pass','Confirm Password','trim|required|xss_clean');
		
		if ($this->form_validation->run() == FALSE)
		{
			
			$this->load->view("site/user/change-password");
		}
		else
		{
			$this->Site_Model->changpass();
			$message = array('message'=>'<span class="text-success">Password Updated Successfully !!</span>');
			$this->session->set_userdata($message);
			redirect(base_url('change-password.html'));
		}
	}
//////////////////////////////////End Change Password/////////////////////////////
	///////////////////////Forget Password /////////////////
	public function forgetPassword()
	{
	    $data["meta_title"] = "Rollsking Forget Password";
		$data["meta_description"] = "Rollsking Forget Password";
		$data["meta_keywords"] = "Rollsking Forget Password";
		$data["canonical_url"] = base_url('forget-password.html');
		$data["meta_author"] = base_url();
	   $this->load->view('site/user/forget_password',$data);
	}
    public function submitForgetPassword()
	{
	    $this->load->library('form_validation');
	    $this->form_validation->set_error_delimiters('<div class="text-danger" style="font-size:13px;font-style: italic;margin-top:-5px;margin-bottom:10px;">', '</div>');
	    $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
	    if($this->form_validation->run() == FALSE){
	        $message = array('message'=>'<span class="text-success">Please Enter Your Registered email address</span>');
			$this->session->set_userdata($message);
	        redirect(base_url('forget-password.html'));
	    }else{
	        $data['userEmail']=$this->Site_Model->forgetPasswordEmail();
	        @$dbEmail=$data['userEmail']->user_email;
	        $enterEmail=$this->input->post('email');
	        if($dbEmail  == $enterEmail){
	            $to=$data['userEmail']->user_email;
	            $name=$data['userEmail']->user_name;
	            $mobileNum=$data['userEmail']->user_mobile;
	            $user_id=$data['userEmail']->user_id;
	            //$password=$data['userEmail']->user_password_text;
	            
	           $password = rand(100000, 999999);
	           $mdPassword = md5($password);
	            
	     
	           $this->db->set("user_password",$mdPassword);
 		       $this->db->set("user_password_text",$password);
	           $this->db->where('user_id',$user_id);
	           $this->db->update('kh_user_list');
	       
	        
	            
	            
	            
               /* $sms="$password is your password to log in. You can change your password anytime in your profile.";
    			
    			$forgetSMS=urlencode($sms);
    
    			$curl = curl_init();
    
    			curl_setopt_array($curl, array(
    			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$forgetSMS."&ServiceName=TEMPLATE_BASED",
    			  CURLOPT_RETURNTRANSFER => true,
    			  CURLOPT_ENCODING => "",
    			  CURLOPT_MAXREDIRS => 10,
    			  CURLOPT_TIMEOUT => 0,
    			  CURLOPT_FOLLOWLOCATION => true,
    			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    			  CURLOPT_CUSTOMREQUEST => "GET",
    			));
    
    			$response = curl_exec($curl);
    			curl_close($curl);*/
	            
	            
	            
	            
	            
	           
    	        $message = '<p>Hello '.$name.',</p>';
    			$message .= '<p>Welcome to rollsking.com. Thanks for Reset Password Request </p>';
    			$message .= '<p>Username : '.$to.'</p>';
    			$message .= '<p>Password : '.$password.'</p>';
    			$message .= '<p> </p>';
    			$message .= '<p>It looks like you requested a new password </p>';

    			$body = mailerHtml($message);

                //$body =$message;
                
    			$subject = "rollsking.com : Reset Password Request";
    			
    			$this->sendMail($to, $subject, $body);
    			$message = array('message'=>'<span class="text-success">Your change password has been sent to your registered mobile number and email id.</span>');
			    $this->session->set_userdata($message); 
			    redirect($_SERVER['HTTP_REFERER']);
			   // $this->load->view('site/login');
	            
	        }else{
	            $message = array('message'=>'<span class="text-success">We cannot find an account with that email address</span>');
			    $this->session->set_userdata($message);
			    redirect(base_url('forget-password.html')); 
	        }
	      }
	}
	 public function SubscribeNow()
	{
	 	$this->load->library('form_validation');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
		if (($this->form_validation->run() == FALSE))
		{
			// $message = array('message'=>'<span class="text-success">You Are Not Subscribed Please Try Again</span>');
			// $this->session->set_userdata($message);
			$this->session->set_flashdata('messageNot','You Are Not Subscribed Please Try Again');	
			redirect($_SERVER['HTTP_REFERER']);
		}
		else
		{
			$this->Site_Model->insertSubscribed();
			$this->session->set_flashdata('messageDone','Subscribed Successfully !!');		
			redirect($_SERVER['HTTP_REFERER']);
		}
	}
	public function shippingdelivery()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('shipping-and-delivery.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/shipping-and-delivery',$data);
	}
	public function returnsandexchanges()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('returns-and-exchanges.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/returns-and-exchanges',$data);
	}
	public function category_lists()
	{
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('category-list.html');
		$data["meta_author"] = base_url();
		$this->load->view('site/category_list',$data);
	}
	///////////////////////end Forget password /////////////////


	/////////////////////membership/////////////////////////////////
	public function purchasemembership()
	{	
		if($this->session->userdata("isUserLogged_in")!=1){
			$newdata = array('redirect' => base_url('membership.html'));
			$this->session->set_userdata($newdata);
			redirect(base_url('user-login.html'));
		}
		$id=$this->Site_Model->purchasemembership();
		redirect(base_url('Website/membership_payment/'.$id.''));
	}

public function membership_payment($membershipid)
	{
	        $data['title'] = 'Membership Payment | Daily Doze';
	        $data['getOrderData']=$this->Site_Model->getMembershipOrderData($membershipid);
	        $data['userdata']=$this->Site_Model->getUserDataForMembership($data['getOrderData']->user_id);

	        $data['order_id']=$data['getOrderData']->purchase_id;
	        $data['order_amount_with_tax']=$data['getOrderData']->pack_price;
	        $data['order_firstname']=$data['userdata']->user_name;
	        $data['order_email']=$data['userdata']->user_email;
	        $data['order_phone']=$data['userdata']->user_mobile;
	        $data['productinfo']=$data['getOrderData']->membership_id;
	        $data['return_url'] = site_url().'/membership-payment-success.html';
	        $data['surl'] = site_url().'/membership-payment-success.html';
	        $data['furl'] = site_url().'/Website/paymentFailure';
	        $data['currency_code'] = 'INR';
	        $this->load->view('site/payment/razorpay',$data);
	}


	public function membershippaymentsuccess()
	{
			//print_r($_POST); die;
	
			

			$data= array(
				'order_id' => $_POST['merchant_order_id'],
				'trans_id' => $_POST['merchant_trans_id'],
				'product_info_id' => $_POST['merchant_product_info_id'],
				'card_holder_name_id' => $_POST['card_holder_name_id'],
				'merchant_amount' => $_POST['merchant_amount'],
				'payment_status' => 1
			);
			$this->db->insert('kh_membership_payment',$data);


			$this->db->set("payment_status",1);
			$this->db->set("membership_exp",1);
			$this->db->where('purchase_id',$_POST['merchant_order_id']);
			$this->db->update("kh_purchase_membership");

			$this->db->where('purchase_id',$_POST['merchant_order_id']);
			$membershipdata=$this->db->get("kh_purchase_membership")->row();



			$data['userdata']=$this->Site_Model->getUserDataForMembership($membershipdata->user_id);

			//print_r($data['userdata']); die();
			
			$mobileNum = $data['userdata']->user_mobile;
			$username = $data['userdata']->user_name;
			$sms="Dear $username, Congratulations, you are a member of Rollsking Family. You will get exciting offers and free deliveries as applicable. To know more visit our website www.rollsking.com/membership.html";
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl); 
			
			
			
		   $this->db->set('user_id',$data['userdata']->user_id);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
			////////////////End SMS/////////////////////

			$this->load->view('site/payment/member-payment-successful');
	}
	////////////////////End membership/////////////////////////////

//     public function sendexpirysms()
// 	{
// 			$expiry_date =date('Y-m-d', strtotime(date('Y-m-d'). " + 2 day"));
// 			$this->db->select('*');
// 			$this->db->where('expiry_date',$expiry_date);
// 			$this->db->where('send_expiry_sms',0);
// 			$expired=$this->db->get('kh_purchase_membership')->result();

// 			foreach ($expired as $key => $ae) {
// 				$userdata=$this->db->select('*')->where('user_id',$ae->user_id)->get('kh_user_list')->row();
// 				$userdata->user_mobile;


// 				$this->db->set('send_expiry_sms',1);
// 				$this->db->where('purchase_id',$ae->purchase_id);
// 				$this->db->update('kh_purchase_membership');
// 			}
// 	}


	public function prosubscribe()
	{
		@$this->session->set_userdata('product_id',$this->input->post('product_id'));
		@$this->session->set_userdata('product_qty',$this->input->post('quantity'));
		@$this->session->set_userdata('subscribe_date',$this->input->post('subscribe_date'));

		$this->checkSession();
		$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
		$data["meta_title"] = "";
		$data["meta_description"] = "";
		$data["meta_keywords"] = "";
		$data["canonical_url"] = base_url('add-subscribe-checkout.html');
		$data["meta_author"] = base_url();
		$data["saveaddress"]=$this->Site_Model->getSaveAddress();
		$this->load->view('site/subscribe-checkout-billing',$data);
	}



	public function subscribe_billing_checkout()
	{
		$subscribe_date=$this->session->userdata('subscribe_date'); 
		if($subscribe_date == null){
			redirect(base_url());
		}

		$addressid=$this->uri->segment(3);
		if (empty($addressid)) {
			$this->load->library('form_validation');
			$this->form_validation->set_rules('firstname','First Name','trim|required|xss_clean');
			$this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
			$this->form_validation->set_rules('phone','Phone No.','trim|required|xss_clean');
			$this->form_validation->set_rules('state','State Name','trim|required|xss_clean');
			$this->form_validation->set_rules('address','Address','trim|required|xss_clean');
			$this->form_validation->set_rules('city','City','trim|required|xss_clean');
			$this->form_validation->set_rules('zipcode','Zipcode','trim|required|xss_clean');
		
			if (($this->form_validation->run() == FALSE))
			{
				$data['billing'] =1;
				$data["saveaddress"]=$this->Site_Model->getSaveAddress();
				$data['userDataforedit']=$this->Site_Model->getUserDataprofile();
				$this->load->view('site/subscribe-checkout-billing',$data);
			}
			else
			{
				// $saveaddress=$this->input->post('save_address');
				// if ($saveaddress == 1) {
				$this->db->set('user_id',$userid);
				$this->db->set('user_name',$this->input->post('firstname'));
				$this->db->set('user_mobile',$this->input->post('phone'));
				$this->db->set('user_email',$this->input->post('email'));
				$this->db->set('user_state',$this->input->post('state'));
				$this->db->set('user_city',$this->input->post('city'));
				$this->db->set('user_address',$this->input->post('address'));
				$this->db->set('pin_code',$this->input->post('zipcode'));
				$this->db->set('status',1);
				$this->db->insert('kh_save_address');
				// }


				$data['billing'] = 0;
				$sessionData['firstname'] = $this->input->post('firstname');
				$sessionData['email'] = $this->input->post('email');
				$sessionData['phone'] = $this->input->post('phone');
				$sessionData['state'] = $this->input->post('state');
				$sessionData['address'] = $this->input->post('address');
				$sessionData['city'] = $this->input->post('city');
				$sessionData['zipcode'] = $this->input->post('zipcode');

				$this->session->set_userdata($sessionData);
				//$this->load->view('site/checkout',$data);
				redirect(base_url('subscribe-checkout.html'));
			}
		}else{
			$query = $this->db->select('*')->where('id',$addressid)->where('status',1)->get('kh_save_address')->row();
			$data['billing'] = 0;
			$sessionData['firstname'] = $query->user_name;
			$sessionData['email'] = $query->user_email;
			$sessionData['phone'] =$query->user_mobile;
			$sessionData['state'] =$query->user_state;
			$sessionData['address'] =$query->user_address;
			$sessionData['city'] = $query->user_city;
			$sessionData['zipcode'] =$query->pin_code;
			$this->session->set_userdata($sessionData);
			//$this->load->view('site/checkout',$data);
			redirect(base_url('subscribe-checkout.html'));
		}
	}

	public function subcheckoutData()
	{
	    $this->checkSession();
		$this->load->view('site/subscribe_checkout');
	}


	public function subscribeMakePayment()
	{
	 
		
		$orderid = $this->Site_Model->subinsertorder();
		if ($this->input->post('payment_type') == 1) {
			$data['getOrderData']=$this->Site_Model->getOrderDatasub($orderid);
			$data['itemList']=$this->Site_Model->getOrderItemForSub($orderid);
			$mailBox = $this->load->view('template/invoice',$data,true);
		 	
			$email=$data['getOrderData']->order_email;
			$amount=$data['getOrderData']->order_amount;
			$orderuniquecode=$data['getOrderData']->order_unique_code;
			$name=$data['getOrderData']->order_firstname;
			$mobileNum=$data['getOrderData']->order_phone;
			///////////////////////mail//////////////////
			$config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'utf-8';
			$config['wordwrap'] = TRUE;
			$config['mailtype'] = 'html';
		 
			$this->email->initialize($config);
			
			$this->load->library('email');
			
			$this->email->reply_to('contact@rollsking.com', 'rollsking.com');
			 
			$this->email->from('contact@rollsking.com', 'rollsking.com');
			$this->email->to($email);
			$this->email->cc('contact@rollsking.com');
// 			$this->email->bcc('report@infutive.com');
			$this->email->subject("Order Invoice: rollsking.com");
			$this->email->message($mailBox);
			$this->email->send();

			//////////////////////End Mail///////////////////////

			/////////////////Add Amount In Wallet/////////////////

			$walletAmount=$this->input->post('walletAmount');
			if($walletAmount > 0){
				$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount` - ".$walletAmount." WHERE `user_id`= '".$this->session->userdata("activeUserId")."'");
				$this->db->select('*');
				$this->db->where('user_id',$this->session->userdata("activeUserId"));
				$this->db->order_by('transaction_id','desc');
				$this->db->limit(1);
				$lastEntery=$this->db->get('kh_wallet_transaction')->row();

				$debit_amount=$walletAmount;
				$available_amount=$lastEntery->transaction_available_amount - $walletAmount;

				$this->db->set('user_id',$this->session->userdata("activeUserId"));			
				$this->db->set('transaction_from','Order Payment');
				$this->db->set('transaction_debit_amount',$debit_amount);
				$this->db->set('transaction_available_amount',$available_amount);
				$this->db->set('transaction_status',1);
				$this->db->insert('kh_wallet_transaction');

				$insertid=$this->db->insert_id();
				$transaction_number="KHAQWERTYUIO00".$insertid;
				$this->db->set('transaction_number',$transaction_number);
				$this->db->where('transaction_id',$insertid);
				$this->db->update('kh_wallet_transaction');

			}


			$orderdiscountamount=$this->input->post('discountCouponAmount');
			if($orderdiscountamount > 0){
				$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ ".$orderdiscountamount." WHERE `user_id`= '".$this->session->userdata("activeUserId")."'");


				$this->db->select('*');
				$this->db->where('user_id',$this->session->userdata("activeUserId"));
				$this->db->order_by('transaction_id','desc');
				$this->db->limit(1);
				$lastEntery=$this->db->get('kh_wallet_transaction')->row();

				$credit_amount=$orderdiscountamount;
				
				if(empty($lastEntery)){
				    $available_amount=$orderdiscountamount;
				}else{
				    $available_amount=$lastEntery->transaction_available_amount + $orderdiscountamount;
				}
				$this->db->set('user_id',$this->session->userdata("activeUserId"));			
				$this->db->set('transaction_from','Cashback');
				$this->db->set('transaction_credit_amount',$credit_amount);
				$this->db->set('transaction_available_amount',$available_amount);
				$this->db->set('transaction_status',1);
				$this->db->insert('kh_wallet_transaction');

				$insertid=$this->db->insert_id();
				$transaction_number="KHAQWERTYUIO00".$insertid;
				$this->db->set('transaction_number',$transaction_number);
				$this->db->where('transaction_id',$insertid);
				$this->db->update('kh_wallet_transaction');
			}
			///////////////////////////////////////////////////////


			//////////////////////SMS///////////////////////

            $amounts ="Rs.".$amount."/-";
            $sms="Dear $name, Order Placed: Your order with order ID $orderuniquecode amounting to $amounts has been received.
We will send you an update when your order packed/shipped for more details with www.rollsking.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl); 



			$this->db->set('user_id',$data['getOrderData']->order_userid);
			$this->db->set('notification',$sms);
			$this->db->set('status',1);
			$this->db->insert('kh_notification');

			////////////////End SMS/////////////////////

			//$this->cart->destroy();

			$data['order_id']=$orderuniquecode;
			$this->load->view('site/payment/payment-successful',$data);
		}elseif ($this->input->post('payment_type') == 2) {
			$data['title'] = 'Checkout Payment | The Rollsking';
	        $data['getOrderData']=$this->Site_Model->getOrderData($orderid);
	        $data['order_id']=$orderid;
	        $data['order_amount_with_tax']=$data['getOrderData']->order_amount;
	        $data['order_firstname']=$data['getOrderData']->order_firstname;
	        $data['order_email']=$data['getOrderData']->order_email;
	        $data['order_phone']=$data['getOrderData']->order_phone;
	        $data['productinfo']=$data['getOrderData']->order_unique_code;
	        $data['return_url'] = site_url().'/sub-payment-success.html';
	        $data['surl'] = site_url().'/sub-payment-success.html';;
	        $data['furl'] = site_url().'/Website/paymentFailure';;
	        $data['currency_code'] = 'INR';
	        $this->load->view('site/payment/razorpay',$data);
		}else{
			
		}	
	}
	public function subpaymentsuccess()
	{
			// echo "<pre>";
			// print_r($_POST); die();
			$orderid=$_POST['merchant_order_id'];
			$this->Site_Model->subinsertPayment();
			$data['getOrderData']=$this->Site_Model->getOrderDatasub($orderid);
			$data['itemList']=$this->Site_Model->getOrderItemForSub($orderid);
			$mailBox = $this->load->view('template/invoice',$data,true);
		 	
			$email=$data['getOrderData']->order_email;
			$amount=$data['getOrderData']->order_amount;
			$orderuniquecode=$data['getOrderData']->order_unique_code;
			$name=$data['getOrderData']->order_firstname;
			$mobileNum=$data['getOrderData']->order_phone;
			//$testdate=$data['getOrderData']->test_date;


			$walletAmount=$data['getOrderData']->order_wallet_amount;
			if($walletAmount > 0){
				$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`- ".$walletAmount." WHERE `user_id`= '".$data['getOrderData']->order_userid."'");

				$this->db->select('*');
				$this->db->where('user_id',$data['getOrderData']->order_userid);
				$this->db->order_by('transaction_id','desc');
				$this->db->limit(1);
				$lastEntery=$this->db->get('kh_wallet_transaction')->row();

				$debit_amount=$walletAmount;
				$available_amount=$lastEntery->transaction_available_amount - $walletAmount;

				$this->db->set('user_id',$data['getOrderData']->order_userid);			
				$this->db->set('transaction_from','Order Payment');
				$this->db->set('transaction_debit_amount',$debit_amount);
				$this->db->set('transaction_available_amount',$available_amount);
				$this->db->set('transaction_status',1);
				$this->db->insert('kh_wallet_transaction');

				$insertid=$this->db->insert_id();
				$transaction_number="KHAQWERTYUIO00".$insertid;
				$this->db->set('transaction_number',$transaction_number);
				$this->db->where('transaction_id',$insertid);
				$this->db->update('kh_wallet_transaction');
			}


			$orderdiscountamount=$data['getOrderData']->order_discount_amount;
			if($orderdiscountamount > 0){
				$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ ".$orderdiscountamount." WHERE `user_id`= '".$data['getOrderData']->order_userid."'");



				$this->db->select('*');
				$this->db->where('user_id',$data['getOrderData']->order_userid);
				$this->db->order_by('transaction_id','desc');
				$this->db->limit(1);
				$lastEntery=$this->db->get('kh_wallet_transaction')->row();

				$credit_amount=$orderdiscountamount;
				$available_amount=$lastEntery->transaction_available_amount + $orderdiscountamount;

				$this->db->set('user_id',$data['getOrderData']->order_userid);			
				$this->db->set('transaction_from','Cashback');
				$this->db->set('transaction_credit_amount',$credit_amount);
				$this->db->set('transaction_available_amount',$available_amount);
				$this->db->set('transaction_status',1);
				$this->db->insert('kh_wallet_transaction');

				$insertid=$this->db->insert_id();
				$transaction_number="KHAQWERTYUIO00".$insertid;
				$this->db->set('transaction_number',$transaction_number);
				$this->db->where('transaction_id',$insertid);
				$this->db->update('kh_wallet_transaction');

			}



			//$getTimeSlot= $this->Admin_Model->getTimeSlot($data['getOrderData']->time_slot);

			////////////////////// Mail///////////////////////
			$config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'utf-8';
			$config['wordwrap'] = TRUE;
			$config['mailtype'] = 'html';
		 
			$this->email->initialize($config);
			
			$this->load->library('email');
			
			$this->email->reply_to('contact@rollsking.com', 'rollsking.com');
			 
			$this->email->from('contact@rollsking.com', 'rollsking.com');
			$this->email->to($email);
			$this->email->cc('contact@rollsking.com');
			$this->email->bcc('report@infutive.com');
			$this->email->subject("Order Invoice: rollsking.com");
			$this->email->message($mailBox);
			$this->email->send();

			//////////////////////End Mail///////////////////////

            //////////////////////SMS///////////////////////

			//$itemLists=$data['itemList'];
			// $PatientName=$data['getOrderData']->order_firstname;
			// $testName="";
			// foreach ($itemLists as $key => $value) {
			// 	$testName .=$value->name;
			// }
			

			$amounts ="Rs.".$amount."/-";
			$sms="Dear $name, Order Placed: Your order with order ID $orderuniquecode amounting to $amounts has been received.
We will send you an update when your order packed/shipped for more details with www.rollsking.com/order-history.html";
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);


			////////////////End SMS////////////////////
		//$this->cart->destroy();
		$data['order_id']=$orderid;
		$this->load->view('site/payment/payment-successful',$data);
	}
	public function productreview()
	{
		//print_r($_PSOT); die();
		$this->checkSession();
		$this->load->library('form_validation');
		$this->form_validation->set_rules('comment', 'Comment', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$sessionData = array('message'=>'<span class="text-success">Form Not Submit Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect($_SERVER['HTTP_REFERER']);
		}else{ 
		    $this->db->set('product_id',$this->input->post('product_id'));
	        $this->db->set('user_id',$this->session->userdata('activeUserId'));
	        $this->db->set('star',$this->input->post('star'));
	        $this->db->set('status',1);
	        $this->db->set('comment',$this->input->post('comment'));
	        $this->db->insert('kh_reviews');
        
        	$sessionData = array('message'=>'<span class="text-success">Your Review Submit Successfully !!</span>');
        	$this->session->set_userdata($sessionData);
        	redirect($_SERVER['HTTP_REFERER']);
		}
	}
	
	public function billpayment_view(){
		$this->checkSession();
		$url=$this->uri->segment(3);

			$data['title'] = 'Genrate INV Payment | The Rollsking';
	        $data['getinvData']=$this->Site_Model->getsinglepayment($url);
	        $data['invid']=$url;
	        $data['username']=$data['getinvData']->username;
	        $data['useremail']=$data['getinvData']->useremail;
	        $data['userphone']=$data['getinvData']->userphone;
	        $data['bill_amont']=$data['getinvData']->bill_amont;
	        // $data['return_url'] = site_url().'genrateinv-payment.html';
	        // $data['surl'] = site_url().'payment-success.html';
	        // $data['furl'] = site_url().'Website/paymentFailure';
	        $data['currency_code'] = 'INR';
		$this->load->view('site/genrateinv/genrateinv-payment',$data,$url);
	}
	
	public function genrateinvPayment(){
		//print_r($_POST);
		$this->db->set('invid',$this->input->post('invid'));
		$this->db->set('username',$this->input->post('username'));
		$this->db->set('useremail',$this->input->post('useremail'));
		$this->db->set('userphone',$this->input->post('userphone'));
		$this->db->set('billamount',$this->input->post('bill_amont'));
		$this->db->set('payment_status',1);
		$this->db->set('created_date',date('Y-m-d H:i:s'));
		$this->db->set('razorpay_payment_id',$this->input->post('razorpay_payment_id'));
		$this->db->insert('kh_inv_genrate_payment');


		$this->db->select('*');
		$this->db->where('inv_id',$this->input->post('invid'));
		$this->db->set('status',0);
		$this->db->update('kh_genrate_inv');
		//redirect($_SERVER['HTTP_REFERER']);
		redirect(base_url('genrate-payment-success.html'));
		

	}
	public function genrate_payment_success(){
		$this->checkSession();
		$this->load->view('site/genrateinv/genrate-payment-success');
	}
	public function invoice_history(){
		$this->checkSession();
		$orderid=$this->uri->segment(3);
		$data['getOrderData']=$this->Site_Model->getOrderData($orderid);
		$data['itemList']=$this->Site_Model->getOrderItemFromCheckout($orderid);
		$this->load->view('site/user/invoice',$data);
	}



}

