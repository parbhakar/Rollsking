<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __Construct()
	{
		parent::__construct();
		$this->load->model('Admin_Model');
		$this->load->model('Site_Model');
		
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="font-size:14px;font-style: italic;margin-top:5px;margin-bottom:20px;">', '</div>');
	}
	public function index()
	{
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/login',$data);
	}
	public function adminlogin()
	{
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/login',$data);
	}
	public function checkSession()
	{
		$admin_session=$this->session->userdata('login-in');
		if (!isset($admin_session)) {
			redirect(base_url()."Admin");
		}
	}
	public function httpPost($url,$params)
	{
	  $postData = '';
	   //create name value pairs seperated by &
	   foreach($params as $k => $v) 
	   { 
		  $postData .= $k . '='.$v.'&'; 
	   }
	   
	   $postData = rtrim($postData, '&');
	 
		$ch = curl_init();  
	 
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POST, strlen($postData));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
	 
		$output=curl_exec($ch);
	 
		curl_close($ch);
		return $output;
	 
	}
	public function admin_login()
	{
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('password','Password','trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('admin/login');
		}else{
			$userDbpass=$this->Admin_Model->getAdminDetail();
			if ($userDbpass) {
				$adminDbpassword=$userDbpass->password;
				$enterPassword=md5($this->input->post('password'));
				if ($adminDbpassword==$enterPassword) {
					$admin_session=array(
						'id'=>$userDbpass->id,
						'admin_name' => $userDbpass->first_name.' '.$userDbpass->last_name,
						'admin_email' => $userDbpass->email,
						'user_type' => $userDbpass->user_type,
						'admin_status'=>1
					);
					$this->session->set_userdata('login-in',$admin_session);
					$sess_data=$this->session->userdata('login-in');
					redirect(base_url()."Admin/dashboard");
				}else{
					$data['error_message']="Your Password is incorrect";
					$this->load->view('admin/login',$data);
				}
			}else{
				$data['error_message']="Email Account Doesn't Exist";
				$this->load->view('admin/login',$data);
			}
		}
	}
	public function logout()
	{
		$this->session->set_userdata('login-in');
		$this->session->sess_destroy();
		//redirect(base_url()."Admin");
		redirect(base_url()."Admin");
	}
	public function dashboard()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/maindashboard',$data);
	}
	
// 	function do_upload($fileName,$path)
// 	{
// 		$this->checkSession();
// 		$config['upload_path'] = './uploads/'.$path;
// 		$config['allowed_types'] = 'gif|jpg|jpeg|png|pdf|svg';
// 		$config['max_size']	= '20000000000000';
// 	//	$config['max_width']  = '160';
// 	//	$config['max_height']  = '190';
// 		$this->load->library('upload', $config);
		
// 		if ( ! $this->upload->do_upload($fileName))
// 		{
// 			return $error = array('error' => $this->upload->display_errors(),'upload_data' => "");
// 		}
// 		else
// 		{
// 			return $data = array('upload_data' => $this->upload->data(),'error' =>"");
// 		}
// 	}


    function do_upload($fileName,$path)
	{
		$this->checkSession();
		$config['upload_path'] = './uploads/'.$path;
		$config['allowed_types'] = 'gif|jpg|jpeg|png|pdf|svg';
		$config['max_size']	= '20000000000000';
	//	$config['max_width']  = '160';
	//	$config['max_height']  = '190';
		$this->load->library('upload', $config);
		
		if ( ! $this->upload->do_upload($fileName))
		{
			return $error = array('error' => $this->upload->display_errors(),'upload_data' => "");
		}
		else
		{
			$uploadedImage=$this->upload->data();
       	// 	if ($path == "product") {
       	// 		$this->resizeImage($uploadedImage['file_name']);
       	// 	}
			return $data = array('upload_data' => $uploadedImage,'error' =>"");

		}
	}
	public function resizeImage($filename)
    {
      $source_path = './uploads/product/'.$filename;
      $target_path = './uploads/product/thumbnail';
      $config_manip = array(
          'image_library' => 'gd2',
          'source_image' => $source_path,
          'new_image' => $target_path,
          'maintain_ratio' => TRUE,
          //'create_thumb' => TRUE,
          // 'thumb_marker' => '_thumb',
          'width' => 140,
          'height' => 140
      );
      $this->load->library('image_lib', $config_manip);
      if (!$this->image_lib->resize()) {
          echo $this->image_lib->display_errors();
      }
      $this->image_lib->clear();
   }
	

	public function downloadDb()
	{
		$this->load->dbutil();
		$prefs = array(     
		    'format'      => 'zip',             
		    'filename'    => 'classified.sql'
		    );


		@$backup =& $this->dbutil->backup($prefs); 

		$db_name = 'kiranewala-db-backup-on-'. date("Y-m-d-H-i-s") .'.zip';
		$save = 'uploads/databasebackup/'.$db_name;

		$this->load->helper('file');
		write_file($save, $backup);
	}

	public function downloadDbManual()
	{
		$this->checkSession();
		$this->load->dbutil();
		$prefs = array(     
		    'format'      => 'zip',             
		    'filename'    => 'classified.sql'
		    );


		@$backup =& $this->dbutil->backup($prefs); 

		$db_name = 'kiranewala-db-backup-on-'. date("Y-m-d-H-i-s") .'.zip';
		$save = 'uploads/databasebackup/'.$db_name;

		$this->load->helper('file');
		write_file($save, $backup);

		$this->load->helper('download');
		force_download($db_name, $backup);


	    $admin_session=$this->session->userdata('login-in'); 
		$customerData ="";
		$userdata = $this->Admin_Model->getEmployeeDataForMailDatabase($admin_session['id']);
		$customerData .= "Name : ".$userdata->first_name." ".$userdata->last_name."<br>";
		$customerData .= "Phone : ".$userdata->phone."<br>";
		$customerData .= "Email : ".$userdata->email."<br>";
		$customerData .= "Address : ".$userdata->address."<br>";
		
		$MailBody =  mailerHtml($customerData);
		$subjectData = "kiranewala Database Downloading...";
	    $mailSender = $this->sendEmail($tomail,$subjectData, $MailBody);
	
		redirect(base_url('Admin/dashboard'));
	}

	////////////////////////////////////Manu//////////////////////////////
	public function menu_management()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();	
		$data['menus']=$this->Admin_Model->get_all_menus();
		$data['role_data']=$this->Admin_Model->get_all_role();
		//$data['main_content']='admin_files/admin_menu';
		$this->load->view('admin/menu/menu',$data);
	}


	public function add_menu()
	{
		$this->checkSession();
		$this->Admin_Model->add_menu();
		redirect($_SERVER['HTTP_REFERER']);
	}


	public function edit_menu_page($menuid)
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();	
		$data['menus']=$this->Admin_Model->get_menu_byid($menuid);
		$data['menuslist']=$this->Admin_Model->get_all_menus();
		$data['role_data']=$this->Admin_Model->get_all_role();
		$data['menu_list']='menu_management';
		$this->load->view('admin/menu/edit_menu',$data);

	}

	public function edit_menu()
	{
		$this->checkSession();
		$this->Admin_Model->edit_menu($_POST);
	}

	public function delete_menu()
	{
		$this->checkSession();
		$data=$this->Admin_Model->delete_menu($_POST);
		if($data){
	 		echo json_encode("Menu deleated Successfully");
	 	}else{
	 		echo json_encode("Menu deletion Failed");
	 	}
	}
	////////////////////////////////End Menu//////////////////////////
	///////////////////////////////Emp User Managment/////////////////////



////////////////////  Function to show user list ///////////////////////////////////

	public function show_user_list()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['users_list']=$this->Admin_Model->show_user_list();
		$this->load->view('admin/users/userlist',$data);
	}
	////////////////////  Function to show add user page ///////////////////////////////////

	public function show_add_user()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['user_type_list']=$this->Admin_Model->get_user_type_new();
		$this->load->view('admin/users/adduser',$data);
	}

	public function show_add_sub_users()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		//$data['user_type_list']=$this->Admin_Model->get_user_type_new();
		$this->load->view('admin/users/add_subuser',$data);
	}



	
	////////////////////  Function to add user ///////////////////////////////////

	public function add_user()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->Admin_Model->add_user($_POST);
	}
	public function add_sub_users(){
		 //return $this->Admin_Model->add_sub_users();
		 
		$password = $this->input->post('password');
		$confirm_password = $this->input->post('confirm_password');
		if($password == $confirm_password){
			
			return $this->Admin_Model->add_sub_users();
		}else{
				  echo '<script>alert("Please Enter Confirm Password");</script>';
					echo  "<script>window.location='".base_url()."Admin/show_add_sub_users'</script>";	
		}
		//print_r($_POST);
	}
	////////////////////  Function to show edit user ///////////////////////////////////
	public function show_edit_user($user_id)
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data["user_specific_data"]=$this->Admin_Model->show_edit_user($user_id);
		$data["user_role"]=$this->Admin_Model->get_user_type_new();
		$data["title"]="Edit User";
		$this->load->view("admin/users/edituser",$data);
	}
	////////////////////  Function to edit user ///////////////////////////////////

	public function edit_user()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->Admin_Model->edit_user($_POST);
	}

	///////////////////////  Function to  delete user  /////////////////////////////////////////////////

    public function deleteUsers()
    {
    	$this->checkSession();
    	$result=$this->Admin_Model->deleteUser($_POST);  
    	if($result){
    		echo json_encode("User Deleted successfully");
    	}else{
    		echo json_encode("User Deletion Failed");
    	}
    }
    ///////////////////////  Function to  Deactivate user status /////////////////////////////////////////////////

    public function DeactivateUser()
    {
    	$this->checkSession();
    	$result=$this->Admin_Model->DeactivateUser($_POST);
    	if($result){
    		echo json_encode("User Deactivated successfully");
    	}else{
    		echo json_encode("User Deactivated Failed");
    	}  	
    }
    ///////////////////////  Function to  Activate user status  /////////////////////////////////////////////////

    public function ActivateUser()
    {
    	$this->checkSession();
    	$result=$this->Admin_Model->ActivateUser($_POST);
    	if($result){
    		echo json_encode("User Activated successfully");
    	}else{
    		echo json_encode("User Activated Failed");
    	}  	
    }

  //   public function get_all_staff_member()
  //   {
		// $data['adminData']=getAdminDetails();
		// $data['users_list']=$this->Admin_Model->get_all_staff_member();
		// $data["title"]="All Users";
		// $this->load->view('admin/users/stafflist',$data);

  //   }
	//////////////////////////////End Emp User Managemnt//////////////////// 

    ///////////////////////////////////////////GROUP///////////////////////////////

    ////  Functiosn to show add employee group page ///////////////////////////////////

	public function show_add_employee_group_page()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['menu_data']=$this->Admin_Model->get_menu_for_permission();
		$data["title"]="Add Employee Group";
		$this->load->view('admin/group/add_employee_group',$data);
	}

	////////////////////  Function to add employee group  ///////////////////////////////////

	public function add_employee_group()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->Admin_Model->add_employee_group($_POST);
	}
	///////////////////// Funtion to show assign permission page /////////////////////////
	public function assign_group_permission_page()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['employee_group_data']=$this->Admin_Model->assign_group_permission_page();
		$this->load->view('admin/group/assign_group_permision_page');
	}

	//////////////////// Function to manage employee group ///////////////////////////////////////

	public function show_manage_employee_group()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['employee_group_data']=$this->Admin_Model->get_all_employee_group();
		$data['title']="Admin_Model Group";
		$this->load->view('admin/group/manage_employee_group',$data);
	}
	//////////////////// function to edit employee group details ///////////////////////////////////
	public function show_employee_group_edit($employee_group_id)
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['employee_group_detail']=$this->Admin_Model->get_employee_group_specific($employee_group_id);
		$data['menu_data']=$this->Admin_Model->get_menu_for_permission();
		$data['exist_menu_of_group']=$this->Admin_Model->get_assigned_menu_of_group($employee_group_id);
		$data['title']="Group Edit";
		$this->load->view('admin/group/manage_employee_group_edit',$data);
	}
	////////////////// Function to edit employee group detail  //////////////////////////////////////////

	public function edit_employee_group()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->Admin_Model->edit_employee_group($_POST);
	}

	//////////////////  function to deactivate employee group  //////////////////////////////////////////

	public function DeactivateEmployeeGroup()
	{
		$this->checkSession();
    	$result=$this->Admin_Model->DeactivateEmployeeGroup($_POST);
    	if($result){
    		echo json_encode("Group Deactivated successfully");
    	}else{
    		echo json_encode("Group Deactivated Failed");
    	}
	}

	//////////////////  function to Activate employee group  //////////////////////////////////////////
	public function ActivateEmployeeGroup()
	{
		$this->checkSession();
			$result=$this->Admin_Model->ActivateEmployeeGroup($_POST);
			if($result){
				echo json_encode("Group Activated successfully");
			}else{
				echo json_encode("Group Activated Failed");
			}
	}
	//////////////////  function to show add employee page  //////////////////////////////////////////

	
	///////////////////////////////////  Function to Delete Employee  ////////////////////////////////////////////////////
	public function deleteEmployee()
	{
		$this->checkSession();
		$result=$this->Admin_Model->DeleteEmployee($_POST);
		if($result==TRUE){
			echo json_encode("Group Deleted Successfully");
		}else{
			echo json_encode("Group Deletion Failed");
		}
	}


	///////////////////////////  Function to assign groups to a particular groups ////////////////////////////////

	

	/////////////////////  Function to show assigned groups ///////////////////////////////////////////////////

	public function show_assigned_group()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['group_data']=$this->Admin_Model->get_all_employee_group();
		$data['title']="Assigned User Group";
		$this->load->view('admin/group/show_assigned_user',$data);
	}

	/////////////////////  Function to show assigned groups by id ///////////////////////////////////////////////////
	public function get_assigned_group_by_id()
	{
		$this->checkSession();
		$data=$this->Admin_Model->get_assigned_group_by_id($_POST);		
		if($data){
			echo  json_encode($data);
		}else{
			$data="notfound";
			echo  json_encode($data);
		}	
	}
	/////////////////////////////////////////End Group////////////////////////////////////



	/////////////////////////Login  User////////////////////////////////
	public function stafflogins()
	{
		$this->checkSession();
   		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/logins/logins-list',$data);
	}

	///////////////////////End Logins User/////////////////////////////
	/////////////////////////change password///////////////////////////
	public function changepassword()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/password/change-password',$data);
	}
	public function changepassworddata()
	{
		$this->checkSession();
		$this->form_validation->set_rules('pass','Password','trim|required|xss_clean|matches[co_pass]');
		$this->form_validation->set_rules('co_pass','Confirm Password','trim|required|xss_clean');
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData'] =getAdminDetails();
			$this->load->view('admin/password/change-password',$data);
		}
		else
		{
			$this->Admin_Model->changpass();
			$message = array('message'=>'<span class="text-success">Password Updated Successfully !!</span>');
			$this->session->set_userdata($message);
			redirect(base_url('Admin/changepassword'));
		}
	}
	/////////////////////////End change password///////////////////////////

	///////////////////////Forget Password /////////////////
	public function forgetPassword()
	{
	   $this->load->view('admin/forget_password');
	}
	public function submitForgetPassword()
	{
	    $this->load->library('form_validation');
	    $this->form_validation->set_error_delimiters('<div class="text-danger" style="font-size:13px;font-style: italic;margin-top:-5px;margin-bottom:10px;">', '</div>');
	    $this->form_validation->set_rules('email','Email','trim|required|valid_email|xss_clean');
	    if($this->form_validation->run() == FALSE){
	        redirect(base_url('Admin/forgetPassword'));
	    }else{
	        $data['userEmail']=$this->Admin_Model->forgetPasswordEmail();
	        @$dbEmail=$data['userEmail']->email;
	        $enterEmail=$this->input->post('email');
	        if($dbEmail  == $enterEmail){
	            $to=$data['userEmail']->email;
	            $name=$data['userEmail']->first_name.' '.$data['userEmail']->last_name;
	            $user_id=$data['userEmail']->id;
	            $password = rand(99999,9999999999);
	            $mdPassword = md5($password);
	            
	     
	            $this->db->set("password",$mdPassword);
 			    $this->db->set("text_password",$password);
	            $this->db->where('id',$user_id);
	            $this->db->update('dev_admin');
	            
	           
    	        $message = '<p>Hello '.$name.',</p>';
    			$message .= '<p>Welcome to kiranewala.com. Thanks for Reset Password Request </p>';
    			$message .= '<p>Username : '.$to.'</p>';
    			$message .= '<p>Password : '.$password.'</p>';
    			$message .= '<p> </p>';
    			$message .= '<p>It looks like you requested a new password </p>';

    			$body = mailerHtml($message);
    			
    			$subject = "Star Imaging : CRM Reset Password Request";
    			
    			$this->sendEmail($to, $subject, $body);
    			$message = array('message'=>'<span>We Send Your Password Your Email Address</span>');
			    $this->session->set_userdata($message);
			    redirect(base_url('Admin/forgetPassword')); 
	            
	        }else{
	            $message = array('message'=>'<span>We cannot find email address</span>');
			    $this->session->set_userdata($message);
			    redirect(base_url('Admin/forgetPassword')); 
	        }
	      }
	}

	///////////////////////end Forget password /////////////////


	/////////////////////////////////all lab code////////////////////

	public function userlist()
	{	
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		
		
		$config = array();
        $config["base_url"] = base_url()."Admin/userlist";
        $config["total_rows"] = $this->Admin_Model->countgetAllUserRegistered();
        
        //print_r($config["total_rows"]); die;
        $config["per_page"] = 25;
        $config["uri_segment"] = 3;
        $config['enable_query_strings'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["links"] = $this->pagination->create_links();
        $data['userList'] = $this->Admin_Model->getAllUserRegistered($config["per_page"],$page);
        //print_r($data['userList']); die;
		
		$this->load->view('admin/users/user_registered_list',$data);	
	}
	public function referrallist()
	{	
		$this->checkSession();
		$refer_id=base64_decode($this->uri->segment(3));
		$data['adminData'] =getAdminDetails();
		$data['userList'] = $this->Admin_Model->getAllUserRefferUser($refer_id);
		//print_r($data['userList'] ); die();
		$this->load->view('admin/users/referral-list',$data);	
	}

	public function amount_transaction()
	{	
		$this->checkSession();
		$userid=base64_decode($this->uri->segment(3));
		$data['adminData'] =getAdminDetails();
		$data['amount_transaction_list'] = $this->Admin_Model->amount_transaction($userid);
		$this->load->view('admin/users/transaction',$data);	
	}
	public function add_cashback()
	{	
	    if($this->uri->segment(3) == null){
	       redirect(base_url('Admin/userlist'));
	    }
		$this->checkSession();
		$data['userid']=base64_decode($this->uri->segment(3));
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/users/add_cashback',$data);	
	}
	
	public function submitcashback()
	{
	    $userid=$this->input->post('userid');
	    $cashback_amount=$this->input->post('cashback_amount');
	    $cashback_remark=$this->input->post('cashback_remark');
	    
	       $getuserdata= $this->db->select('*')->where('user_id',$userid)->get('kh_user_list')->row();
	    
	        $mobileNum = $getuserdata->user_mobile;
	        $amounts ="Rs.".$cashback_amount."/-";
            $sms="Your cashback of $amounts has been added to your kiranewala wallet in lieu of $cashback_remark";
			
			$cashbackSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$cashbackSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl); 



			$this->db->set('user_id',$userid);
			$this->db->set('notification',$sms);
			$this->db->set('status',1);
			$this->db->insert('kh_notification');
	    
	    
	  
	    
	    $this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ ".$cashback_amount." WHERE `user_id`= '".$userid."'");
        $this->db->select('*');
        $this->db->where('user_id',$userid);
        $this->db->order_by('transaction_id','desc');
        $this->db->limit(1);
        $lastEntery=$this->db->get('kh_wallet_transaction')->row();
        
        $credit_amount=$cashback_amount;
        
        if(empty($lastEntery)){
            $available_amount=$cashback_amount;
        }else{
            $available_amount=$lastEntery->transaction_available_amount + $cashback_amount;
        }
        
        $this->db->set('user_id',$userid);			
        $this->db->set('transaction_from',$cashback_remark);
        $this->db->set('transaction_credit_amount',$credit_amount);
        $this->db->set('transaction_available_amount',$available_amount);
        $this->db->set('transaction_status',1);
        $this->db->insert('kh_wallet_transaction');
        
        $insertid=$this->db->insert_id();
        $transaction_number="KHAQWERTYUIO00".$insertid;
        $this->db->set('transaction_number',$transaction_number);
        $this->db->where('transaction_id',$insertid);
        $this->db->update('kh_wallet_transaction');
        
        $sessionData = array('message'=>'<span class="text-success">Cashback Added Successfully !!</span>');
		$this->session->set_userdata($sessionData);
        redirect($_SERVER['HTTP_REFERER']);
	}

	////////////////////////////////////////////Company/////////////////////////////////////
	public function companyList()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$data['allElement']=$this->Admin_Model->getAllCompany();
		// print_r($data['allElement']); die();
		$this->load->view('admin/branch/company_list',$data);
	}
	public function addCompany()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$data['stateList']=$this->Admin_Model->getState();
		$this->load->view('admin/branch/add_company',$data);
	}
	public function submitCompany()
	{
		$this->checkSession();
		$this->form_validation->set_rules('company_name', 'Company Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_cin', 'CIN Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_regis_no', 'Registration Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_gst_no', 'GST Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_phone', 'Phone Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_email', 'Email ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_address', 'Address', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_state', 'State', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_city', 'City', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_zip', 'Zip Code', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('admin/add_company');
		}
		else
		{   
			$logoData = $this->do_upload('company_logo','company_logo');
			$logoName = $logoData["upload_data"]["file_name"];

			$this->Admin_Model->addCompany($logoName);
			$sessionData = array('message'=>'<span class="text-success">Company Added Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/companyList"));
		}
	}
	public function companyStatus($companyId,$status)
	{
		$this->checkSession();
		$this->db->set("company_status",$status);
		$this->db->where("company_id",$companyId);
		$this->db->update("kh_company");
		$sessionData = array('message'  => '<span class="text-success">Company Status Updated Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/companyList'));
	}
	public function companyDelete($companyId,$status)
	{	
		$this->checkSession();
		$this->db->set("company_status",$status);
		$this->db->where("company_id",$companyId);
		$this->db->update("kh_company");

		$this->db->set("bra_status",$status);
		$this->db->where("bra_company_id",$companyId);
		$this->db->update("kh_branch");


		$sessionData = array('message'  => '<span class="text-success">Company Delete Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/companyList'));
	}

	public function eidtCompany()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$id=$this->uri->segment(3);
		$data['com_info'] = $this->Admin_Model->getCompanyForEdit($id);
		$data['stateList']=$this->Admin_Model->getState();
		$this->load->view('admin/branch/edit_company',$data);
	}
	public function updateCompany()
	{
		$this->checkSession();
		$this->form_validation->set_rules('company_id', 'Company id', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_name', 'Company Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_cin', 'CIN Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_regis_no', 'Registration Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_gst_no', 'GST Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_phone', 'Phone Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_email', 'Email ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_address', 'Address', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_state', 'State', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_city', 'City', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_zip', 'Zip Code', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData'] =getAdminDetails();
			$data['com_info'] = $this->Admin_Model->getCompanyForEdit($this->input->post('company_id'));
			$data['stateList']=$this->Admin_Model->getState();
			$this->load->view('admin/branch/edit_company',$data);
		}
		else
		{      

			if($_FILES['company_logo']['size']>0)
			{
				$logoData = $this->do_upload('company_logo','company_logo');
				$logoName = $logoData["upload_data"]["file_name"];
			}
			else{
				$logoName = NULL;
			}	
			$this->Admin_Model->updateCompany($logoName);

			$sessionData = array('message'  => '<span class="text-success">Company Updated Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/companyList"));
		
		}
	}
	////////////////////////////////////////////End Company/////////////////////////////////////
	///////////////////////////////////////////branch//////////////////////////////////////
	public function branchList()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$data['companyList']=$this->Admin_Model->getCompanyForLab();
		$data['branchList']=$this->Admin_Model->getLabs();
		$data['stateList']=$this->Admin_Model->getState();
		$this->load->view('admin/branch/branch_list',$data);
	}
	public function branchStatus($bra_status,$status)
	{
		$this->checkSession();
		$this->db->set("bra_status",$status);
		$this->db->where("bra_id",$bra_status);
		$this->db->update("kh_branch");
		$sessionData = array('message'  => '<span class="text-success">Branch Status Updated Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/branchList'));
	}
	public function  branchDelete($bra_id,$status)
	{
		$this->checkSession();
		//$this->db->set("bra_status",$status);
		$this->db->where("bra_id",$bra_id);
		$this->db->delete("kh_branch");

		$sessionData = array('message'  => '<span class="text-success">Branch Delete Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/branchList'));
	}

	public function addbranch()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$data['stateList']=$this->Admin_Model->getState();
		$data['companyList']=$this->Admin_Model->getCompanyForLab();	
		//print_r($data['companyList']); die();	
		$this->load->view('admin/branch/add_branch',$data);
	}

	public function submitbranch()
	{
		$this->checkSession();
		$this->form_validation->set_rules('bra_company_id', 'Company ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_name', 'Lab Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_address', 'Lab Address', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_state', 'Lab State', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_city', 'Lab City', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_zip', 'Lab Zip', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_lat', ' Latitude', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_long', 'longitude', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData'] =getAdminDetails();
			$data['stateList']=$this->Admin_Model->getState();
			$data['companyList']=$this->Admin_Model->getCompanyForLab();
			$this->load->view('admin/branch/add_branch',$data);
		}
		else
		{   
			$this->Admin_Model->addBranch();
			$sessionData = array('message'=>'<span class="text-success">Branch Added Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/branchList"));
		}
	}
	public function editbranch()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$id=$this->uri->segment(3);
		$data['bra_info'] = $this->Admin_Model->getLabForEdit($id);
		$data['companyList']=$this->Admin_Model->getCompanyForLab();	
		$data['stateList']=$this->Admin_Model->getState();
		$this->load->view('admin/branch/edit_branch',$data);
	}
	public function updatebranch()
	{
		$this->checkSession();
		$this->form_validation->set_rules('bra_id', 'Lab ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_company_id', 'Company ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_name', 'Lab Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_address', 'Lab Address', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_state', 'Lab State', 'trim|required|xss_clean');
		$this->form_validation->set_rules('company_city', 'Lab City', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_zip', 'Lab Zip', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_lat', ' Latitude', 'trim|required|xss_clean');
		$this->form_validation->set_rules('bra_long', 'longitude', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData'] =getAdminDetails();
			$data['Lab_info'] = $this->Admin_Model->getLabForEdit($this->input->post('bra_id'));
			$data['companyList']=$this->Admin_Model->getCompanyForLab();	
			$data['stateList']=$this->Admin_Model->getState();
			$this->load->view('admin/branch/add_branch',$data);
		}
		else
		{   
			$this->Admin_Model->editBranch();
			$sessionData = array('message'=>'<span class="text-success">Branch Updated Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/branchList"));
		}
	}
	///////////////////////////////////////////End Labs//////////////////////////////////////
	public function getCityForAjax($state_id)
	{
       $city_list = $this->db->where("state_id",$state_id)->get("kh_city")->result();
       echo json_encode($city_list);
	}

	////////////////////////////////////category///////////////////////////////////////////
	function category()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$data['allElement']=$this->Admin_Model->getAllCategory();
		$this->load->view('admin/category/category_list',$data);
	}

    function categorystatus($catId,$status)
	{
		$this->checkSession();
		$this->db->set("category_status",$status);
		$this->db->where("category_id",$catId);
		$this->db->update("kh_category");
		
		$sessionData = array('message'  => '<span class="text-success">Category Status Updated Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/category/'));
	}

	  function addressstatus($catId,$status)
	{
		$this->checkSession();
		$this->db->set("ch_payment_status",$status);
		$this->db->where("user_id",$catId);
		$this->db->update("kh_user_list");
		
		$sessionData = array('message'  => '<span class="text-success">Payment Status Updated Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/userlist/'));
	}
 
	function deletecategory($cat)
	{
		$this->checkSession();
		$this->db->where("category_id",$cat);
		$this->db->delete("kh_category");
		
// 		$this->db->set("category_status",3);
// 		$this->db->where("category_id",$cat);
// 		$this->db->update("kh_category");

		$sessionData = array('message'  => '<span class="text-success">Category Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url()."Admin/category");
	}
	
 
	function addcategory()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->load->view('admin/category/add_category',$data);
	}
	
	function addcategorydata()
	{
		$this->checkSession();
		$this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('category_parent', 'Category Parent', 'trim|xss_clean');
		$this->form_validation->set_rules('cate_desc', 'Category Desc', 'trim|required|xss_clean');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_description', 'Meta Description', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_keyword', 'Meta Keyword', 'trim|xss_clean');
	
		if ($this->form_validation->run() == FALSE)
		{
			
			$data['adminData']=getAdminDetails();
			$this->load->view('admin/category/add_category',$data);
		}
		else
		{      
			$coverData = $this->do_upload('category_image','category');
			$cover = $coverData['upload_data']['file_name'];

			$this->Admin_Model->addcategry($cover);

			$sessionData = array('message'  => '<span class="text-success">Category Added Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/category"));
		
		}
	}
	
	function editcategory($catid)
	{
		$data['adminData']=getAdminDetails();
		$data['cat_info'] = $this->Admin_Model->getCategory($catid);
		$this->load->view('admin/category/edit_category',$data);
	}
	
	function updatecategory()
	{
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('category_parent', 'Category Parent', 'trim|xss_clean');
		$this->form_validation->set_rules('cate_desc', 'Category Desc', 'trim|required|xss_clean');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_description', 'Meta Description', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_keyword', 'Meta Keyword', 'trim|xss_clean');
		
	
		if ($this->form_validation->run() == FALSE)
		{
			$data['cat_info'] = $this->Admin_Model->getCategory($this->input->post('category_id'));
			$this->load->view('admin/category/edit_category',$data);
		}
		else
		{      
			if($_FILES['category_image']['size']>0)
			{
				$logoData = $this->do_upload('category_image','category');
				$cover = $logoData["upload_data"]["file_name"];
			}
			else{
				$cover = NULL;
			}	

			$this->Admin_Model->updateCategry($cover);

			$sessionData = array('message'  => '<span class="text-success">Category Updated Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("admin/category"));
		
		}
	}
	////////////////////////////////////End category///////////////////////////////////
////////////////////////////////////////////////couponcode//////////////////////////////////////

	public function coupan()
	{
		$data['adminData']=getAdminDetails();
		$data['coupan_list'] = $this->Admin_Model->coupan_list();
		$this->load->view('admin/coupan/add_coupan',$data);
	}


    public function deletecoupon($id)
	{
	   $this->db->select("*");
		$this->db->where("coupon_id",$id);
		// $this->db->set("coupon_status",$status);
		$this->db->delete("kh_couponcode");
	
		$sessionData = array('message'  => '<span class="text-success alert alert-success">Coupon Deleted Successfully.</span>');
		$this->session->set_userdata($sessionData);
		
		redirect(base_url("admin/coupan"));
		// header("Location:".base_url("admin/coupan"));
		
	}
		
	public function savecoupon()
	{
		$data['coupan_list'] = $this->Admin_Model->coupan_list();
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="text-danger" style="font-size:12px;font-style: italic;margin-top:-10px;margin-bottom:20px;">', '</div>');
		$this->form_validation->set_rules('coupon_code','Coupon Code','trim|required|is_unique[kh_couponcode.coupon_code]');
		$this->form_validation->set_rules('coupan_used_type','Coupon type','trim|required');
		$this->form_validation->set_rules('coupan_discount_type','Discount Type','trim|required');
		$this->form_validation->set_rules('coupan_discount_value','Discount Value','numeric|trim|required');
		$this->form_validation->set_rules('coupon_valid_upto','Valid Upto','trim|required');
		$this->form_validation->set_rules('coupon_discount_limit','Max Discount Value','numeric|trim|required');
		$this->form_validation->set_rules('coupon_minimun_limit','Minimum Amount','numeric|trim|required');
		$this->form_validation->set_rules('coupon_title','Coupon Title','trim|required');
		$this->form_validation->set_rules('coupon_description','Coupon Description','trim|required');
		 
		if (($this->form_validation->run() == FALSE))
		{
			$data['adminData']=getAdminDetails();
			$this->load->view('admin/coupan/add_coupan',$data);			
		}
		else
		{
			$this->Admin_Model->coponNew();
			$sessionData = array('message'  => '<span class="text-success">Coupon Added successfully !!</span>');
			$this->session->set_userdata($sessionData);
			header("Location:".base_url("Admin/coupan"));
		}
	}


	////////////////////////////////////////////////couponcode//////////////////////////////////////


	/////////////////////////////////////////////Site Setting/////////////////////////////////////

	public function siteSetting()
	{
		$data['adminData']=getAdminDetails();
		$data['setting'] = $this->Admin_Model->getSetting();
		$this->load->view("admin/setting/site_setting",$data);
	}
	
	public function insertSiteSetting()
	{
		$this->Admin_Model->updateSetting();
		$sessionData = array('message'  => '<span class="text-success">Setting Updated successfully !!</span>');
		$this->session->set_userdata($sessionData);
		redirect(base_url("admin/siteSetting"));
	}
	//////////////////////////////////////////////end Site Setting////////////////////////////////

	////////////////////////////////////Contact List//////////////////////////////////////////
	public function contactlist()
	{
		$data['adminData'] =getAdminDetails();
		$data['allContactQuery'] =  $this->Admin_Model->getContactQuery();
		$this->load->view('admin/contact/contact_list',$data);	
	}
	
	public function deleteQuery($qId)
	{
		$this->db->where("contact_id",$qId);
		$this->db->delete("kh_contact_query");
		$sessionData = array('message'  => '<span class="text-success alert alert-success">Qurey Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		redirect("admin/contactlist");
	}

	///////////////////////////////////Contact List /////////////////////////////////////////


	//////////////////////////////////test_collection_user////////////////////////////////////

	public function testcollectionuser()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$data['userList'] = $this->Admin_Model->getAllCollectionUserRegistered();
		$this->load->view('admin/users/test_collection_user_list.php',$data);
	}
	public function addtestcollectionuser()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/users/add_test_collection_user',$data);
	}
	public function submittestcollectionuser()
	{
		$this->checkSession();
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_email', 'User Email', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_mobile', 'Mobile Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_password', 'Password', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_state', 'State', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_city', 'City', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_address', 'Address', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_zipcode', 'State', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('admin/users/add_test_collection_user');
		}
		else
		{   
			$imgData = $this->do_upload('user_img','test_collection_user_img');
			$profileImg = $imgData["upload_data"]["file_name"];

			$this->Admin_Model->addTestCollectionUser($profileImg);
			$sessionData = array('message'=>'<span class="text-success">Test Collection User Added Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/testcollectionuser"));
		}
	}
	public function edittestcollectionuser()
	{
		$this->checkSession();
		$id=$this->uri->segment(3);
		$data['adminData'] =getAdminDetails();
		$data['getEditTestCollectionUser']=$this->Admin_Model->getTestCollectionUserData($id);
		$this->load->view('admin/users/edit_test_collection_user',$data);
	}
	public function submitedittestcollectionuser()
	{
		$this->checkSession();
		$this->form_validation->set_rules('user_id', 'User id', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_email', 'User Email', 'trim|xss_clean');
		$this->form_validation->set_rules('user_mobile', 'Mobile Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_password', 'Password', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_state', 'State', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_city', 'City', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_address', 'Address', 'trim|required|xss_clean');
		$this->form_validation->set_rules('user_zipcode', 'State', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData'] =getAdminDetails();
			$data['getEditTestCollectionUser']=$this->Admin_Model->getTestCollectionUserData($this->input->post('user_id'));
			$this->load->view('admin/users/edit_test_collection_user',$data);
		}
		else
		{   
			

			if($_FILES['user_img']['size']>0)
			{
				$imgData = $this->do_upload('user_img','test_collection_user_img');
				$profileImg = $imgData["upload_data"]["file_name"];
			}
			else{
				$profileImg = NULL;
			}	

			$this->Admin_Model->eidtTestCollectionUser($profileImg);
			$sessionData = array('message'=>'<span class="text-success">Test Collection User Edit Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/testcollectionuser"));
		}
	}

	public function  testcollectionuserStatus($user_id,$status)
	{
		$this->checkSession();
		$this->db->set("user_status",$status);
		$this->db->where("user_id",$user_id);
		$this->db->update("kh_test_collection_user");
		$sessionData = array('message'  => '<span class="text-success">User Status Updated Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/testcollectionuser'));
	}
	public function  testcollectionuserDelete($user_id,$status)
	{
		$this->checkSession();
		$this->db->set("user_status",$status);
		$this->db->where("user_id",$user_id);
		$this->db->update("kh_test_collection_user");
		$sessionData = array('message'  => '<span class="text-success">User Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		header("Location:".base_url('Admin/testcollectionuser'));
	}

	public function searchPhleboslotOrder()
	{
		$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/users/search_slot',$data);
	}
	///////////////////////////////test_collection_user///////////////////////////////////////

	///////////////////////////////////////////////order /////////////////////////////////////
	
	public function orderlist()
	{
		 
	    $this->checkSession();
		$data['adminData'] =getAdminDetails();
		$session_data=$this->session->userdata('login-in');
		if ($session_data['user_type'] ==1 || $session_data['user_type'] ==2 || $session_data['user_type'] ==3 || $session_data['user_type'] ==4) {
       	
			@$fromdate=$this->input->get('fromdate');
			@$todate=$this->input->get('todate');
			@$paid_unpaid=$this->input->get('paid_unpaid');
			@$sales=$this->input->get('sales');
			
			    $config = array();
                $config["base_url"] = base_url()."Admin/orderlist";
                $config["total_rows"] = $this->Admin_Model->countorderDatas($fromdate,$todate,$paid_unpaid,$sales);
                $config["per_page"] = 25;
                $config["uri_segment"] = 3;
                $config['enable_query_strings'] = TRUE;
                $config['reuse_query_string'] = TRUE;
                
                $config['full_tag_open'] = '<ul class="pagination">';
                $config['full_tag_close'] = '</ul>';
                $config['first_link'] = 'First';
                $config['last_link'] = 'Last';
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['prev_link'] = 'Prev';
                $config['prev_tag_open'] = '<li class="prev">';
                $config['prev_tag_close'] = '</li>';
                $config['next_link'] = 'Next';
                $config['next_tag_open'] = '<li>';
                $config['next_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $config['cur_tag_open'] = '<li class="active"><a href="#">';
                $config['cur_tag_close'] = '</a></li>';
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data["links"] = $this->pagination->create_links();
                $data['orderData'] = $this->Admin_Model->orderDatas($config["per_page"],$page,$fromdate,$todate,$paid_unpaid,$sales);
			
		}else{
			echo "You don't have the authority to view the permissions for this page. Please Login Again!!"; die();
		}
        $data['employee_list'] = $this->Admin_Model->getAllEmployeeForOrder();
		$this->load->view('admin/order/order-list',$data);
	}

	public function suborderlist()
	{
	    $this->checkSession();
		$data['adminData'] =getAdminDetails();
		$session_data=$this->session->userdata('login-in');
		if ($session_data['user_type'] ==1 || $session_data['user_type'] ==2 || $session_data['user_type'] ==3) {
			@$fromdate=$this->input->get('fromdate');
			@$todate=$this->input->get('todate');
			@$paid_unpaid=$this->input->get('paid_unpaid');
			@$sales=$this->input->get('sales');
			
			    $config = array();
                $config["base_url"] = base_url()."Admin/orderlist";
                $config["total_rows"] = $this->Admin_Model->subcountorderDatas($fromdate,$todate,$paid_unpaid,$sales);
                $config["per_page"] = 25;
                $config["uri_segment"] = 3;
                $config['enable_query_strings'] = TRUE;
                $config['reuse_query_string'] = TRUE;
                
                $config['full_tag_open'] = '<ul class="pagination">';
                $config['full_tag_close'] = '</ul>';
                $config['first_link'] = 'First';
                $config['last_link'] = 'Last';
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['prev_link'] = 'Prev';
                $config['prev_tag_open'] = '<li class="prev">';
                $config['prev_tag_close'] = '</li>';
                $config['next_link'] = 'Next';
                $config['next_tag_open'] = '<li>';
                $config['next_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $config['cur_tag_open'] = '<li class="active"><a href="#">';
                $config['cur_tag_close'] = '</a></li>';
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data["links"] = $this->pagination->create_links();
                $data['orderData'] = $this->Admin_Model->suborderDatas($config["per_page"],$page,$fromdate,$todate,$paid_unpaid,$sales);
			
		}elseif ($session_data['user_type'] ==5) {
		    @$admin_id=$session_data['id'];
			@$fromdate=$this->input->get('fromdate');
			@$todate=$this->input->get('todate');
			@$paid_unpaid=$this->input->get('paid_unpaid');


			$config = array();
                $config["base_url"] = base_url()."Admin/orderlist";
                $config["total_rows"] = $this->Admin_Model->subcountorderDatasEmployee($admin_id,$fromdate,$todate,$paid_unpaid);
                $config["per_page"] = 25;
                $config["uri_segment"] = 3;
                $config['enable_query_strings'] = TRUE;
                $config['reuse_query_string'] = TRUE;
                
                $config['full_tag_open'] = '<ul class="pagination">';
                $config['full_tag_close'] = '</ul>';
                $config['first_link'] = 'First';
                $config['last_link'] = 'Last';
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['prev_link'] = 'Prev';
                $config['prev_tag_open'] = '<li class="prev">';
                $config['prev_tag_close'] = '</li>';
                $config['next_link'] = 'Next';
                $config['next_tag_open'] = '<li>';
                $config['next_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $config['cur_tag_open'] = '<li class="active"><a href="#">';
                $config['cur_tag_close'] = '</a></li>';
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data["links"] = $this->pagination->create_links();
                $data['orderData'] = $this->Admin_Model->suborderDatasEmployee($config["per_page"],$page,$admin_id,$fromdate,$todate,$paid_unpaid);

                //print_r($data['orderData']); die();
		}else{
			echo "You don't have the authority to view the permissions for this page. Please Login Again!!"; die();
		}
        $data['employee_list'] = $this->Admin_Model->getAllEmployeeForOrder();
		$this->load->view('admin/subscription_order/order-list',$data);
	}
	public function subviewOrderItem()
	{
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/subscription_order/view_order_item',$data);
	}
	public function assigncollectionUser()
	{
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/order/assign_collection_user',$data);
	}
	public function assigncollectyion()
	{
	    $this->checkSession();
		$user_id=$this->input->post('user_id');
		$orderId=$this->input->post('orderid');
		$this->db->set("collection_user",$user_id);
		$this->db->set("order_status",2);
		$this->db->where("order_id",$orderId);
		$this->db->update("kh_order_tb");


		//////////////////SMS///////////////////

		$data['getOrderData']=$this->Admin_Model->getOrderData($orderId);
		$PatientName=$data['getOrderData']->order_firstname;
		$testDate=$data['getOrderData']->test_date;
		$slotTime=$data['getOrderData']->time_slot;
		$getTimeSlot= $this->Admin_Model->getTimeSlot($slotTime);
		$timeslotTitle=$getTimeSlot->time_slot;
		$mobileNum=$data['getOrderData']->order_phone;
		$getAssignUser=$this->Admin_Model->getCollectionUserData($user_id);
		$testCollectionUserName=$getAssignUser->user_name;
		$testCollectionUserPhone=$getAssignUser->user_mobile;

		$NameAndPhone=$testCollectionUserName." (".$testCollectionUserPhone.")";

		//$sms="Dear $PatientName, Home collection appointment has been confirmed for $testDate between $timeslotTitle and assigned to $NameAndPhone.";
		$sms="Dear $PatientName, Home Collection assigned to $NameAndPhone, He Will Come To Your Place On $testDate between $timeslotTitle. T&C Apply";
			
		$assignSMS=urlencode($sms);
		
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=STARIM&Message=".$assignSMS."&ServiceName=TEMPLATE_BASED",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		));

		$response = curl_exec($curl);
		curl_close($curl);


		/////////////////End SMS////////////////
		
		$order_address=$data['getOrderData']->order_address;
		$order_amount_with_tax=$data['getOrderData']->order_amount_with_tax;
		$data['itemList']=$this->Admin_Model->getOrderItem($orderId);
		$itemLists=$data['itemList'];
			$testName="";
			foreach ($itemLists as $key => $value) {
				$testName .=$value->name; echo ",";
			}
		
		$smss="Home Collection, Patient Name - $PatientName Address - $order_address Total Amount - $order_amount_with_tax Test - $testName Date - $testDate Time - $timeslotTitle";
			
		$testCollectionSMS=urlencode($smss);
		
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$testCollectionUserPhone."&SenderID=STARIM&Message=".$testCollectionSMS."&ServiceName=TEMPLATE_BASED",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		));

		$response = curl_exec($curl);
		curl_close($curl);


		/////////////////End SMS////////////////
		
		/////////////////////////////////////////
	
		
		$sessionData = array('message'  => '<span class="text-success">User Assigned Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function viewOrderItem()
	{
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/order/view_order_item',$data);
	}
	public function viewReturnItem()
	{
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/order/view_returnitem',$data);
	}
	public function orderinfo($orderInfo)
	{
	    $this->checkSession();
		$orderid = base64_decode($orderInfo);
		$data['order_id'] = $orderid;
		$data['getOrderData']=$this->Admin_Model->getOrderData($orderid);
		$data['itemList']=$this->Admin_Model->getOrderItem($orderid);
	    $this->load->view('template/invoice',$data);
	}
	
	public function suborderinfo($orderInfo)
	{
	    $this->checkSession();
		$orderid = base64_decode($orderInfo);
		$data['order_id'] = $orderid;
		$data['getOrderData']=$this->Admin_Model->getOrderDatasub($orderid);
		//print_r($data['getOrderData']); die();
		$data['itemList']=$this->Admin_Model->subgetOrderServces($orderid);
	    $this->load->view('template/sub-invoice',$data);
	}
	public function checkorderinfo($checkoutid)
	{
	    $this->checkSession();
		$checkout_id = base64_decode($checkoutid);

		$data['check_out_data']=$this->Admin_Model->getCheckoutdata($checkout_id);
		//print_r($data['check_out_data']); die();
		$data['order_id'] = $data['check_out_data']->order_unique_code;
		$data['getOrderData']=$data['check_out_data'];

		$data['itemList']=$this->Admin_Model->getOrderItemFromCheckout($checkout_id);
	    $this->load->view('template/checkoutinvoice',$data);
	}
	public  function cancleOrder($orderId,$status)
	{ 
	    $this->checkSession();
	    
	     $getOrderData=$this->Admin_Model->getOrderData($orderId);
	     $orderuniquecode=$getOrderData->order_unique_code;
	      $mobileNum=$getOrderData->order_phone;
	    if($status == 2){
	       $sms="Packed: Your order with order ID $orderuniquecode has been packed by the seller and will be shipped soon. We will share the tracking details once the item is on its way to you. For more details visit www.thekiranewala.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			
			 $this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
	        
	        
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }elseif($status == 3){
	        
	        $day=date("l");
	        $datetoday=date("M d, Y");
	        $dates=$day.','.$datetoday;
	        $sms="Shipped: your order with order ID $orderuniquecode has been shipped and will be delivered by $dates  You will receive another SMS when the delivery person is out to deliver it. Track your shipment here www.thekiranewala.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
	        
	        $this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
	        
	        
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }elseif($status == 4){
	        $sms="Delivered: Your order with order ID $orderuniquecode is delivered on time. For more details visit www.thekiranewala.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			
			$this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
	        
	       
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }elseif($status == 6){
	   
$sms="Cancelled: Your order with order ID $orderuniquecode has been cancelled successfully.For more details visit www.thekiranewala.com/order-history.html";

			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			
			$this->db->set('user_id',$getOrderData->order_userid);
		    $this->db->set('notification',$sms);
		    $this->db->set('status',1);
		    $this->db->insert('kh_notification');
		    
		        $walletMAmount=$getOrderData->order_discount_amount;
		        $userid=$getOrderData->order_userid;
		    
		    if($walletMAmount > 0){
		        
		    
                $this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`- ".$walletMAmount." WHERE `user_id`= '".$userid."'");
    
				$this->db->select('*');
				$this->db->where('user_id',$userid);
				$this->db->order_by('transaction_id','desc');
				$this->db->limit(1);
				$lastEntery=$this->db->get('kh_wallet_transaction')->row();

				$debit_amount=$walletMAmount;
				$available_amount=$lastEntery->transaction_available_amount - $walletMAmount;

				$this->db->set('user_id',$userid);			
				$this->db->set('transaction_from','Cashback Deduction');
				$this->db->set('transaction_debit_amount',$debit_amount);
				$this->db->set('transaction_available_amount',$available_amount);
				$this->db->set('transaction_status',1);
				$this->db->insert('kh_wallet_transaction');

				$insertid=$this->db->insert_id();
				$transaction_number="KHAQWERTYUIO00".$insertid;
				$this->db->set('transaction_number',$transaction_number);
				$this->db->where('transaction_id',$insertid);
				$this->db->update('kh_wallet_transaction');
		    }
	        
	       
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }else{
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }
	 }
	public function PaidOrder($orderId,$status)
	{
	    $this->checkSession();
		$this->db->set("order_payment_status",$status);
		$this->db->where("order_id",$orderId);
		$this->db->update("kh_order_tb");
		
		$sessionData = array('message'  => '<span class="text-success">Order Status Paid Successfully !!</span>');
		$this->session->set_userdata($sessionData);

		redirect($_SERVER['HTTP_REFERER']);
		
	}
	
	//////////////////////////////////////////////End Order///////////////////////////////////


	



	 ////////////////////////////////CSV Export/////////////////////////////////
	 public function orderExport()
	 {
	 	 $myData = $this->Admin_Model->orderExportInCSV();
 
 // print_r($myData); die();
        // file name
        $filename = 'kiranewala'.date('Y-m-d').'.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");
 
        // file creation
        $file = fopen('php://output', 'w');
 
        $header = array("ORDER ID","ORDER TEST","ORDER_UNIQUE_CODE","ORDER_PAYMENT_ID","ORDER_USERID","ORDER_APPLIED_COUPON","ORDER_DISCOUNT_AMOUNT","ORDER_DELIVERY","ORDER_AMOUNT","ORDER_AMOUNT_WITH_TAX","ORDER_FIRSTNAME","ORDER_EMAIL","ORDER_PHONE","ORDER_STATE","ORDER_CITY","ORDER_ADDRESS","ORDER_ZIPCODE","ORDER_AGE","ORDER_GENDER","TEST_DATE","TIME_SLOT","ORDER_PAYMENT_STATUS","ORDER_CREATED","PAYMENT_TYPE","ORDER_TYPE","ORDER CREATED BY","COLLECTION_USER","ORDER COLLECTION TYPE","ORDER STATUS");
        fputcsv($file, $header);
 	


 		// print_r($myData); die();
        foreach ($myData as $order){
        	$orderItemlist="";
        	$productList=$this->Admin_Model->getOrderItemForExport($order->order_id);
      		foreach ($productList as $key => $value) {
      			$orderItemlist .=$value->test_name.", ";
      		}
      		//$orderItemlist=0;

      		$slotTime=$this->Admin_Model->getTimeSlotForExport($order->time_slot);
      		if ($order->payment_type == 1) {
      			$payment_type="Center Payment";
      		}else{
      			$payment_type="Online Payment";
      		}

      		$orderCreated=$this->Admin_Model->getForOrderEmployeeDataExprt($order->order_created_by);
      		 if ($order->order_type == 1) {
               $order_created_by="Website";
             }else{
                 if (!empty($orderCreated->first_name)) {
                  $order_created_by=$orderCreated->first_name." ".$orderCreated->last_name;
                 }else{
                  $order_created_by="";
                 } 
             }

             if ($order->order_type == 1) {
               $order_type="Website";
             }else{
                $order_type="Admin / Agent";
             }
             
             if ($order->order_gender == 1) {
               $orderGender="Male";
             }else{
                $orderGender="Female";
             }
            
            if ($order->order_collection_type == 1) {
               $order_collection_type="CENTER COLLECTION";
             }else{
                $order_collection_type="HOME COLLECTION";
             }
             
              if ($order->order_payment_status == 1) {
               $orderpaid="Paid";
             }else{
                $orderpaid="Not Paid";
             }
             
             //	0= cancel By user | 1 = process | 2 = confirmed( User Assign) | 3 = User onway | 4= Test Collected | 5 = Order Done | 6= cancel By admin
              if ($order->order_status == 0) {
               $order_status="Cancel By User";
             }elseif($order->order_status == 1){
                 $order_status="process";
             }elseif($order->order_status == 2){
                 $order_status="confirmed( User Assign)";
             }elseif($order->order_status == 3){
                 $order_status="Cancel By User";
             }elseif($order->order_status == 4){
                 $order_status="User onway";
             }elseif($order->order_status == 5){
                 $order_status="Order Done";
             }else{
                 $order_status="Cancel By admin";
             }
            
            
            $userdata= $this->Admin_Model->getUserDataForExports($order->order_userid);
            $userEmailForExport=$userdata->user_email;

            $callectionUserdata= $this->Admin_Model->getCallectionUserData($order->collection_user);

            fputcsv($file,array($order->order_id,$orderItemlist,$order->order_unique_code,$order->order_payment_id,$userEmailForExport,$order->order_applied_coupon,$order->order_discount_amount,$order->order_delivery,$order->order_amount,$order->order_amount_with_tax,$order->order_firstname,$order->order_email,$order->order_phone,$order->order_state,$order->order_city,$order->order_address,$order->order_zipcode,$order->order_age,$orderGender,$order->test_date,$slotTime->time_slot,$orderpaid,$order->order_created,$payment_type,$order_type,$order_created_by,@$callectionUserdata->user_name,$order_collection_type,$order_status));
        }
        fclose($file);
        exit;
        redirect($_SERVER['HTTP_REFERER']);
	 }

	 ///////////////////////////////End CSV Export/////////////////////////////////
	
    
    //////////////////////////////////////////Product///////////////////////////////

	
////// PRODUCT //////////////////////////////////////////////////////////////////////////////////////////
	public function product()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();	
		
		
        $config = array();
        $config["base_url"] = base_url()."Admin/product";
        $config["total_rows"] = $this->Admin_Model->getproductcount();
        $config["per_page"] = 25;
        $config["uri_segment"] = 3;
        $config['enable_query_strings'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["links"] = $this->pagination->create_links();
        $data['product_list'] = $this->Admin_Model->getproduct($config["per_page"],$page);
		
		
	
		
		$this->load->view('admin/product/product_list',$data);
	}
	public function addproduct()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();	
		$this->load->view('admin/product/add_product',$data);
	}

	public function productsubmit()
	{
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('product_name', 'Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('brand_id', 'Brand Name', 'trim|required|xss_clean');
		// $this->form_validation->set_rules('product_code', 'Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('purchase_qty', 'Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_qty', 'Qty', 'trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('stock_status', 'Stock Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_status', 'Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('featured_status', 'Feature Stock', 'trim|required|xss_clean');

		//$this->form_validation->set_rules('kh_purchase_price', 'Purchase Price', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_mrp', 'Product MRP', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_price', 'Product Price', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_shipping_price', 'Shipping Price', 'trim|required|xss_clean');
		
		$this->form_validation->set_rules('product_description', 'Description', 'trim|required|xss_clean');
		$this->form_validation->set_rules('small_description','Small Description','trim|xss_clean');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_description', 'Meta Description', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_keyword', 'Meta Keyword', 'trim|xss_clean');
		$this->form_validation->set_rules('product_tag', 'Product Tags', 'trim|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData']=getAdminDetails();
			$this->load->view('admin/product/add_product',$data);
		}
		else
		{   
		 
    	   if($_FILES['product_image']['size']>0)
        	{
        	$coverData = $this->do_upload('product_image','product');
    	    $cover = $coverData['upload_data']['file_name'];
        	    
        	} else{
        	    $cover = null;
        	}   
		     

			$product_id = $this->Admin_Model->addProduct($cover);
			$this->Admin_Model->addProductCategory($product_id);
			$sessionData = array('message'  => '<span class="text-success">Product Added Successfully !!</span>');
			$this->session->set_userdata($sessionData);
		    redirect(base_url("Admin/product"));
		
		}
	}

	public function editproduct($pid)
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$id = base64_decode($pid);
		$data['product_info'] = $this->Admin_Model->getSingleProduct($id);
		$this->load->view('admin/product/edit_product',$data);
	}

	public function updateproduct()
	{
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('product_id', 'Product ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('brand_id', 'Brand Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_name', 'Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_code', 'Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('purchase_qty', 'Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_qty', 'Qty', 'trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('stock_status', 'Stock Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_status', 'Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('featured_status', 'Feature Stock', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_mrp', 'Product MRP', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_price', 'Price', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_shipping_price', 'Shipping Price', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('kh_purchase_price', 'Purchase Price', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_description', 'Description', 'trim|required|xss_clean');
		$this->form_validation->set_rules('small_description','Small Description','trim|xss_clean');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_description', 'Meta Description', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_keyword', 'Meta Keyword', 'trim|xss_clean');
		$this->form_validation->set_rules('product_tag', 'Product Tags', 'trim|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData']=getAdminDetails();
			$data['product_info'] = $this->Admin_Model->getSingleProduct($this->input->post('product_id'));
			$this->load->view('admin/product/edit_product',$data);
		}
		else
		{    
			if($_FILES['product_image']['size']>0)
			{
			$coverData = $this->do_upload('product_image','product');
			$cover = $coverData['upload_data']['file_name'];
			}
			else{
				$cover = NULL;
			}
			
			$this->Admin_Model->updateProduct($cover);
			$this->Admin_Model->updateProductCategory();
			

			$sessionData = array('message'  => '<span class="text-success">Product Updated Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/product"));
		
		}
	}



	public function updateproduct_qty()
	{
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('product_id', 'Product ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_name', 'Name', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_code', 'Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('purchase_qty', 'Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_qty', 'Qty', 'trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('stock_status', 'Stock Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_status', 'Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('featured_status', 'Feature Stock', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_mrp', 'Product MRP', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_price', 'Price', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('product_shipping_price', 'Shipping Price', 'trim|required|xss_clean');
		//$this->form_validation->set_rules('kh_purchase_price', 'Purchase Price', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_description', 'Description', 'trim|required|xss_clean');
		$this->form_validation->set_rules('small_description','Small Description','trim|xss_clean');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_description', 'Meta Description', 'trim|xss_clean');
		$this->form_validation->set_rules('meta_keyword', 'Meta Keyword', 'trim|xss_clean');
		$this->form_validation->set_rules('product_tag', 'Product Tags', 'trim|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData']=getAdminDetails();
			$data['product_info'] = $this->Admin_Model->getSingleProduct($this->input->post('product_id'));
			$this->load->view('admin/product/edit_product',$data);
		}
		else
		{    
			if($_FILES['product_image']['size']>0)
			{
			$coverData = $this->do_upload('product_image','product');
			$cover = $coverData['upload_data']['file_name'];
			}
			else{
				$cover = NULL;
			}
			
			$this->Admin_Model->updateProduct($cover);
			$this->Admin_Model->updateProductCategory();

			$sessionData = array('message'  => '<span class="text-success">Product Updated Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect(base_url("Admin/product"));
		
		}
	}







	public function child_product_list()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$id = base64_decode($this->uri->segment(3));
		$data['child_product_list'] = $this->Admin_Model->getChildProduct($id);
		$this->load->view('admin/product/child_product_list',$data);
	}

	public function childProductsubmit()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('product_id', 'Product ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_code', 'Product Code', 'trim|required|xss_clean');
		$this->form_validation->set_rules('purchase_qty', 'Product Qty', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_qty', 'Qty', 'trim|required|numeric|xss_clean');
		$this->form_validation->set_rules('stock_status', 'Stock Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_status', 'Status', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_mrp', 'Product MRP', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_price', 'Product Price', 'trim|required|xss_clean');
		$this->form_validation->set_rules('product_shipping_price', 'Shipping Price', 'trim|required|xss_clean');
		$this->form_validation->set_rules('kh_purchase_price', 'Purchase Price', 'trim|required|xss_clean');

		if ($this->form_validation->run() == FALSE)
		{
			$data['adminData']=getAdminDetails();
			$this->load->view('admin/product/child_product_list',$data);
		}
		else
		{      
			$product_id = $this->Admin_Model->addChildProduct();
			$sessionData = array('message'  => '<span class="text-success">Child Product Added Successfully !!</span>');
			$this->session->set_userdata($sessionData);
			redirect($_SERVER['HTTP_REFERER']);
		}
	}

	public function updateuproductstatus($id,$status)
	{
		$id = base64_decode($id);
		
		$this->db->set("product_status",$status);
		$this->db->where("product_id",$id);
		$this->db->update("kh_product");
		redirect($_SERVER['HTTP_REFERER']);
	}

	public function updateuproductfeature($id,$status)
	{
		$id = base64_decode($id);
		
		$this->db->set("featured_status",$status);
		$this->db->where("product_id",$id);
		$this->db->update("kh_product");
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function updateuproductdiscounted_products($id,$status)
	{
		$id = base64_decode($id);
		
		$this->db->set("discounted_products",$status);
		$this->db->where("product_id",$id);
		$this->db->update("kh_product");
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function updateuproductnew_products($id,$status)
	{
		$id = base64_decode($id);
		
		$this->db->set("new_products",$status);
		$this->db->where("product_id",$id);
		$this->db->update("kh_product");
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function updateuproductstock_status($id,$status)
	{
		$id = base64_decode($id);
		
		$this->db->set("stock_status",$status);
		$this->db->where("product_id",$id);
		$this->db->update("kh_product");
		redirect($_SERVER['HTTP_REFERER']);
	}

	
	
	public function add_image($product_id)
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['product_id'] = $product_id;
		$this->load->view("admin/product/add_images",$data);
		
		
	}


	
 
 
	public function deleteproduct($product)
	{
		$pd = base64_decode($product);
		
		 
		$this->db->where("product_id",$pd);
		$this->db->delete("kh_product");
	
		$sessionData = array('message'  => '<span class="text-success">Product Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);
	redirect($_SERVER['HTTP_REFERER']);
	}
	public function deleteproductmain($product)
	{
		$pd = base64_decode($product);
		
		 
		$this->db->where("product_id",$pd);
		$this->db->delete("kh_product");
		
		$this->db->where("parent_product",$pd);
		$this->db->delete("kh_product");
		
		
		$sessionData = array('message'  => '<span class="text-success">Product Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);
		redirect($_SERVER['HTTP_REFERER']);
	}

	
	public function submit_image()
	{       
		$this->load->library('upload');

		$files = $_FILES;
		$cpt = count($_FILES['userfile']['name']);
		
		$set_product_id = $this->input->post("get_product_id");
 	
		for($i=0; $i<$cpt; $i++)
		{           
			$_FILES['userfile']['name']= $files['userfile']['name'][$i];
			$_FILES['userfile']['type']= $files['userfile']['type'][$i];
			$_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
			$_FILES['userfile']['error']= $files['userfile']['error'][$i];
			$_FILES['userfile']['size']= $files['userfile']['size'][$i];    

			// $this->upload->initialize($this->set_upload_options());
 
			$config = array();
			$config['upload_path'] = 'uploads/product/';
			// $config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG';
			$config['allowed_types'] = '*';
			$config['max_size']      = '0';
			$config['overwrite']     = FALSE;
			$path = $_FILES['userfile']['name'][$i];
			$config['file_name'] = "kiranewala_".time().$_FILES['userfile']['name'];
			$this->upload->initialize($config);
		
			if ( ! $this->upload->do_upload()) {

				// return the error message and kill the script
				echo $this->upload->display_errors(); die();
 
		 
			}
			else
			{
			 
				$return_data = $this->upload->data();
			    $this->Admin_Model->insertProductImage($set_product_id,$return_data['file_name']);
			}
			 

		 	
		}
		
		redirect("admin/add_image/".$set_product_id."/");
		
	}

	function delete_photo($photoId)
	{
		$this->db->where("image_id",$photoId);
		$this->db->delete("kh_product_images");
		
		$sessionData = array('message'  => '<span class="text-success">Image Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);

		redirect($_SERVER['HTTP_REFERER']);
		
	}

    ///////////////////////////////////////End Product//////////////////////////////


    //////////////////////User Login By Admin//////////////////////////////////////

	function userloginbyadmin()
	{
		$id=base64_decode($this->uri->segment(3));
		$currentUserDetail = $this->Admin_Model->getSiteLoginAdmin($id);
			if($currentUserDetail)
				{
				 	$getDbPaas = $currentUserDetail->user_password;
					//$getUserPaas = md5($this->input->post('user_password'));
	    //             $getbduser = $currentUserDetail->user_email;	
					// $getUsername = $this->input->post('user_email');
					if($getDbPaas == $getDbPaas)
					{
						$newdata = array(
							'activeUserMail' => $currentUserDetail->user_email,
							'activeUserId'  => $currentUserDetail->user_id,
							'isUserLogged_in' => 1);
						$this->session->set_userdata($newdata);
						
						if($this->session->userdata("redirect"))
						{
							$redirectTo = $this->session->userdata("redirect");
							$removeData = array('redirect'  => "");
							$this->session->unset_userdata($removeData);
							redirect($redirectTo);
						}
						else
						{
							$this->session->set_flashdata('message','<span class="text-success">User Login Successfully</span>');
							redirect(base_url());
						}
					}
					else
					{
						$this->session->set_flashdata('message','<span class="text-danger">Your Password is incorrect</span>');
						redirect($_SERVER['HTTP_REFERER']);
					}
				}	
				else
				{
				    $this->session->set_flashdata('message','<span class="text-danger">We cannot find an account with that email address</span>');
					redirect($_SERVER['HTTP_REFERER']);
				}
			
		
	}

    /////////////////////End user Login By Admin/////////////////////////////////
    
    
    /***********************************add_price_by_pin_code.php**************************/
    public function add_price_by_pin_code($pid)
    {
    	$this->checkSession();
		$data['adminData']=getAdminDetails();
		$id = base64_decode($pid);
		$data['get_pincode'] = $this->Admin_Model->getPinCodeByProductForPrice($id);
		//print_r($data['get_pincode']); die();
		$this->load->view('admin/product/add_price_by_pin_code',$data);
    }

    /*public function addpricebypincode()
    {
    	// echo "<pre>";
    	// print_r($_POST); die();
    	$product_id = $this->input->post("product_id");
    	$productprice = $this->input->post("product_price");
		$branch_id = $this->input->post("branch_id");
		if(count($branch_id)){
				$this->db->where('product_id',$product_id);
				$this->db->delete('kh_product_price_by_pincode');
			foreach($branch_id as  $key => $brandid){
				$price=$productprice[$key];
				$this->db->set('product_price',$price);
				$this->db->set('branch_id',$brandid);
				$this->db->set('product_id',$product_id);
				$this->db->set('status',1);
				$this->db->insert('kh_product_price_by_pincode');
			}
		} 
		redirect($_SERVER['HTTP_REFERER']);

		
    }*/
    
    public function addpricebypincode()
    {
    	 // echo "<pre>";
    	 // print_r($_POST); die();
    	$product_id = $this->input->post("product_id");
    	$productprice = $this->input->post("product_price");
    	$productqty = $this->input->post("offerQty");
		$branch_id = $this->input->post("branch_id");
		if(count($branch_id)){
				$this->db->where('product_id',$product_id);
				$this->db->delete('kh_product_price_by_pincode');
			foreach($branch_id as  $key => $brandid){
				$price=$productprice[$key];
				$qty=$productqty[$key];
				
				$this->db->set('product_price',$price);
				$this->db->set('branch_id',$brandid);
				$this->db->set('product_id',$product_id);
				$this->db->set('offerQty',$qty);
				$this->db->set('status',1);
				$this->db->insert('kh_product_price_by_pincode');
			}
		} 
		redirect($_SERVER['HTTP_REFERER']);
    }
    /**********************************Eng add_price_by_pin_code.php**********************/
    
   /**************************** Order Item Search***************************************/
   public function object_to_array($data)
	{
		if (is_array($data) || is_object($data))
		{
			$result = array();
			foreach ($data as $key => $value)
			{
				$result[$key] = $this->object_to_array($value);
			}
			return $result;
		}
		return $data;
	}
	public function export($data)
	{
	     $file_name = 'kiranewala_'.rand(999,99999).date('Ymd').'.csv'; 
		 header("Content-Description: File Transfer"); 
		 header("Content-Disposition: attachment; filename=$file_name"); 
		 header("Content-Type: application/csv;");
	    
		 $data = $this->object_to_array($data);
		 // file creation 
		 $file = fopen('php://output', 'w');
	 
		 $header = array_keys($data[0]); //array("Student Name","Student Phone"); 
		  
		 
		 fputcsv($file, $header);
		 foreach ($data as $key => $value)
		 { 
		   fputcsv($file, $value); 
		 }
		 fclose($file); 
		 exit; 
	}
    public function searchOrderItemBydate()
    {
    	$this->checkSession();
    	if ($this->input->get('submit') == "Export") {
    		$orSersvice=$this->Admin_Model->getOrderItemByDateSearch();
    		//print_r($orSersvice); die();
		
				foreach ($orSersvice as $pro){
		            $data['Product Name']=$pro->name;
		            $data['Product Code']=$pro->code;
		            $data['Product Price']=$pro->one_price;
		            $qtyprint=$this->Admin_Model->getOrderQtysearch($_GET['search-date-from'],$_GET['search-date-to'],$pro->product_id);
		            $totalqty=0;
                    foreach ($qtyprint as $key => $qty) {
                     $totalqty+=$qty->qty;
                    }
                    
		            $data['Qty']=$totalqty;

		            $totalprice=0;
                    foreach ($qtyprint as $key => $prices) {
                     $totalprice+=$prices->price;
                    }
		            $data['Qty Price']="Rs.".$totalprice."/-";
		            $productpurchaseprice=$qtyprint[0]->product_purchase_price;
		            $data['Purchase Price']=$productpurchaseprice;
		            $data['Purchase Price By Qty']=$finalPurchase=$productpurchaseprice * $totalqty;
		            $data['Profit']=$totalprice - $finalPurchase;
		            $exportData[]=$data;
		   		}
    		$this->export($exportData);
    	}
    	
		$data['adminData']=getAdminDetails();
		$data['orderSersvice']=$this->Admin_Model->getOrderItemByDateSearch(); 
		$this->load->view('admin/order/order_item_search',$data);
    }
    public function orderedproduct()
    {
    	$this->checkSession();
		$data['adminData']=getAdminDetails();
		$data['orderSersvice']=$this->Admin_Model->getordereditembyproductidanddate(); 
		$this->load->view('admin/order/ordered_product',$data);
    }
    /****************************End Order Item Search***************************************/
    
    
     
    
    //////////////////////////////////////////App Slider/////////////////////////////////////
    public function apphome()
	{
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->load->view("admin/apphome/apphome",$data);
	}
	public function homesubmit_image()
	{       
		$this->load->library('upload');

		$files = $_FILES;
		$cpt = count($_FILES['userfile']['name']);
		
		$image_section_type = $this->input->post("image_section_type");
 	
		for($i=0; $i<$cpt; $i++)
		{           
			$_FILES['userfile']['name']= $files['userfile']['name'][$i];
			$_FILES['userfile']['type']= $files['userfile']['type'][$i];
			$_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
			$_FILES['userfile']['error']= $files['userfile']['error'][$i];
			$_FILES['userfile']['size']= $files['userfile']['size'][$i];    

			// $this->upload->initialize($this->set_upload_options());
 
			$config = array();
			$config['upload_path'] = 'uploads/app_home/';
			// $config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG';
			$config['allowed_types'] = '*';
			$config['max_size']      = '0';
			$config['overwrite']     = FALSE;
			$path = $_FILES['userfile']['name'][$i];
			$config['file_name'] = "kiranewala_".time().$_FILES['userfile']['name'];
			$this->upload->initialize($config);
		
			if ( ! $this->upload->do_upload()) {

				// return the error message and kill the script
				echo $this->upload->display_errors(); die();
			}
			else
			{
				$return_data = $this->upload->data();
			    $this->Admin_Model->insertAppHomeImage($image_section_type,$return_data['file_name']);
			} 	
		}
		$this->session->set_flashdata('message','<span class="text-danger">Data Update Successfully !!</span>');
		redirect("admin/apphome");	
	}
	public function updatedata($data_id,$link)
	{
		$this->db->set('image_link',$link);
		$this->db->where('image_id',$data_id);
		$this->db->update('kh_app_home_images');
		$this->session->set_flashdata('message','<span class="text-danger">Data Update Successfully !!</span>');
		redirect("admin/apphome");
	}
	public function submitCategoryForApp()
	{
		$image_section_type=$this->input->post('image_section_type');
		$cat_list = $this->input->post("app_cat");
		if(count($cat_list)){
				$this->db->where('image_section_type',$image_section_type);
				$this->db->delete('kh_app_home_images');
			foreach($cat_list as $cat_id){
				$this->db->set('image_name',$cat_id);
				$this->db->set('image_section_type',$image_section_type);
				$this->db->insert('kh_app_home_images');
			}
		} 
		$this->session->set_flashdata('message','<span class="text-danger">Data Update Successfully !!</span>');
		redirect("admin/apphome");
	}
	function appdelete_photo($photoId)
	{
		$this->db->where("image_id",$photoId);
		$this->db->delete("kh_app_home_images");
		
		$sessionData = array('message'  => '<span class="text-success">Image Deleted Successfully !!</span>');
		$this->session->set_userdata($sessionData);

		redirect($_SERVER['HTTP_REFERER']);
		
	}


    /////////////////////////////////////////End App Slider//////////////////////////////////
    

    public  function subcancleOrder($orderId,$status)
	{ 
	    $this->checkSession();
	    
	     $getOrderData=$this->Admin_Model->getOrderDatasub($orderId);
	     $orderuniquecode=$getOrderData->order_unique_code;
	      $mobileNum=$getOrderData->order_phone;
	    if($status == 2){
	       $sms="Packed: Your order with order ID $orderuniquecode has been packed by the seller and will be shipped soon. We will share the tracking details once the item is on its way to you.
For more details visit www.kiranewala.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			
			 $this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
	        
	        
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_subscribe_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }elseif($status == 3){
	        
	        $day=date("l");
	        $datetoday=date("M d, Y");
	        $dates=$day.','.$datetoday;
	        $sms="Shipped: your order with order ID $orderuniquecode has been shipped and will be delivered by $dates You will receive another SMS when the delivery person is out to deliver it. Track your shipment here www.kiranewala.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
	        
	        $this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
	        
	        
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_subscribe_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }elseif($status == 4){
	        $sms="Delivered: Your order with order ID $orderuniquecode is delivered on time.
For more details visit www.kiranewala.com/order-history.html";
			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			
			$this->db->set('user_id',$getOrderData->order_userid);
		   $this->db->set('notification',$sms);
		   $this->db->set('status',1);
		   $this->db->insert('kh_notification');
	        
	       
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_subscribe_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }elseif($status == 6){
	   
$sms="Cancelled: Your order with order ID $orderuniquecode has been cancelled successfully.
For more details visit www.kiranewala.com/order-history.html";

			
			$orderSMS=urlencode($sms);

			$curl = curl_init();

			curl_setopt_array($curl, array(
			  CURLOPT_URL => "https://smsapi.24x7sms.com/api_2.0/SendSMS.aspx?APIKEY=ijh7SudgdpO&MobileNo=".$mobileNum."&SenderID=KIRAWA&Message=".$orderSMS."&ServiceName=TEMPLATE_BASED",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "GET",
			));

			$response = curl_exec($curl);
			curl_close($curl);
			
			$this->db->set('user_id',$getOrderData->order_userid);
		    $this->db->set('notification',$sms);
		    $this->db->set('status',1);
		    $this->db->insert('kh_notification');
		    
		        $walletMAmount=$getOrderData->order_discount_amount;
		        $userid=$getOrderData->order_userid;
		    
		    if($walletMAmount > 0){
		        
		    
                $this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`- ".$walletMAmount." WHERE `user_id`= '".$userid."'");
    
				$this->db->select('*');
				$this->db->where('user_id',$userid);
				$this->db->order_by('transaction_id','desc');
				$this->db->limit(1);
				$lastEntery=$this->db->get('kh_wallet_transaction')->row();

				$debit_amount=$walletMAmount;
				$available_amount=$lastEntery->transaction_available_amount - $walletMAmount;

				$this->db->set('user_id',$userid);			
				$this->db->set('transaction_from','Cashback Deduction');
				$this->db->set('transaction_debit_amount',$debit_amount);
				$this->db->set('transaction_available_amount',$available_amount);
				$this->db->set('transaction_status',1);
				$this->db->insert('kh_wallet_transaction');

				$insertid=$this->db->insert_id();
				$transaction_number="KHAQWERTYUIO00".$insertid;
				$this->db->set('transaction_number',$transaction_number);
				$this->db->where('transaction_id',$insertid);
				$this->db->update('kh_wallet_transaction');
		    }
	        
	       
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_subscribe_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }else{
	        $this->db->set("order_status",$status);
    		$this->db->where("order_id",$orderId);
    		$this->db->update("kh_subscribe_order_tb");
    		$sessionData = array('message'  => '<span class="text-success">Order Status Update Successfully !!</span>');
    		$this->session->set_userdata($sessionData);
    		redirect($_SERVER['HTTP_REFERER']);
	    }
	 }
	public function subPaidOrder($orderId,$status)
	{
	    $this->checkSession();
		$this->db->set("order_payment_status",$status);
		$this->db->where("order_id",$orderId);
		$this->db->update("kh_subscribe_order_tb");
		
		$sessionData = array('message'  => '<span class="text-success">Order Status Paid Successfully !!</span>');
		$this->session->set_userdata($sessionData);

		redirect($_SERVER['HTTP_REFERER']);
		
	}

/************************Do Not Remove This code ************************/
  /* public function updateurl()
	{
		$this->db->select('*');
		$dataurl=$this->db->get('kh_product')->result();
		foreach ($dataurl as $value) {
			$url=$value->product_name.''.$value->purchase_qty;
			$this->db->set('product_url',$this->urlMaker($url));
			$this->db->where('product_id',$value->product_id);
			$this->db->update('kh_product');
		}
		echo "Done";
	}
	public function urlMaker($string)
	{
	    $string = utf8_encode($string);
		//$string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);   
		$string = preg_replace('/[^a-z0-9- ]/i', '', $string);
		$string = str_replace(' ', '-', $string);
		$string = trim($string, '-');
		$string = strtolower($string);
		if (empty($string)) {
		return 'n-a';
		}
		return $string.".html";
	} */
	/************************Do Not Remove This code ************************/


	public function Update_auto_qty(){

		$this->db->select('*');
		$this->db->where('auto_update_qty !=',0);
		$getAllQty = $this->db->get('kh_product')->result();
		
		foreach($getAllQty as $getAllQtyy){
			$totle = $getAllQtyy->product_qty + $getAllQtyy->auto_update_qty;
			$this->db->set('product_qty',$totle);
			$this->db->where('auto_update_qty',$getAllQtyy->auto_update_qty);
			$this->db->update('kh_product');
			echo "Done";
		}
		
	}
	
	public function Single_product_qty_Update(){
		//print_r($_POST);die;
		$this->db->select('*');
		$this->db->set('product_qty',$this->input->post('product_qty'));
		$this->db->where('product_id',$this->input->post('product_id'));
		$this->db->update('kh_product');

		$response = "Qty Updated Successfully";
		echo json_encode($response);

	}
	
	
	
	///////////////brand list/////////////////
	public function Brand_list(){
		$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->load->view("admin/brand/brandlist",$data);
	}
	public function add_brand(){
	    
    if($_FILES['bimg']['size']>0)
	{
	 $covers = $this->do_upload('bimg','brand');
     $cover = $covers["upload_data"]["file_name"];
	    
	} else{
	    $cover = null;
	}   
 

	$this->Admin_Model->add_brand_list($cover);
	$response = array('message' => '<span class="text-success">Brand Add Successfully !!</span>');
	$this->session->set_userdata($response);
	redirect($_SERVER['HTTP_REFERER']);
	//print_r($_POST);
	}
	public function brandstatus($catid,$status){
		$this->checkSession();
		$this->db->set('status',$status);
		$this->db->where('id',$catid);
		$this->db->update('kh_brand');
		$response = array('message' => '<span class="text-success">Status Update Successfully !!</span>');
	  $this->session->set_userdata($response);
	  redirect($_SERVER['HTTP_REFERER']);
	}

	/*public function Edit_brand(){

		if(!empty($this->input->post('Brand_id'))){
			  $covers = $this->do_upload('bimgu','brand');
			  $cover = $covers["upload_data"]["file_name"];
			   

			  $created_at=date("Y-m-d h:i:sa");
				//$img = $this->input->post('img');
				$this->db->select('*');
				$this->db->set('b_name',$this->input->post('bname'));
				$this->db->set('b_img',$cover);
				$this->db->set('created_date',$created_at);	
				$this->db->where('id',$this->input->post('Brand_id'));
				 $this->db->update('kh_brand');
				$response = array('message' => '<span class="text-success">Brand update Successfully !!</span>');
				$this->session->set_userdata($response);
				redirect($_SERVER['HTTP_REFERER']);
		}else{


					$covers = $this->do_upload('bimgu','brand');
			    $cover = $covers["upload_data"]["file_name"];
					$this->db->select('*');
					$this->db->set('b_img',$cover!=NULL);
					$this->db->where('id',$this->input->post('Brand_id'));
					$this->db->update('kh_brand');
					 
					header("Location:".base_url('Admin/Brand_list'));
					}

  }*/

  public function Edit_brand(){
       if($_FILES['bimgu']['size']>0)
    	{
    		$logoData = $this->do_upload('bimgu','brand');
    		$cover = $logoData["upload_data"]["file_name"];
    	}else{
    		$cover = NULL;
    	}	
    	$this->Admin_Model->updatebrandlist($cover);
    
    	
    	header("Location:".base_url('Admin/Brand_list'));
  }

  public function delete_brand($id){
  	$this->db->select('*');
  	$this->db->where('id',$id);
  	$this->db->delete('kh_brand');
  	$response = array('message' => '<span class="text-success">Record Delete Successfully !!</span>');
	  $this->session->set_userdata($response);
	  redirect($_SERVER['HTTP_REFERER']);
  }


  ////////////////end brand list///////////////////
  public function view_all_address(){
  	$this->checkSession();
		$data['adminData']=getAdminDetails();
		$this->load->view("admin/view_all_address",$data);
  }
  public function update_address_status($id,$status){

  	//echo 'hello';die;
  	$this->db->select('*');
  	$this->db->set('status',$status);
  	$this->db->where('id',$id);
  	$this->db->update('kh_save_address');
  	$response = array('message' => '<span class="text-success">Address Update Successfully !!</span>');
	  $this->session->set_userdata($response);
	  redirect($_SERVER['HTTP_REFERER']);
  }

  public function return_order(){
  		 $this->checkSession();
		$data['adminData'] =getAdminDetails();
		$session_data=$this->session->userdata('login-in');
		if ($session_data['user_type'] ==1 || $session_data['user_type'] ==2 || $session_data['user_type'] ==3) {
       	
			@$fromdate=$this->input->get('fromdate');
			@$todate=$this->input->get('todate');
			@$paid_unpaid=$this->input->get('paid_unpaid');
			@$sales=$this->input->get('sales');
			
			    $config = array();
                $config["base_url"] = base_url()."Admin/orderlist";
                $config["total_rows"] = $this->Admin_Model->countorderDatas($fromdate,$todate,$paid_unpaid,$sales);
                $config["per_page"] = 25;
                $config["uri_segment"] = 3;
                $config['enable_query_strings'] = TRUE;
                $config['reuse_query_string'] = TRUE;
                
                $config['full_tag_open'] = '<ul class="pagination">';
                $config['full_tag_close'] = '</ul>';
                $config['first_link'] = 'First';
                $config['last_link'] = 'Last';
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['prev_link'] = 'Prev';
                $config['prev_tag_open'] = '<li class="prev">';
                $config['prev_tag_close'] = '</li>';
                $config['next_link'] = 'Next';
                $config['next_tag_open'] = '<li>';
                $config['next_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $config['cur_tag_open'] = '<li class="active"><a href="#">';
                $config['cur_tag_close'] = '</a></li>';
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data["links"] = $this->pagination->create_links();
                $data['orderData'] = $this->Admin_Model->orderDatas($config["per_page"],$page,$fromdate,$todate,$paid_unpaid,$sales);
			
		}elseif ($session_data['user_type'] ==5) {
		    @$admin_id=$session_data['id'];
			@$fromdate=$this->input->get('fromdate');
			@$todate=$this->input->get('todate');
			@$paid_unpaid=$this->input->get('paid_unpaid');


			$config = array();
                $config["base_url"] = base_url()."Admin/orderlist";
                $config["total_rows"] = $this->Admin_Model->countorderDatasEmployee($admin_id,$fromdate,$todate,$paid_unpaid);
                $config["per_page"] = 25;
                $config["uri_segment"] = 3;
                $config['enable_query_strings'] = TRUE;
                $config['reuse_query_string'] = TRUE;
                
                $config['full_tag_open'] = '<ul class="pagination">';
                $config['full_tag_close'] = '</ul>';
                $config['first_link'] = 'First';
                $config['last_link'] = 'Last';
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['prev_link'] = 'Prev';
                $config['prev_tag_open'] = '<li class="prev">';
                $config['prev_tag_close'] = '</li>';
                $config['next_link'] = 'Next';
                $config['next_tag_open'] = '<li>';
                $config['next_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $config['cur_tag_open'] = '<li class="active"><a href="#">';
                $config['cur_tag_close'] = '</a></li>';
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data["links"] = $this->pagination->create_links();
                $data['orderData'] = $this->Admin_Model->orderDatasEmployee($config["per_page"],$page,$admin_id,$fromdate,$todate,$paid_unpaid);

                //print_r($data['orderData']); die();
		}else{
			echo "You don't have the authority to view the permissions for this page. Please Login Again!!"; die();
		}
        $data['employee_list'] = $this->Admin_Model->getAllEmployeeForOrder();
	
			$this->load->view('admin/order/return-order-list',$data);
  }
 
  public function updatereturnstatus($id,$status)
  {
  	$this->db->select('*');
  	$this->db->where('item_id',$id);
  	$this->db->set('status',$status);
  	$this->db->update('kh_order_items');

  	$response = array('message' => '<span class="text-success">Return Request Accepted !!</span>');
	  $this->session->set_userdata($response);
	  redirect($_SERVER['HTTP_REFERER']);
  }
  
   public function genrate_form(){
  	    $this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/invoice/genrate',$data);
  }
  
   public function genrate_list(){
  	$this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/invoice/genratelist',$data);
  }

  
  public function genrate_inv_billamount()
  {
  	$bill_amont = $this->input->post('billamount');
		$totalamount = $this->input->post('order_amount');
		$persantage = ($bill_amont / $totalamount) * 100;
		 
  	//print_r($_POST);die;

    $this->db->set('inv_type',$this->input->post('inv_type'));
  	$this->db->set('userid',$this->input->post('order_userid'));
  	$this->db->set('username',$this->input->post('order_firstname'));
  	$this->db->set('useremail',$this->input->post('order_email'));
  	$this->db->set('userphone',$this->input->post('order_phone'));
  	$this->db->set('order_created',$this->input->post('order_created'));
  	$this->db->set('order_month_amount',$totalamount);
  	$this->db->set('bill_amont',$bill_amont);
  	$this->db->set('persantage',$persantage);
  	$this->db->set('status',1);
  	$this->db->insert('kh_genrate_inv');

  	$response = array('message' => '<span> Invoice Genarate Successfully !!</span>');
  	$this->session->set_userdata($response);
  	 redirect($_SERVER['HTTP_REFERER']);

  }

  public function Invoice_Genrate_status($id,$status)
 	{
 		$this->db->select('*');
 		$this->db->where('inv_id',$id);
 		$this->db->set('status',$status);
 		$this->db->update('kh_genrate_inv');
 		$response = array('message' => '<span> Status Updated Successfully !!</span>');
  	$this->session->set_userdata($response);
  	 redirect($_SERVER['HTTP_REFERER']);
 	}
 	
 	public function ViewALLADDRESS_LIST(){
 	   $this->checkSession();
		$data['adminData'] =getAdminDetails();
		$this->load->view('admin/address',$data);
 	}



    public function invinfo($inv_id)
	{
	    $this->checkSession();
		$inv_ids = base64_decode($inv_id);
		$data['invid'] = $inv_ids;
		$data['getOrderData']=$this->db->select('*')->where('inv_id',$inv_ids)->get('kh_genrate_inv')->row();
		$data['userdata']=$this->db->select('*')->where('user_id',$data['getOrderData']->userid)->get('kh_user_list')->row();
		$data['userAddressData']=$this->db->select('*')->where('user_id',$data['getOrderData']->userid)->get('kh_save_address')->row();
		//print_r($data['userdata']); die;
	    $this->load->view('template/inv_invoice',$data);
	}
  







}


