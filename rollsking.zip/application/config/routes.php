<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/

$route['default_controller'] = 'Website';
$route['404_override'] = 'Website/page404';
$route['translate_uri_dashes'] = FALSE;




//////////////////////////////////Admin URL/////////////////////////////
$route['Admin/login.html']='Admin/adminloginForm';
$route['Admin/dashboard.html']='Admin/dashboard';
$route['Admin/logout.html']='Admin/adminLogout';
/////////////////////////////////End Admin URL//////////////////////////

///////////////////////////////Website URL /////////////////////////////
$route['index']='Website/index';
$route['index/(:any)']='Website/index/$1';
$route['user-login.html']='Website/login';
$route['login-now.html']='Website/loginForm';
$route['logout.html']='Website/userLogout';
$route['contact-us.html']='Website/contactUs';
$route['product/(:any)'] = 'Website/packagedetail/$1';
$route['subscribe/(:any)'] = 'Website/subscribe/$1';
$route['category/(:any)'] = 'Website/productlist/$1';

$route['search.html'] ='Website/searchProduct';
$route['search.html/(:any)'] ='Website/searchProduct/$1';
$route['subscribe-now.html']='Website/SubscribeNow';
$route['update-cart.html']='Website/updateCart';

$route['add-location.html']='Website/addlocationForSearch';
$route['ajax-apply-coupon-code.html']='Admin/ajaxapplyCouponCode';
$route['user-register.html']='Website/registerNow';
$route['register-successfully.html']='Website/registerSuccessfully';
$route['register-now.html']='Website/registerForm';




$route['about-us.html']='Website/aboutus';
$route['terms-and-conditions.html']='Website/terms_and_conditions';
$route['privacy.html']='Website/privacy';
$route['returns-and-exchanges.html']='Website/returnsandexchanges';
$route['shipping-and-delivery.html']='Website/shippingdelivery';
$route['faq.html']='Website/faq';
$route['category-list.html']='Website/category_lists';
$route['membership.html']='Website/membership';
$route['purchase-membership.html']='Website/purchasemembership';
$route['notification.html']='Website/notification';
$route['membership-benefits.html']='Website/membershipbenefits';



$route['dashboard.html']='Website/dashboard';
$route['user-profile.html']='Website/userProfile';
$route['subscription-order-list.html']='Website/userOrderSubscription';
$route['edit-profile.html']='Website/editProfile';
$route['change-password.html']='Website/changepassword';
$route['order-history.html/(:any)']='Website/orderHistory/$1';
$route['order-history.html']='Website/orderHistory/';
$route['forget-password.html']='Website/forgetPassword';
$route['verify-otp.html']='Website/OTPVerification';
$route['family-member.html']='Website/userfamilyMember';


$route['add-to-cart.html']='Website/addtocart';
$route['shopping-cart.html']='Website/shoppingcart';
$route['checkout-billing.html']='Website/checkoutBilling';
$route['billing-checkout.html'] = 'Website/billing_checkout';
$route['checkout.html']='Website/checkoutData';




$route['subscribe-billing.html']='Website/prosubscribe';
$route['submit-subscribe-billing.html']='Website/subscribe_billing_checkout';
$route['subscribe-checkout.html']='Website/subcheckoutData';
$route['subscribe-payment.html']='Website/subscribeMakePayment';



$route['order-now.html']='Website/orderNow';
$route['apply-coupon.html']='Website/applyCouponCode';
$route['discount-offers.html']='Website/discountoffers';

$route['payment.html']='Website/makePayment';
$route['genrateinv-payment.html/(:any)']='Website/genrateinvPayment/$1';
$route['genrate-payment-success.html']='Website/genrate_payment_success';
$route['payment-success.html']='Website/paymentsuccess';
$route['sub-payment-success.html']='Website/subpaymentsuccess';


////////paytm////////////////
$route['pgRedirect.html']='Website/paytmpgRedirect';
$route['pgResponse.html']='Website/paytmpgResponse';
$route['TxnStatus.html']='Website/paytmTxnStatus';



//repayment
$route['repaytmpgRedirect.html']='Website/repaytmpgRedirect';
$route['repaytmpgResponse.html']='Website/repaytmpgResponse';

//////// revnue and share ////////////////
$route['revnuepgRedirect.html']='Website/revnuepgRedirect';
$route['revnuepgResponse.html']='Website/revnuepgResponse';

/////////////front invoice////////////////////
$route['invoice.html']='Website/invoice_history';



$route['payment-failure.html']='Website/paymentFailure';
$route['refer-and-earn.html']='Website/referandEarn';

$route['amount-transaction.html']='Website/transaction';

$route['membership-payment-success.html']='Website/membershippaymentsuccess';


$route['discounted-products.html']='Website/discountedproducts';
$route['popular-products.html']='Website/popularproducts';

$route['edit-billing-address.html/(:any)']='Website/editbillingaddress/$1';
$route['check-redirect.html']='Website/checkRedirect';


$route['add-sub-user-address.html']='Website/show_add_sub_address';

$route['multi_address_edit.html']='Website/show_multi_address_edit';






/*****App Route***********************************************************//////////
// $route['app/register']='App/registerAppUser';
// $route['app/otp-verification']='App/submitOTPVerification';
// $route['app/resendotp']='App/resendotp';
$route['app/app-user-login']='App/AppUserLogin';
$route['app/get-user-profile']='App/getUserProfile';
$route['app/update-user-profile']='App/updateUserProfile';
$route['app/changepassword']='App/changePassword';
$route['app/get-main-cat']='App/getMainCatListForSiteall';
$route['app/get-sub-cat']='App/getSubCatListForSiteall';
$route['app/get-category-product']='App/getcategoryProduct';

$route['app/get-all-product']='App/getallProduct';

// $route['app/get-child-product']='App/getchildProduct';
// $route['app/get-product-gallery']='App/getProductGallery';
// $route['app/get-related-product']='App/getRelatedProduct';
// $route['app/get-new-product']='App/getNewProdict';
// $route['app/get-discounted-prodict']='App/getDiscountedProdict';
// $route['app/get-sales-prodict']='App/getSalesProdict';
// $route['app/check-pincode']='App/addpincodeForSearch';
$route['app/search-product']='App/searchProduct';
$route['app/product-suggestions']='App/productsuggestions';
$route['app/product-detail']='App/getProductDetail';


$route['app/add-address']='App/addAddress';
$route['app/get-save-address']='App/getsaveAddress'; // home page profile and pagination
$route['app/get-save-address-checkout']='App/getsaveAddresscheckout';// page profile checkout
$route['app/update-save-address']='App/updateSaveAddress';
$route['app/display-single-address']='App/displaysingleaddress';
$route['app/get-billing-address']='App/getbillingaddress';
$route['app/delete-save-address']='App/deletesaveaddress';
// $route['app/applyCouponCode']='App/applyCouponCode';


// $route['app/add-to-cart']='App/addtocart';
$route['app/get-total-cart-amount']='App/getcarttotal';
$route['app/get-cart-gst-amount']='App/getcarttotalgst';
$route['app/get-cart-order-amount']='App/getcartorderamount';
$route['app/cart-delete']='App/deletecartitem';
$route['app/get-cart-data']='App/getCartData';

// $route['app/check-product-stock']='App/checkproductstock';
$route['app/order-now']='App/insertordernow';
$route['app/make-order-payment']='App/makeOrderPayment';
$route['app/makeOrderPaymentpaytm']='App/makeOrderPaymentpaytm_checksum'; 
$route['app/get-order-list']='App/getorderlist';
$route['app/cancel-order']='App/cancelOrder';
// $route['app/get-offer']='App/getOfferCouponcode';
$route['app/notification']='App/notification';
// $route['app/transaction']='App/transaction';
// $route['app/getmembershippack']='App/getmembershipPack';
// $route['app/delivery-amount']='App/delivery_amount';
// $route['app/purchase-membership']='App/purchasemembership';
// $route['app/membership-payment']='App/membershipPayment';
 $route['app/apphomepage']='App/apphomepage';
 
 $route['app/brandlist']='App/brandlist';
 $route['app/brandlist-product']='App/brandlistproduct';
$route['app/forget-password']='App/forgetPassword';

// $route['app/get-product-details-banner']='App/getProductdetailsbanner';
// $route['app/delivery-slot']='App/getTimeSlotForBooking';
// $route['app/re-order']='App/reorder';
// $route['app/get-product-review']='App/getreview';
// $route['app/submit-product-review']='App/productreview';
 $route['app/get-recent-order']='App/recentorder';
  $route['app/allowed-cod']='App/allowed_cod';
   $route['app/cartadd']='App/cartadd';

