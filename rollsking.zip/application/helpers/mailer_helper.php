<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if ( ! function_exists('mailerHtml'))
{
function mailerHtml($message)
{		 $message = '<html>
   <body>
      <table style="border:10px solid #FFDD00" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="650">
         <tbody>
            <tr>
               <td align="left" valign="top">
                  <table style="border-bottom:1px solid #cccccc;background:#ffffff;" border="0" cellpadding="0" cellspacing="0" width="650">
                     <tbody>
                        <tr>
                           <td style="padding:5px" align="left" valign="middle" width="275"><img class="CToWUd" alt="thekiranewala.com" src="https://rollsking.in/beta/assets/img/logo/logo_.png"  width="320"></td>
                           <td style="font-family:Arial;font-size:14px;color:#555555;padding:30px" align="right" valign="middle" width="255">&nbsp;</td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
            <tr>
               <td align="left" valign="top">
                  <table border="0" cellpadding="0" cellspacing="0" width="650">
                     <tbody>
                        <tr>
                           <td colspan="3" height="30" width="100%">&nbsp;</td>
                        </tr>
                        <tr>
                           <td width="30">&nbsp;</td>
                           <td style="font-size:13px;color:#333333" width="590">
                              <p style="font-family:Arial;color:#434A54;margin-bottom:0.5em;margin-top:0">'.$message.'</p>
                              <div><b> Thank you !</b> </div>
                              <div><b> <span class="il">Rollsking</span></b>  </div>
                           </td>
                           <td width="30">&nbsp;</td>
                        </tr>
                        <tr>
                           <td colspan="3" height="30" width="100%">&nbsp;</td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
         </tbody>
      </table>
   </body>
</html>'; return $message;
}

if ( ! function_exists('mailerHtml'))
{
function mailerHtmltwo($message)
{      $message = '<table width="650" border="0" cellspacing="0" cellpadding="0" style="margin:0 auto;border:1px dashed #00f;font-family:Verdana,Geneva,sans-serif;padding:20px;font-size:15px">
   <tbody>
      <tr>
         <td style="text-align:center;padding:10px;background:#4a9e46;color:#fff;font-size:18px"><strong> thekiranewala.com</strong></td>
      </tr>
      <tr>
         <td style="padding:10px 0;line-height:25px">
            '.$message.'
         </td>
      </tr>
      <tr>
         <td style="text-align:center;padding:0 10px 20px 10px"><strong></strong></td>
      </tr>
      <tr>
         <td style="text-align:center;padding:10px"><a href="#" style="padding:10px 20px;text-decoration:none;background:#4a9e46;color:#fff" target="_blank" data-saferedirecturl="">Go To Website</a>
         </td>
         <td>
         </td>
      </tr>
   </tbody>
</table>'; return $message;}
}

}
