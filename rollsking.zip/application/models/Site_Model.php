<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

 class Site_Model extends CI_Model {

  function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	public function getSiteSetting()
	{
		$this->db->select('*');
		$this->db->where('setting_id',1);
		$getResult = $this->db->get('kh_site_setting');
		return $getResult->row(); 
	}	
	public function insertregister()
	{
		$userId = $this->getUserDetailByMobile($this->input->post("mobile_number"));

		if(empty($userId))
		{
			$todayDate = date("Y-m-d h:i:s");
			$this->db->set("user_name",$this->input->post("full_name"));
			$this->db->set("user_email",$this->input->post("email"));		 
			$this->db->set("user_mobile",$this->input->post("mobile_number"));	
			$this->db->set('user_state',$this->input->post("state"));
			$this->db->set("user_password",md5($this->input->post("password")));
			$this->db->set("user_password_text",$this->input->post("password"));
			$source="Web";
			$this->db->set("user_source",$source);
			$this->db->set("user_status",1);
			$this->db->set("user_activation",0);
			$this->db->set("user_updated",$todayDate);
			$this->db->set("user_created",$todayDate);
			$this->db->insert("kh_user_list");
			$p=$this->db->insert_id();

			$username="ROK00".$p;
			$this->db->set('username',$username);
			$this->db->where('user_id',$p);
			$this->db->update("kh_user_list");
			return $p;
		}else{
			$todayDate = date("Y-m-d h:i:s");
			$this->db->set("user_name",$this->input->post("full_name"));
			$this->db->set("user_email",$this->input->post("email"));		 	
			$this->db->set('user_state',$this->input->post("state")); 
			$this->db->set("user_password",md5($this->input->post("password")));
			$this->db->set("user_password_text",$this->input->post("password"));
			$this->db->set("user_updated",$todayDate);
			$this->db->where("user_id",$userId->user_id);
			$this->db->update("kh_user_list");
			return $user_id = $userId->user_id;
		}
	}
	public function getLoginByMobileNumber($mobileNumber)
	{
		$this->db->where('user_mobile',$mobileNumber);
		$this->db->where('user_status',1);
		$this->db->order_by('user_id','desc');
		return $query=$this->db->get('kh_user_list')->row();
	}
    public function google_user_list($email)
	{
		$this->db->select("*");
		$this->db->where("user_email",$email);
		return $this->db->get("kh_user_list")->row();
	}
	
	public function googleinsertregister($name,$email)
	{
		    $todayDate = date("Y-m-d h:i:s");
			$this->db->set("user_name",$name);
			$this->db->set("user_email",$email);		 
			$source="Google";
			$this->db->set("user_source",$source);
			$this->db->set("user_status",1);
			$this->db->set("user_activation",1);
			$this->db->set("user_updated",$todayDate);
			$this->db->set("user_created",$todayDate);
			$this->db->insert("kh_user_list");
			$p=$this->db->insert_id();

			$username="KHA00".$p;
			$this->db->set('username',$username);
			$this->db->where('user_id',$p);
			$this->db->update("kh_user_list");
			
			return $p;
	}
	
	
	public function getWalletAmount($id)
	{
		$this->db->where("user_id",$id);
		return $this->db->get("kh_user_list")->row();
	}

	public function getsave_More_address($id)
	{
		$this->db->where("user_id",$id);
  		//$this->db->where("status",2);
		return $this->db->get("kh_save_address")->result();
	}

	public function getsave_More_address_chk_biling($id)
	{
		$this->db->where("user_id",$id);
  		$this->db->where("status",2);
		return $this->db->get("kh_save_address")->result();
	}

	public function getsingle_More_address($addressid)
	{	
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
	    $this->db->where('id',$addressid);
		$this->db->where('status',1);
		return $this->db->get('kh_save_address')->row();
		  
	}

	public function getsingle_More_address_invo($userid)
	{	
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
	    $this->db->where('id',$userid);
		$this->db->where('status',2);
		return $this->db->get('kh_save_address')->row();
		  
	}
	function getSiteLoginAdmin($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		$query = $this->db->get('kh_user_list');
        return $query->row();
	}
	public function getUserDetailByMobile($user_mobile)
	{
		$this->db->select('*');
		$this->db->where('user_mobile',$user_mobile);
		$query = $this->db->get('kh_user_list');
        return $query->row();	
	}
	public function insertOtp($mobile , $otpNum)
	{
		$date = date('Y-m-d h:i:s');
		$time = time();
		$lapt_time = ($time - ($time % (15 * 60)));
		$in15mins =  $lapt_time+ (15 * 60);
		
		$ValidUpto = date('Y-m-d h:i:s', $in15mins);
		
		$this->db->set('otp_mobile',$mobile);
		$this->db->set('otp_number',$otpNum);
		$this->db->set('otp_status',0);
		$this->db->set('otp_valid',$ValidUpto);
		$this->db->set('otp_created',$date);
		$query = $this->db->insert('kh_otp_num');
		return date('h:i', $in15mins);
	}
	public function confirmOtp($mobile , $otpNum)
	{
		$this->db->where('mobile_number',$mobile);
		$this->db->order_by('mobile_number','desc');
		$referData=$this->db->get('kh_referral')->row();

		
		if(!empty($referData)){
			$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ ".$referData->refer_amount." WHERE `username`= '".$referData->refer_id."'");

			$this->db->where("username",$referData->refer_id);
			$userdataforid= $this->db->get("kh_user_list")->row();

			$this->db->select('*');
			$this->db->where('user_id',$userdataforid->user_id);
			$this->db->order_by('transaction_id','desc');
			$this->db->limit(1);
			$lastEntery=$this->db->get('kh_wallet_transaction')->row();

			$credit_amount=$referData->refer_amount;
			$available_amount=$lastEntery->transaction_available_amount + $referData->refer_amount;

			$this->db->set('user_id',$userdataforid->user_id);			
			$this->db->set('transaction_from','Referral');
			$this->db->set('transaction_credit_amount',$credit_amount);
			$this->db->set('transaction_available_amount',$available_amount);
			$this->db->set('transaction_status',1);
			$this->db->insert('kh_wallet_transaction');

			$insertid=$this->db->insert_id();
			$transaction_number="KHAQWERTYUIO00".$insertid;
			$this->db->set('transaction_number',$transaction_number);
			$this->db->where('transaction_id',$insertid);
			$this->db->update('kh_wallet_transaction');
		}
		
		
		$this->db->select('*');
		$this->db->where('otp_number',$otpNum);
		$this->db->where('otp_mobile',$mobile);
		$this->db->order_by('otp_id','desc');
		$this->db->limit(1);
 
		$query = $this->db->get('kh_otp_num');
        return $query->num_rows();	
	}
	public function updateotp($mobile , $otpNum)
	{
		$this->db->set('otp_status',1);
		$this->db->where('otp_number',$otpNum);
		$this->db->where('otp_mobile',$mobile);
		$this->db->update('kh_otp_num');
	}
	public function getSiteLogin()
	{
		$this->db->where('user_email',$this->input->post('user_email'));
		$this->db->where('user_status',1);
		//$this->db->where('user_activation',1);
		$query1=$this->db->get('kh_user_list')->num_rows();

		$this->db->where('user_email',$this->input->post('user_email'));
		$this->db->where('user_status',1);
		//$this->db->where('user_activation',1);
		$query=$this->db->get('kh_user_list')->row();

		if ($query1 == 1) {
			return $query;
		}else{
			$this->db->where('user_mobile',$this->input->post('user_email'));
			$this->db->where('user_status',1);
			//$this->db->where('user_activation',1);
			return $query2=$this->db->get('kh_user_list')->row();

		}
	}
	public function getOtpForResend($mobile)
	{
	    $this->db->select('*');
		$this->db->where('otp_mobile',$mobile);
		$this->db->order_by('otp_id','desc');
		$this->db->limit(1);
		$query = $this->db->get('kh_otp_num');
        return $query->row();
	}
	public function getCartList($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->where('cart_status',1);
		return $this->db->get('kh_cart')->result();
	}
	public function getCouponInfo($couponCode)
	{
		$this->db->select('*');
		$this->db->where('coupon_code',$couponCode);
		$this->db->where('coupon_status',1);
		$this->db->where('coupon_valid_upto >=',date('Y-m-d 00:00:00'));
		$getResult = $this->db->get('kh_couponcode');
		return $getResult->row(); 
	}	
	public function getCartItem()
	{
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('cart_status',1);
		$query=$this->db->get('kh_cart');
		return $query->result();
	}

	 public function getLoginUserName($id)
    {
        $this->db->select('*');
		$this->db->where('user_id',$id);
		$getResult = $this->db->get('kh_user_list');
        return $getResult->row();
    }
    public function getUserName($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		return $this->db->get('kh_user_list')->row();
	}
		public function getOrderDataforUserDashboard()
	{
		$this->db->select('*');
		$this->db->where('order_userid',$this->session->userdata('activeUserId'));
		$query=$this->db->get('kh_order_tb');
		return $query->result();
	}
	public function getUserDataprofile()
	{
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('user_status',1);
		$query=$this->db->get('kh_user_list');
		return $query->row();
	
	}
	public function changpass()
	{
		$this->db->set("user_password",md5($this->input->post("pass")));
		$this->db->set("user_password_text",$this->input->post("pass"));
		$this->db->where("user_id",$this->session->userdata("activeUserId"));
		$this->db->update("kh_user_list");		
	}
	public function orderDatas()
	{
		$this->db->select('*');
		$this->db->where('order_userid',$this->session->userdata('activeUserId'));


		$addressID=$this->uri->segment(2);
		if($addressID!=null AND $addressID !=0)
		{
			$this->db->where('user_address_id',$addressID);
		}
		$this->db->order_by('order_id','DESC');
		$query=$this->db->get('kh_order_tb');
		return $query->result();
	}
	public function getOrderItem($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}



	public function orderSubscriptionDatas()
	{
		$this->db->select('*');
		$this->db->where('order_userid',$this->session->userdata('activeUserId'));
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->result();
	}
	public function getSubscriptionOrderServces($id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$id);
		$query=$this->db->get('kh_subscribe_order_items');
		return $query->result();
	}

	public function forgetPasswordEmail()
	{
	    $this->db->select('*');
		$this->db->where('user_email',$this->input->post('email'));
		$query = $this->db->get('kh_user_list');
        return $query->row();
	}
	public function getOrderServces($id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$id);
		$query=$this->db->get('kh_order_items');
		return $query->result();
	}
	public function updateprofile()
	{
		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("user_name",$this->input->post("name"));
		//$this->db->set("user_email",$this->input->post("email"));
		$this->db->set("user_mobile",$this->input->post("phone"));
		$this->db->set("user_city",$this->input->post("city"));
		$this->db->set("user_state",$this->input->post("state"));
		$this->db->set("user_zipcode",$this->input->post("zipcode"));
		$this->db->set("user_address",$this->input->post("address"));

		//$this->db->set("user_age",$this->input->post("age"));
		//$this->db->set("user_gender",$this->input->post("gender"));
		$this->db->set("user_updated",$todayDate);
		$this->db->where("user_id",$this->session->userdata("activeUserId"));
		$this->db->update("kh_user_list");
	}
	public function getCatListForSite()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->limit(7);
		return $this->db->get('kh_category')->result();
	}
	public function getCatListForSiteformobile()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->limit(7);
		return $this->db->get('kh_category')->result();
	}
	public function getCatListForSiteall()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->where('category_parent_id',0);
		return $this->db->get('kh_category')->result();
	}
	public function getCatListForForMenu()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->where('category_parent_id',0);
		$this->db->limit(15);
		return $this->db->get('kh_category')->result();
	}
	public function getSubCategoryForMenu($id)
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->where('category_parent_id',$id);
		return $this->db->get('kh_category')->result();
	}
	public function getCatListForSiteiner()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		return $this->db->get('kh_category')->result();
	}
		public function getCatListForSiteinerlist()
	{
		$this->db->select('*');
		$this->db->where('category_parent_id',0);
		$this->db->where('category_status',1);
		return $this->db->get('kh_category')->result();
	}
	public function getCatListForSiteinerIner($url)
	{
	    $this->db->select('*');
		$this->db->where('category_url',$url);
		$this->db->where('category_status',1);
	    return $this->db->get('kh_category')->row();
	}
	
	public function getParentIDcat($id)
	{
	    $this->db->select('*');
		$this->db->where('category_parent_id',$id);
		$this->db->where('category_status',1);
		return $this->db->get('kh_category')->result(); 
	}
	public function getProductBySearchcount()
	{
		
		

		$this->db->select('*');
		$this->db->like('product_name', $this->input->get('product_name'), 'before'); 
        $this->db->or_like('product_name', $this->input->get('product_name'), 'after');  
        $this->db->or_like('product_name', $this->input->get('product_name'), 'none');   
        $this->db->or_like('product_name', $this->input->get('product_name'), 'both');   
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'before'); 
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'after');  
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'none');   
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'both');
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'before'); 
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'after');  
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'none');   
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'both');
		if(!empty($pincode)){
			$this->db->where_in('product_id',$product_id);
		}
		$this->db->where('product_status',1);
		return $this->db->get('kh_product')->result();

	}

	public function getProductBySearch($limit, $start)
	{
		
		$this->db->select('*');
		$this->db->like('product_name', $this->input->get('product_name'), 'before'); 
        $this->db->or_like('product_name', $this->input->get('product_name'), 'after');  
        $this->db->or_like('product_name', $this->input->get('product_name'), 'none');   
        $this->db->or_like('product_name', $this->input->get('product_name'), 'both');   
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'before'); 
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'after');  
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'none');   
        $this->db->or_like('product_tags', $this->input->get('product_name'), 'both');
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'before'); 
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'after');  
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'none');   
        $this->db->or_like('product_desc', $this->input->get('product_name'), 'both');
		if(!empty($pincode)){
			$this->db->where_in('product_id',$product_id);
		}
		$this->db->limit($limit, $start);
		$this->db->where('product_status',1);
		return $this->db->get('kh_product')->result();
	}
	public function getProductNameForSuggestions()
	{
		$this->db->select('*');
		$this->db->where('product_status',1);
		//$this->db->group_by('product_name');
		return $this->db->get('kh_product')->result();
	}

	public function getCategoryProduct($CatId)
	{

			$this->db->select("p.*");
			$this->db->join("kh_category_products cp","cp.prod_id=p.product_id");
			$this->db->where("cp.cat_id",$CatId);
			$this->db->where('p.product_status',1);
			return $this->db->get("kh_product p")->result(); 
		
	}

	public function getCategoryProducts($limit,$page,$CatId)
	{


			$this->db->select("p.*");
			$this->db->join("kh_category_products cp","cp.prod_id=p.product_id");
			$this->db->where("cp.cat_id",$CatId);
			$this->db->order_by('product_id','desc');
			//$this->db->order_by('rand()');
			$this->db->limit($limit,$page);
			$this->db->where('p.product_status',1);
			return $this->db->get("kh_product p")->result(); 
		
	}
	public function getCatDetail($url)
	{
		$this->db->select("*");
		$this->db->where("category_url",$url);
		return  $this->db->get("kh_category")->row();
	}


	public function getProductDataForCart($product_id)
	{
		$this->db->select('*');
		$this->db->where('product_id',$product_id);
		return $this->db->get('kh_product')->row();
	}
	public function getProductDetailbyUrl($url)
	{
		$this->db->select("*");
		$this->db->where("product_url",$url);
		return  $this->db->get("kh_product")->row();
	}

	public function getProductPhoto($id)
	{
		$this->db->select('*');
		$this->db->where('image_product_id',$id);
		$getResult = $this->db->get('kh_product_images');
		return $getResult->result(); 
	}	
	public function generateOrderNo()
	{
		$this->db->set('timestamp',time());	
		$this->db->insert('kh_order_number');	
		return $orderId = $this->db->insert_id();	
	}
	public function group_by($key, $data) {
    $result = array();

	    foreach($data as $val) {
	        if(array_key_exists($key, $val)){
	            $result[$val[$key]][] = $val;
	        }else{
	            $result[""][] = $val;
	        }
	    }

	    return $result;
	}
	/*public function insertorder()
	{


		$orderCode = $this->generateOrderNo();
		$date = date("Y-m-d");
		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("order_unique_code",$orderCode);
		$this->db->set("order_userid",$this->session->userdata("activeUserId"));
		$this->db->set("order_delivery",$this->input->post('delivery'));
		$this->db->set("order_amount",$this->input->post('totalAmount'));	
		$this->db->set("order_firstname",$this->input->post('firstname'));
		$this->db->set("order_email",$this->input->post('email'));
		$this->db->set("order_phone",$this->input->post('phone'));
		$this->db->set("order_state",$this->input->post('state'));
		$this->db->set("order_city",$this->input->post('city'));
		$this->db->set("order_address",$this->input->post('address'));
		$this->db->set("order_zipcode",$this->input->post('zipcode'));
		$this->db->set("payment_type",$this->input->post('payment_type'));
		$this->db->set("gstnmber",$this->input->post('usergstno'));
		$this->db->set("user_address_id",$this->input->post('useraddressid'));


	    $this->db->set("order_created",$todayDate);
		$this->db->set("order_status",1);
		$this->db->set("order_type",1);
		$this->db->set("order_created_by",1);
		$this->db->insert("kh_order_tb");
		$orderId = $this->db->insert_id();
	

		$cartItem=$this->cart->contents();
		foreach($cartItem as $pd){

			$this->db->set("order_id",$orderId);
			$this->db->set("user_id",$this->session->userdata("activeUserId"));
			$this->db->set("product_id",$pd['id']);
			$this->db->set("one_price",$pd['price']);
			$this->db->set("qty",$pd['qty']);
			$productdata=$this->db->select('*')->where('product_id',$pd['id'])->get('kh_product')->row();
			//print_r($productdata);die;
			$this->db->set("code",$productdata->product_code);
			$this->db->set("hsncode",$productdata->hsncode);
			$this->db->set('gstslab',$productdata->slab);
			$this->db->set("name",$pd['name']);
			$this->db->set("price",$pd['subtotal']);
			$this->db->set("product_purchase_price",$productdata->kh_purchase_price);
			$this->db->set("status",1);
			$this->db->set("created",$todayDate);
			$this->db->insert("kh_order_items");
		}	

		return $orderId;
	}*/
	
		public function insertorder()
	{

		
		$orderCode = $this->generateOrderNo();
		$date = date("Y-m-d");
		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("order_unique_code",$orderCode);
		$this->db->set("order_userid",$this->session->userdata("activeUserId"));
		$this->db->set("order_delivery",$this->input->post('delivery'));
		$this->db->set("order_amount",$this->input->post('totalAmount'));	
		$this->db->set("order_firstname",$this->input->post('firstname'));
		$this->db->set("order_email",$this->input->post('email'));
		$this->db->set("order_phone",$this->input->post('phone'));
		$this->db->set("order_state",$this->input->post('state'));
		$this->db->set("order_city",$this->input->post('city'));
		$this->db->set("order_address",$this->input->post('address'));
		$this->db->set("order_zipcode",$this->input->post('zipcode'));
		$this->db->set("payment_type",$this->input->post('payment_type'));
		$this->db->set("gstnmber",$this->input->post('usergstno'));
		$this->db->set("user_address_id",$this->input->post('useraddressid'));


	    $this->db->set("order_created",$todayDate);
		$this->db->set("order_status",1);
		$this->db->set("order_type",1);
		$this->db->set("order_created_by",1);
		$this->db->insert("kh_order_tb");
		$orderId = $this->db->insert_id();

		$cartItem=$this->db->select('*')->where('user_id',$this->session->userdata("activeUserId"))->get('kh_cart')->result();

		foreach($cartItem as $pd){
			//print_r($pd);

			
			$this->db->set("order_id",$orderId);
			$this->db->set("user_id",$this->session->userdata("activeUserId"));
			$this->db->set("product_id",$pd->product_id);
			$this->db->set("one_price",$pd->one_price);
			$this->db->set("qty",$pd->qty);
			$productdata=$this->db->select('*')->where('product_id',$pd->product_id)->get('kh_product')->row();
			//print_r($productdata);die;
			$this->db->set("code",$productdata->product_code);
			$this->db->set("hsncode",$productdata->hsncode);
			$this->db->set('gstslab',$productdata->slab);
			$this->db->set("name",$pd->name);
			$this->db->set("price",$pd->price);
			$this->db->set("product_purchase_price",$productdata->kh_purchase_price);
			$this->db->set("status",1);
			$this->db->set("created",$todayDate);
			$this->db->insert("kh_order_items");

		}	
		return $orderId;
	}


	public function getOrderData($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_tb")->row();
	}

	public function getOrderItemFromCheckout($orderid)
	{
		$this->db->select('*');
		$this->db->where_in('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}  

	public function insertPayment()
	{
		
		$data= array(
			'order_id' => $_POST['merchant_order_id'],
			'trans_id' => $_POST['merchant_trans_id'],
			'product_info_id' => $_POST['merchant_product_info_id'],
			'card_holder_name_id' => $_POST['card_holder_name_id'],
			'merchant_amount' => $_POST['merchant_amount'],
			'payment_status' => 1
		);
		$this->db->insert('kh_order_payment',$data);


		$this->db->set("order_payment_status",1);
		$this->db->where('order_id',$_POST['merchant_order_id']);
		$this->db->update("kh_order_tb");
			
	}
	

	

	
	public function getSalesProdict()
	{
		$this->db->select("*");
		$this->db->where("featured_status",1);
 		$this->db->order_by('rand()');
 		$this->db->where('product_status',1);
		$this->db->limit(8);
		return  $this->db->get("kh_product")->result();
	}
	public function getDiscountedProdict()
	{
		$this->db->select("*");
		$this->db->where("discounted_products",1);
 		$this->db->order_by('rand()');
 		$this->db->where('product_status',1);
		$this->db->limit(8);
		return  $this->db->get("kh_product")->result();
	}
	public function getNewProdict()
	{
		$this->db->select("*");
		$this->db->where("new_products",1);
 		$this->db->order_by('rand()');
 		$this->db->where('product_status',1);
		$this->db->limit(8);
		return  $this->db->get("kh_product")->result();
	}
	public function insertSubscribed()
	{
		$this->db->set('sub_email',$this->input->post('email'));
		$this->db->set('sub_status',1);
		$this->db->insert('kh_subscribe');
	}
	public	function getChildProductForProductDetails($id)
	{
		$this->db->select('*');
		$this->db->where('parent_product',$id);
		$this->db->or_where('product_id',$id);
		$getResult = $this->db->get('kh_product');
        return $getResult->result(); 
	}
	public function GetProductImages($id)
	{
	    $this->db->select('*');
		$this->db->where('product_id',$id);
		$getResult = $this->db->get('kh_product');
        return $getResult->row(); 
	}
	
	public function getCategoryProductForcolumn($CatId)
	{
		$this->db->select("p.*");
		$this->db->join("kh_category_products cp","cp.prod_id=p.product_id");
		$this->db->where("cp.cat_id",$CatId);
 		$this->db->order_by('rand()');
 		$this->db->where('product_status',1);
		$this->db->limit(8);
		return $this->db->get("kh_product p")->result(); 
	}
	
	public function getallProduct()
	{
		$this->db->select("*");
 		$this->db->order_by('rand()');
 		$this->db->where('product_status',1);
		$this->db->limit(12);
		return $this->db->get("kh_product")->result(); 
	}
	public function getallProduct_m_p($id)
	{
		$this->db->select("*"); 
 		$this->db->where('product_id',$id);
		return $this->db->get("kh_product")->row(); 
	}
	
	public function getallproduct_count(){
		$this->db->select("*");
 		$this->db->where('product_status',1);
		return $this->db->get("kh_product")->num_rows(); 
	}
	public function getallproduct_count_start($limit, $start) {
		$this->db->select("*");
 		$this->db->where('product_status',1);
        $this->db->limit($limit, $start);
        $query = $this->db->get("kh_product");
        return $query->result();
    }


	/////////////////////////membership/////////////////////////////
	public function getmembershipPack()
	{
		$this->db->select('*');
		$this->db->where('pack_status',1);
		$getResult = $this->db->get('kh_membership_pack');
        return $getResult->result(); 
	}


	public function purchasemembership()
	{
		$this->db->select('*');
		$this->db->where('pack_id',$this->input->post('pack_id'));
		$getResult = $this->db->get('kh_membership_pack')->row(); 

		$expinmonths="+".$getResult->pack_time_duration."month";
		$expdate = date('Y-m-d',  strtotime($expinmonths));

		$data = array(
			'user_id' => $this->session->userdata('activeUserId'), 
			'pack_name' => $getResult->pack_name, 
			'pack_price' => $getResult->pack_price, 
			'pack_time_duration' => $getResult->pack_time_duration, 
			'pack_desc' => $getResult->pack_desc, 
			'membership_exp' => 0,
			'purchase_data' => $time=date("Y-m-d"),
			'expiry_date' => $expdate,
			'payment_status' => 0, 
			'super_pack' =>  $getResult->super_pack
		);
		$this->db->insert('kh_purchase_membership',$data);
		$insertid=$this->db->insert_id();

		$membership_id="MEMBER".$insertid;

		$this->db->set('membership_id',$membership_id);
		$this->db->where('purchase_id',$insertid);
		$this->db->update('kh_purchase_membership');

		return $insertid;
	}
	public function getMembershipOrderData($membershipid)
	{
		$this->db->select('*');
		$this->db->where('purchase_id',$membershipid);
		return $this->db->get("kh_purchase_membership")->row();
	}
	public function getUserDataForMembership($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		return $this->db->get("kh_user_list")->row();
	}
	public function getMemberShipStatus()
	{
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('payment_status',1);
		$this->db->where('membership_exp',1);
		return $this->db->get("kh_purchase_membership")->row();
	}
	public function expiredMembership($id)
	{
		$this->db->set('membership_exp',0);
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('purchase_id',$id);
		$this->db->update('kh_purchase_membership');
	}

	/////////////////////////End membership/////////////////////////


	////////////////////////getNotificationData/////////////////////
	public function getNotificationData()
	{
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('status',1);
		return $this->db->get('kh_notification')->result();
	}
	public function amount_transaction($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->limit(10);
		$this->db->order_by('transaction_id','desc');
		return $this->db->get('kh_wallet_transaction')->result();
	}
	
	////////////////////////getNotificationData//////////////////////

	public function checkProductInPincodeorNot($product_id)
	{
		$pincode=$this->session->userdata('pincode');
		if(!empty($pincode)){
			$searchData=$this->db->select('*')->where('bra_zip',$pincode)->get('kh_branch')->row();
			if(!empty($searchData)){
			   $this->db->where('brd_id',$searchData->bra_id);
    			$this->db->where('prod_id',$product_id);
    			$pincodechecks=$this->db->get('kh_branch_products')->row();
    			if(!empty($pincodechecks)){
    			    return $pincodechecks;
    			}else{
    			    return false;
    			} 
			}else{
			      return false;
			}
		}else{
			 return true;
		}
	}
	public function getPriceBypinCode($product_id,$zipcode)
	{
		$this->db->select('*');
		$this->db->where('bra_zip',$zipcode);
		$query=$this->db->get('kh_branch')->row();
        if(!empty($query)){
		    $this->db->select('*');
		    $this->db->where('branch_id',$query->bra_id);
		    $this->db->where('product_id',$product_id);
		    return $this->db->get('kh_product_price_by_pincode')->row();
        }else{
			 return false;
		}
	}

    public function getSubCatListForPrint($id)
	{
	    $this->db->select('*');
		$this->db->where('category_id',$id);
		$this->db->where('category_status',1);
		$query=$this->db->get('kh_category')->row();
		if(!empty($query)){
		    return $query;
        }else{
			 return false;
		}
	}

    public function getParentIDcatForCat($id)
	{
	    $this->db->select('*');
		$this->db->where('category_parent_id',$id);
		$this->db->where('category_status',1);
		return $this->db->get('kh_category')->result(); 
	}
	public function getSaveAddress()
	{
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('pin_code',$this->session->userdata('pincode'));
		$this->db->where('status',1);
		return $this->db->get('kh_save_address')->result();
	}
	public function getEditAddressData($addressid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$this->db->where('id',$addressid);
		$this->db->where('status',1);
		return $this->db->get('kh_save_address')->row();
	}
	public function updateEditaddress()
	{
		$this->db->set('user_name',$this->input->post('first_name'). " " .$this->input->post('last_name'));
		$this->db->set('user_mobile',$this->input->post('phone'));
		$this->db->set('user_email',$this->input->post('email'));
		$this->db->set('user_shop',$this->input->post('outletname'));
		$this->db->set('user_gst',$this->input->post('gstnumber'));
		$this->db->set('user_state',$this->input->post('state'));
		$this->db->set('user_city',$this->input->post('city'));
		$this->db->set('user_address',$this->input->post('address'));
		$this->db->set('pin_code',$this->input->post('pincode'));
		$this->db->where('id',$this->input->post('id'));
		$this->db->update('kh_save_address');
	}
	public function getDiscountOffers()
	{
		$this->db->select('*');
		$this->db->where('coupon_valid_upto >=',date('Y-m-d'));
		$this->db->where('coupon_hide_show',0);
		return $this->db->get('kh_couponcode')->result();
	}
    public function getProductStatusforOutOfstork($id)
	{
		$this->db->select('*');
		$this->db->where('product_id',$id);
		return $this->db->get('kh_product')->row();
	}
	public function getRelatedCagegoryProduct($id)
	{
		$this->db->select('*');
		$this->db->where('prod_id',$id);
		$category_ids=$this->db->get('kh_category_products')->result();
		if(!empty($category_ids)){
		    foreach ($category_ids as $key => $ae) {
				$catid[]=$ae->cat_id;
			}
			$catids=array_unique($catid);
			$this->db->select('*');
			$this->db->where_in('cat_id',$catids);
			$productids=$this->db->get('kh_category_products')->result();
			if (!empty($productids)) {
				foreach ($productids as $key => $value) {
					$productid[]=$value->prod_id;
				}
				$product_id=array_unique($productid);
				$this->db->select('*');
				$this->db->where_in('product_id',$product_id);
				$this->db->order_by('rand()');
				$this->db->limit(10);
				return $this->db->get('kh_product')->result();
			}else{
			    return false;
			}	
		}else{
		    return false;
		}
	}


	public function getTimeSlotForBooking()
	{
	    $this->db->select('*');
	    $this->db->where('status',1);
	    return $this->db->get('kh_time_slot')->result();
	}
	public function getAbalableDeliverySlot($id)
	{
 		$date1 = date('Y-m-d 01:00:00', strtotime(date('Y-m-d h:i:s')));
 		$date2 = date('Y-m-d 24:00:00', strtotime(date('Y-m-d h:i:s')));
 	  	$date3 = date('Y-m-d h:i:s', strtotime($date1));
 		$date4 = date('Y-m-d h:i:s', strtotime($date2));


		$this->db->select('*');
		$this->db->where('order_created >',$date3);
		$this->db->where('order_created <',$date4);
		$this->db->where('slot_id',$id);
		$this->db->where("order_status !=",0);
		$this->db->where("order_status !=",6);
		$getResult = $this->db->get('kh_order_tb');
        return $getResult->num_rows(); 
	}


	public function subgenerateOrderNo()
	{
		$this->db->set('timestamp',time());	
		$this->db->insert('kh_subscribe_order_number');	
		return $orderId = $this->db->insert_id();	
	}

	
	public function getOrderDatasub($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_subscribe_order_tb")->row();
	}
	public function getOrderItemForSub($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_subscribe_order_items")->result();
	}
	public function subinsertPayment()
	{
		$data= array(
			'order_id' => $_POST['merchant_order_id'],
			'trans_id' => $_POST['merchant_trans_id'],
			'product_info_id' => $_POST['merchant_product_info_id'],
			'card_holder_name_id' => $_POST['card_holder_name_id'],
			'merchant_amount' => $_POST['merchant_amount'],
			'payment_status' => 1
		);
		$this->db->insert('kh_sub_order_payment',$data);


		$this->db->set("order_payment_status",1);
		$this->db->where('order_id',$_POST['merchant_order_id']);
		$this->db->update("kh_subscribe_order_tb");
	}
	public function getReview($product_id)
	{
		$reviewAlreadySubmi=$this->db->select('*')->where('product_id',$product_id)->order_by('review_id','desc')->get('kh_reviews')->result();
		return $reviewAlreadySubmi;
	}
	public function getUserDataForReview($id)
	{
		$userdata=$this->db->select('*')->where('user_id',$id)->get('kh_user_list')->row();return $userdata;
	}

	function getreturnorderajax($orderid)
	{
		  
		  $this->db->select('*');
		  $this->db->where('order_id',$orderid);
		  $this->db->set('status',0); 
		  return $this->db->get('kh_order_items')->row();
	}
	
	public function getstart_date_anddate($orderuserid){

		$this->db->select('*');
		$this->db->where('userid',$orderuserid);
		return $this->db->get('kh_genrate_inv')->result();
	}
	public function getsinglepayment($invid){

		$this->db->select('*');
		$this->db->where('inv_id',$invid);
		return $this->db->get('kh_genrate_inv')->row();
	}
	public function getrevnue_paytm($invid){

		$this->db->select('*');
		$this->db->where('inv_id',$invid);
		return $this->db->get('kh_genrate_inv')->row();
	}

	
	
	
}