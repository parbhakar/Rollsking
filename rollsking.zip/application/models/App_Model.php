<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class App_Model extends CI_Model {
  function __construct()
    {
        parent::__construct();
    }
	
	public function index()
	{

	}
	public function getUserEmail($email)
	{
		$this->db->where("user_email",$email);
		return $this->db->get('kh_user_list')->row();

	}
	public function getUserDetail($id)
	{
		$this->db->where("user_id",$id);
		return $this->db->get('kh_user_list')->row();
	}
	public function getproductpriceforcart($id){
    	$this->db->select('*');
		$this->db->where('product_id',$id);
		return $this->db->get('kh_product')->row();
	 }
	public function insertregister($user_name,$user_email, $user_mobile, $user_password,$user_state,$fcm_token,$refer_id)
	{
		$userId = $this->getUserDetailByMobile($user_mobile);

		if(empty($userId))
		{
			$todayDate = date("Y-m-d h:i:s");
			$this->db->set("user_name",$user_name);
			$this->db->set("user_email",$user_email);		 
			$this->db->set("user_mobile",$user_mobile);	
			$this->db->set('user_state',$user_state);
			$this->db->set("user_password",md5($user_password));
			$this->db->set("user_password_text",$user_password);
			$source="Web";
			$this->db->set("user_source",$source);
			$this->db->set("user_status",1);
			$this->db->set("user_activation",0);
			$this->db->set("fcm_token",$fcm_token);
			$this->db->set("user_updated",$todayDate);
			$this->db->set("user_created",$todayDate);
			$this->db->insert("kh_user_list");
			$p=$this->db->insert_id();

			$username="KHA00".$p;
			$this->db->set('username',$username);
			$this->db->where('user_id',$p);
			$this->db->update("kh_user_list");

// 			$referid=$refer_id;
// 			if(!empty($referid)){
// 				$this->db->set('refer_amount',1);
// 				$this->db->set('user_id',$p);
// 				$this->db->set('refer_id',$referid);
// 				$this->db->set('mobile_number',$user_mobile);
// 				$this->db->insert('kh_referral');
// 			}

// 			$referid=$this->input->post('refer_id');
// 			if(!empty($referid)){
// 				$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ 1 WHERE `username`= '".$referid."'");
// 			}
			return $p;
		}else{
			$todayDate = date("Y-m-d h:i:s");
			$this->db->set("user_name",$user_name);
			$this->db->set("user_email",$user_email);		 
			$this->db->set('user_state',$user_state);
			$this->db->set("fcm_token",$fcm_token);
			$this->db->set("user_password",md5($user_password));
			$this->db->set("user_password_text",$user_password);
			$this->db->set("user_updated",$todayDate);
			$this->db->where("user_id",$userId->user_id);
			$this->db->update("kh_user_list");
			return $user_id = $userId->user_id;
		}
	}
	public function getUserDetailByMobile($user_mobile)
	{
		$this->db->select('*');
		$this->db->where('user_mobile',$user_mobile);
		$query = $this->db->get('kh_user_list');
        return $query->row();	
	}
	public function insertOtp($mobile , $otpNum)
	{
		$date = date('Y-m-d h:i:s');
		$time = time();
		$lapt_time = ($time - ($time % (15 * 60)));
		$in15mins =  $lapt_time+ (15 * 60);
		
		$ValidUpto = date('Y-m-d h:i:s', $in15mins);
		
		$this->db->set('otp_mobile',$mobile);
		$this->db->set('otp_number',$otpNum);
		$this->db->set('otp_status',0);
		$this->db->set('otp_valid',$ValidUpto);
		$this->db->set('otp_created',$date);
		$query = $this->db->insert('kh_otp_num');
		return date('h:i', $in15mins);
	}
	public function confirmOtp($mobile , $otpNum)
	{
		$this->db->where('mobile_number',$mobile);
		$this->db->order_by('mobile_number','desc');
		$referData=$this->db->get('kh_referral')->row();

// 		if(!empty($referData)){
// 			$this->db->query("UPDATE `kh_user_list` SET `user_wallet_amount`=`user_wallet_amount`+ ".$referData->refer_amount." WHERE `username`= '".$referData->refer_id."'");

// 			$this->db->where("username",$referData->refer_id);
// 			$userdataforid= $this->db->get("kh_user_list")->row();

// 			$this->db->select('*');
// 			$this->db->where('user_id',$userdataforid->user_id);
// 			$this->db->order_by('transaction_id','desc');
// 			$this->db->limit(1);
// 			$lastEntery=$this->db->get('kh_wallet_transaction')->row();

// 			$credit_amount=$referData->refer_amount;
// 			$available_amount=$lastEntery->transaction_available_amount + $referData->refer_amount;

// 			$this->db->set('user_id',$userdataforid->user_id);			
// 			$this->db->set('transaction_from','Referral');
// 			$this->db->set('transaction_credit_amount',$credit_amount);
// 			$this->db->set('transaction_available_amount',$available_amount);
// 			$this->db->set('transaction_status',1);
// 			$this->db->insert('kh_wallet_transaction');

// 			$insertid=$this->db->insert_id();
// 			$transaction_number="KHAQWERTYUIO00".$insertid;
// 			$this->db->set('transaction_number',$transaction_number);
// 			$this->db->where('transaction_id',$insertid);
// 			$this->db->update('kh_wallet_transaction');
// 		}
	
		$this->db->select('*');
		$this->db->where('otp_number',$otpNum);
		$this->db->where('otp_mobile',$mobile);
		$this->db->order_by('otp_id','desc');
		$this->db->limit(1);
 
		$query = $this->db->get('kh_otp_num');
        return $query->num_rows();	
	}
		public function updateotp($mobile , $otpNum)
	{
		$this->db->set('otp_status',1);
		$this->db->where('otp_number',$otpNum);
		$this->db->where('otp_mobile',$mobile);
		$this->db->update('kh_otp_num');
	}
	public function getOtpForResend($mobile)
	{
	    $this->db->select('*');
		$this->db->where('otp_mobile',$mobile);
		$this->db->order_by('otp_id','desc');
		$this->db->limit(1);
		$query = $this->db->get('kh_otp_num');
        return $query->row();
	}
	public function getSiteLogin($user_email)
	{
		$this->db->where('user_email',$user_email);
		$this->db->where('user_status',1);
		$query1=$this->db->get('kh_user_list')->num_rows();

		$this->db->where('user_email',$user_email);
		$this->db->where('user_status',1);
		$query=$this->db->get('kh_user_list')->row();

		if ($query1 == 1) {
			return $query;
		}else{
			$this->db->where('user_mobile',$user_email);
			$this->db->where('user_status',1);
			return $query2=$this->db->get('kh_user_list')->row();

		}
	}
	 public function getUserDetailForProfile($userid)
	{
		$this->db->select('user_id,username,user_name,user_email,user_mobile,user_gender,user_state,user_city,user_zipcode,user_address,user_source,user_wallet_amount,ch_payment_status');
		$this->db->where('user_id',$userid);
		return $this->db->get('kh_user_list')->row();
	}
	public function updateUserProfile($user_id,$user_name, $user_email, $user_mobile, $address,$user_gender,$city,$state,$zipcode)
	{
			$date = date('Y-m-d h:i:s');
			$this->db->set("user_name",$user_name);
			$this->db->set("user_email",$user_email);
			$this->db->set("user_mobile",$user_mobile);		 
			$this->db->set("user_address",$address);
			$this->db->set("user_gender",$user_gender);
			$this->db->set("user_city",$city);
			$this->db->set("user_state",$state);
			$this->db->set("user_zipcode",$zipcode);
			$this->db->set("user_created",$date);
			$this->db->where("user_id",$user_id);
			$this->db->update("kh_user_list");
	} 
	public function changpass($user_id,$password)
	{
		$this->db->set("user_password",md5($password));
		$this->db->set("user_password_text",$password);
		$this->db->where("user_id",$user_id);
		$this->db->update("kh_user_list");		
	}
	public function getCatListForSiteall()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		// $this->db->where('category_parent_id',0);
		return $this->db->get('kh_category')->result();
	}
	public function getCategoryProductForcolumn($category_id,$limit,$page)
	{
		$this->db->select("p.*");
		$this->db->join("kh_category_products cp","cp.prod_id=p.product_id");
		$this->db->where("cp.cat_id",$category_id);
 		//$this->db->order_by('rand()');
 		$this->db->limit($limit,$page);
 		$this->db->where('product_status',1);
 		$this->db->where('stock_status',1);
 		
 		$this->db->order_by('product_id','desc');
		return $this->db->get("kh_product p")->result(); 
	}

	public function getAllproduct()
	{
		$this->db->select("*");
 		$this->db->where('product_status',1);
 		$this->db->where('stock_status',1);
 		$this->db->limit(12);
		// $this->db->limit($limit,$page);
		$this->db->order_by('product_id','desc');
        // $this->db->order_by('rand()');
		return $this->db->get("kh_product")->result(); 
	}

	public	function getChildProductForProductDetails($id)
	{
		$this->db->select('*');
		$this->db->where('product_id',$id);
		$this->db->where('stock_status',1);
		
		$this->db->or_where('parent_product',$id);
		$getResult = $this->db->get('kh_product');
        return $getResult->result(); 
	}
	public function getProductPhoto($id)
	{
		$this->db->select('*');
		$this->db->where('image_product_id',$id);
		$getResult = $this->db->get('kh_product_images');
		return $getResult->result(); 
	}
	public function getRelatedProduct($id)
	{
		$this->db->select('*');
		$this->db->where('prod_id',$id);
		$category_ids=$this->db->get('kh_category_products')->result();
		if(!empty($category_ids)){
		    foreach ($category_ids as $key => $ae) {
				$catid[]=$ae->cat_id;
			}
			$catids=array_unique($catid);
			$this->db->select('*');
			$this->db->where_in('cat_id',$catids);
			$productids=$this->db->get('kh_category_products')->result();
			if (!empty($productids)) {
				foreach ($productids as $key => $value) {
					$productid[]=$value->prod_id;
				}
				$product_id=array_unique($productid);
				$this->db->select('*');
				$this->db->where_in('product_id',$product_id);
				$this->db->order_by('rand()');
				// $this->db->limit(10);
				$this->db->where('stock_status',1);
				
				return $this->db->get('kh_product')->result();
			}else{
			    return false;
			}	
		}else{
		    return false;
		}
	}
	public function getNewProdict()
	{
		$this->db->select("*");
		$this->db->where("new_products",1);
 		$this->db->where('product_status',1);
 		$this->db->where('stock_status',1);
 		$this->db->order_by('rand()');
 		//$this->db->limit(10);
 		
		return  $this->db->get("kh_product")->result();
	}
	public function getDiscountedProdict()
	{
		$this->db->select("*");
		$this->db->where("discounted_products",1);
 		$this->db->order_by('rand()');
 		$this->db->where('product_status',1);
 		$this->db->where('stock_status',1);
 		//$this->db->limit(10);
 		
		return  $this->db->get("kh_product")->result();
	}
	public function getSalesProdict()
	{
		$this->db->select("*");
		$this->db->where("featured_status",1);
 		$this->db->where('product_status',1);
 		$this->db->where('stock_status',1);
 		$this->db->order_by('rand()');
 		//$this->db->limit(10);
 		
		return  $this->db->get("kh_product")->result();
	}
	public function getPriceBypinCode($product_id,$zipcode)
	{
		$this->db->select('*');
		$this->db->where('bra_zip',$zipcode);
		$query=$this->db->get('kh_branch')->row();
        if(!empty($query)){
		    $this->db->select('*');
		    $this->db->where('branch_id',$query->bra_id);
		    $this->db->where('product_id',$product_id);
		    return $this->db->get('kh_product_price_by_pincode')->row();
        }else{
			 return false;
		}
	}
	public function getProductBySearch($search)
	{
	
		$productName=$search;
		$q = $this->db->select('*')
		->from('kh_product')
		->where('stock_status',1)
		->where('product_status',1)
		->where("(product_name LIKE '%".$productName."%' OR product_tags LIKE '%".$productName."%' OR product_desc LIKE '%".$productName."%')", NULL, FALSE)
		->get()->result();
		return $q;

	}
	public function getSuggestions($search)
	{
        $productName=$search;
        $q = $this->db->select('*')
		->from('kh_product')
		->where('stock_status',1)
		->where('product_status',1)
		->where("(product_name LIKE '%".$productName."%' OR product_tags LIKE '%".$productName."%' OR product_desc LIKE '%".$productName."%')", NULL, FALSE)
		->get()->result();
		return $q;
	}
	public function getProductDetailbyid($id)
	{
		$this->db->select("*");
		$this->db->where("product_id",$id);
		return  $this->db->get("kh_product")->row();
	}
	
	public function getProductDetailbyidFororder($id)
	{
		$this->db->select("*");
		$this->db->where("product_id",$id);
		return  $this->db->get("kh_product")->row_array();
	}
	
	
   /////// User checkout address//////////////
	public function getsaveAddress_checkout($userId,$limit,$page)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userId);
		$this->db->limit($limit,$page);
		$this->db->where('status',2);
		return $this->db->get('kh_save_address')->result();
	}
  

  ///////profile User Addresss//////////////
	public function getSaveAddress($userId,$limit,$page)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userId);
		$this->db->limit($limit,$page);
		//$this->db->where('status',2);
		return $this->db->get('kh_save_address')->result();
	}
	public function updateEditaddress($firstname,$phone,$email,$state,$city,$address,$zipcode,$usergst,$usershop,$address_id)
	{
		$this->db->set('user_name',$firstname);
		$this->db->set('user_mobile',$phone);
		$this->db->set('user_email',$email);
		$this->db->set('user_state',$state);
		$this->db->set('user_city',$city);
		$this->db->set('user_address',$address);
		$this->db->set('pin_code',$zipcode);
		$this->db->set('user_gst',$usergst);
		$this->db->set('user_shop',$usershop);
		$this->db->where('id',$address_id);
		$this->db->update('kh_save_address');
	}
	public function adduseraddress($userid,$firstname,$phone,$email,$state,$city,$address,$zipcode,$usergst,$usershop)
	{
		$this->db->set('user_id',$userid);
		$this->db->set('user_name',$firstname);
		$this->db->set('user_mobile',$phone);
		$this->db->set('user_email',$email);
		$this->db->set('user_state',$state);
		$this->db->set('user_city',$city);
		$this->db->set('user_address',$address);
		$this->db->set('pin_code',$zipcode);
		$this->db->set('user_gst',$usergst);
		$this->db->set('user_shop',$usershop);
		$this->db->set('status',2);
		$this->db->insert('kh_save_address');
		return $this->db->insert_id();
	}
	public function getCouponInfo($couponCode)
	{
		$this->db->select('*');
		$this->db->where('coupon_code',$couponCode);
		$this->db->where('coupon_status',1);
		$this->db->where('coupon_valid_upto >=',date('Y-m-d 00:00:00'));
		$getResult = $this->db->get('kh_couponcode');
		return $getResult->row(); 
	}
	    
    
	public function getProductStatusforOutOfstork($id)
	{
		$this->db->select('*');
		$this->db->where('product_id',$id);
		return $this->db->get('kh_product')->row();
	}
	public function getCartList($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->where('cart_status',1);
		return $this->db->get('kh_cart')->result();
	}
	

	public function generateOrderNo()
	{
		$this->db->set('timestamp',time());	
		$this->db->insert('kh_order_number');	
		return $orderId = $this->db->insert_id();	
	}



	public function group_by($key, $data) {
    $result = array();

	    foreach($data as $val) {
	        if(array_key_exists($key, $val)){
	            $result[$val[$key]][] = $val;
	        }else{
	            $result[""][] = $val;
	        }
	    }

	    return $result;
	}

	public function insertorder($user_id,$delivery,$totalAmount,$firstname,$email,$phone,$state,$city,$address,$zipcode,$payment_type,$order_product,$gstnmber)


	{



		$orderCode = $this->generateOrderNo();
		$date = date("Y-m-d");
		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("order_unique_code",$orderCode);
		$this->db->set("order_userid",$user_id);
		$this->db->set("order_delivery",$delivery);
		$this->db->set("order_amount",$totalAmount);	
		$this->db->set("order_firstname",$firstname);
		$this->db->set("order_email",$email);
		$this->db->set("order_phone",$phone);
		$this->db->set("order_state",$state);
		$this->db->set("order_city",$city);
		$this->db->set("order_address",$address);
		$this->db->set("order_zipcode",$zipcode);
		$this->db->set("payment_type",$payment_type);
		$this->db->set("gstnmber",$gstnmber);


	  $this->db->set("order_created",$todayDate);
		$this->db->set("order_status",1);
		$this->db->set("order_type",1);
		$this->db->set("order_created_by",1);
		$this->db->insert("kh_order_tb");
		$orderId = $this->db->insert_id();
	
		// print_r($order_product); die;
		foreach($order_product as $pd){

			$productdata=$this->db->select('*')->where('product_id',$pd['product_id'])->get('kh_product')->row();
			$this->db->set("order_id",$orderId);
			$this->db->set("user_id",$user_id);
			$this->db->set("product_id",$pd['product_id']);
			$this->db->set("one_price",$productdata->product_price);
			$this->db->set("qty",$pd['quantity']);
			$this->db->set("code",$productdata->product_code);
			$this->db->set("hsncode",$productdata->hsncode);
			$this->db->set('gstslab',$productdata->slab);
			$this->db->set("name",$productdata->product_name);
			$this->db->set("price",$productdata->product_price * $pd['quantity']);
			$this->db->set("product_purchase_price",$productdata->kh_purchase_price);
			$this->db->set("status",1);
			$this->db->set("created",$todayDate);
			$this->db->insert("kh_order_items");
		}	

		return $orderId;
	}


	public function insertorder_old($user_id,$delivery,$totalAmount,$walletAmount,$coupon_code,$discountCouponAmount,$firstname,$email,$phone,$state,$city,$address,$zipcode,$payment_type,$slot_id,$order_product)
	{
		$date = date("Y-m-d");
		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("order_userid",$user_id);
		$this->db->set("order_delivery",$delivery);
		$this->db->set("order_amount",$totalAmount);		
		$this->db->set("order_wallet_amount",$walletAmount);
		$this->db->set("order_applied_coupon",$coupon_code);
		$this->db->set("order_discount_amount",$discountCouponAmount);
		$this->db->set("order_firstname",$firstname);
		$this->db->set("order_email",$email);
		$this->db->set("order_phone",$phone);
		$this->db->set("order_state",$state);
		$this->db->set("order_city",$city);
		$this->db->set("order_address",$address);
		$this->db->set("order_zipcode",$zipcode);
		$this->db->set("order_payment_status",0);
		$this->db->set("payment_type",$payment_type); // 1 Cod | 2 Online
	  $this->db->set("order_created",$todayDate);
		$this->db->set("order_status",1);
		$this->db->set("slot_id",$slot_id);
		$this->db->set("order_type",1);
		$this->db->set("order_from",'App');
		$this->db->insert("kh_order_checkout_tb");
		$ordercheckoutid = $this->db->insert_id();

		$checkoutidunique="ORD".$ordercheckoutid;
		$this->db->set("order_unique_code",$checkoutidunique);
		$this->db->where("order_id",$ordercheckoutid);
		$this->db->update("kh_order_checkout_tb");



		$cartItem=$order_product;
		//print_r($cartItem); die;
		foreach($cartItem as $rates){
			$productdata=$this->db->select('*')->where('product_id',$rates['product_id'])->get('kh_product')->row();
			$product[]=array("id" => $rates['product_id'],
                  			 "price" => $rates['product_price'],
                  			 "qty" => $rates['quantity'],
                  			 "name" => $rates['product_name'],
                  			 "subtotal" => $rates['product_price'] * $rates['quantity'],
                  			 "vendor_id" => $productdata->vendor_id);
		}
		$byGroup = $this->group_by("vendor_id", $product);
		//echo "<pre>" . var_export($byGroup, true) . "</pre>"; die();



		foreach ($byGroup as $key => $grouporder) {
			$TotalCartPrices=0;
			foreach($grouporder as $pds){
				$TotalCartPrices +=$pds['subtotal'];
			}
			//print_r($grouporder[0]['vendor_id']); die();
			$orderCode = $this->generateOrderNo();
			$date = date("Y-m-d");
			$todayDate = date("Y-m-d h:i:s");
			$this->db->set("checkout_id",$ordercheckoutid);
			$this->db->set("order_unique_code",$orderCode);
			$this->db->set("order_userid",$user_id);
			$this->db->set("order_delivery",$delivery);
			$this->db->set("order_amount",$TotalCartPrices);		
			$this->db->set("order_firstname",$firstname);
			$this->db->set("order_email",$email);
			$this->db->set("order_phone",$phone);
			$this->db->set("order_state",$state);
			$this->db->set("order_city",$city);
			$this->db->set("slot_id",$slot_id);
			$this->db->set("order_address",$address);
			$this->db->set("order_zipcode",$zipcode);
		    $this->db->set("order_created",$todayDate);
		    $this->db->set("payment_type",$payment_type); // 1 Cod | 2 Online
		    $this->db->set("vendor_id",$grouporder[0]['vendor_id']);
			$this->db->set("order_status",1);
			$this->db->set("order_from",'App');
			$this->db->set("order_type",1);
			$this->db->insert("kh_order_tb");
			$orderId = $this->db->insert_id();
		

			foreach($grouporder as $pd){
				$this->db->set("order_id",$orderId);
				$this->db->set("user_id",$user_id);
				$this->db->set("product_id",$pd['id']);
				$this->db->set("one_price",$pd['price']);
				$this->db->set("qty",$pd['qty']);
				$productdata=$this->db->select('*')->where('product_id',$pd['id'])->get('kh_product')->row();
				$this->db->set("code",$productdata->product_code);
				$this->db->set("name",$pd['name']);
				$this->db->set("price",$pd['subtotal']);
				$this->db->set("vendor_id",$pd['vendor_id']);
				$this->db->set("product_purchase_price",$productdata->kh_purchase_price);
				$this->db->set("status",1);
				$this->db->set("created",$todayDate);
				$this->db->insert("kh_order_items");
			}		
		}
		return $ordercheckoutid;
	}
	public function getOrderItemForOrderList($user_id,$orderid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$user_id);
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}
		public function getOrderData($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_tb")->row();
	}
	public function getOrderItem($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}

	public function getOrderItemFromCheckout($orderid)
	{
		$this->db->select('*');
		$this->db->where_in('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}  
	public function orderDatas($user_id,$limit,$page)
	{
		$this->db->select('*');
		$this->db->where('order_userid',$user_id);
		$this->db->order_by('order_id','desc');
		$this->db->limit($limit,$page);
		$query=$this->db->get('kh_order_tb');
		return $query->result();
	}
	public function getOrderItemForProductList($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}
	
	public function getDiscountOffers()
	{
		$this->db->select('*');
		$this->db->where('coupon_valid_upto >=',date('Y-m-d'));
		return $this->db->get('kh_couponcode')->result();
	}
	public function getNotificationData($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->where('status',1);
		$this->db->order_by('id','desc');
		return $this->db->get('kh_notification')->result();
	}
	
	public function amount_transaction($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->limit(10);
		$this->db->order_by('transaction_id','desc');
		return $this->db->get('kh_wallet_transaction')->result();
	}
	public function getmembershipPack()
	{
		$this->db->select('*');
		$this->db->where('pack_status',1);
		$getResult = $this->db->get('kh_membership_pack');
        return $getResult->result(); 
	}
	public function getSiteSetting()
	{
		$this->db->select('*');
		$this->db->where('setting_id',1);
		$getResult = $this->db->get('kh_site_setting');
		return $getResult->row(); 
	}	
	public function getMemberShipStatus($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->where('payment_status',1);
		$this->db->where('membership_exp',1);
		return $this->db->get("kh_purchase_membership")->row();
	}
	public function purchasemembership($pack_id,$user_id)
	{
		$this->db->select('*');
		$this->db->where('pack_id',$pack_id);
		$getResult = $this->db->get('kh_membership_pack')->row(); 

		$expinmonths="+".$getResult->pack_time_duration."month";
		$expdate = date('Y-m-d',  strtotime($expinmonths));

		$data = array(
			'user_id' => $user_id, 
			'pack_name' => $getResult->pack_name, 
			'pack_price' => $getResult->pack_price, 
			'pack_time_duration' => $getResult->pack_time_duration, 
			'pack_desc' => $getResult->pack_desc, 
			'membership_exp' => 0,
			'purchase_data' => $time=date("Y-m-d"),
			'expiry_date' => $expdate,
			'payment_status' => 0, 
			'super_pack' =>  $getResult->super_pack
		);
		$this->db->insert('kh_purchase_membership',$data);
		$insertid=$this->db->insert_id();

		$membership_id="MEMBER".$insertid;

		$this->db->set('membership_id',$membership_id);
		$this->db->where('purchase_id',$insertid);
		$this->db->update('kh_purchase_membership');

		return $insertid;
	}
	public function getUserDataForMembership($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		return $this->db->get("kh_user_list")->row();
	}
	
	public function getAppHomePage($image_section_type)
	{
		$this->db->select('*');
	
		$this->db->where('image_section_type',$image_section_type);
		$this->db->order_by('image_id','desc');
		$getdata=$this->db->get("kh_app_home_images")->result();
		if(!empty($getdata)){
		   return  $getdata;
		}else{
		    return false;
		}
	}



    public function forgetPasswordEmail($email)
	{
	    $this->db->select('*');
        $this->db->where('user_email',$email);
		$this->db->where('user_status',1);
		$query1=$this->db->get('kh_user_list')->num_rows();

		$this->db->where('user_email',$email);
		$this->db->where('user_status',1);
		$query=$this->db->get('kh_user_list')->row();

		if ($query1 == 1) {
			return $query;
		}else{
			$this->db->where('user_mobile',$email);
			$this->db->where('user_status',1);
			return $query2=$this->db->get('kh_user_list')->row();

		}
	}
	
	public function getsubCatListForSiteall($id)
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->where('category_parent_id',$id);
		return $this->db->get('kh_category')->result();
	}
	public function getSetting()
	{
		$this->db->select("*");
		$this->db->where("setting_id",1);
		return $this->db->get("kh_site_setting")->row();
	}
	public function getTimeSlotForBooking()
	{
	    $this->db->select('*');
	    $this->db->where('status',1);
	    return $this->db->get('kh_time_slot')->result();
	}
	public function getAbalableDeliverySlot($id)
	{
		$date1 = date('Y-m-d 01:00:00', strtotime(date('Y-m-d h:i:s')));
		$date2 = date('Y-m-d 24:00:00', strtotime(date('Y-m-d h:i:s')));
 	  $date3 = date('Y-m-d h:i:s', strtotime($date1));
 		$date4 = date('Y-m-d h:i:s', strtotime($date2));

		$this->db->select('*');
		$this->db->where('order_created >',$date3);
		$this->db->where('order_created <',$date4);
		$this->db->where('slot_id',$id);
		$this->db->where("order_status !=",0);
		$this->db->where("order_status !=",6);
		$getResult = $this->db->get('kh_order_tb');
		
        return $getResult->num_rows(); 
	}

	public function getsave_More_address_chk_biling($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		$this->db->where('status',2);
		return $this->db->get('kh_save_address')->result();
	}
	public function displaysingle_address($addressid)
	{	
		$this->db->select('*');
	    $this->db->where('id',$addressid);
		$this->db->where('status',1);
		return $this->db->get('kh_save_address')->row();
		  
	}

}