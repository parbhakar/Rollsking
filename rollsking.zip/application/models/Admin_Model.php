<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Model extends CI_Model{
	public function index()
	{
		
	}
	public function urlMaker($string)
	{
	    $string = utf8_encode($string);
		//$string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);   
		$string = preg_replace('/[^a-z0-9- ]/i', '', $string);
		$string = str_replace(' ', '-', $string);
		$string = trim($string, '-');
		$string = strtolower($string);
		if (empty($string)) {
		return 'n-a';
		}
		return $string.".html";
	}
	public function getAdminDetail()
	{
		$this->db->select('*');
		$this->db->where('email',$this->input->post('email'));
		$this->db->where('status',1);
		$query=$this->db->get('kh_admin');
		return $query->row();
	}
	
	
	///////////////////////////////Menu/////////////////////////////////
	public function get_all_menus()
	{
		$this->db->order_by('position','asc');
		$query=$this->db->get('kh_menu');
		if($query->num_rows() > 0){
		return $query->result();
		}
	}
	public function add_menu()
	{
		$menu_insert=array(
			'menu_name'=>$this->input->post('menu_name'),
			'parent_id'=>$this->input->post('parent_menu'),
			'position'=>$this->input->post('position'),
			'menu_link'=>$this->input->post('link')
		);
		$this->db->insert('kh_menu',$menu_insert);
		
		
	}
	public function get_all_role()
	{
		$query=$this->db->get("kh_user_types");
		if ($query->num_rows()>0){
			return $query->result();
		}else{
			return FALSE;
		}
	}
	function get_menu_byid($menuid)
	{
		$query=$this->db->get_where('kh_menu',array('menu_id'=>$menuid));
		if($query->num_rows()>0){
			 return $query->result();
		}
	}

	function edit_menu()
	{
		$menu_id=$this->input->post('menu_id');
		
		$data=array(
			'menu_name'=>$this->input->post('menu_name'),
			'menu_link'=>$this->input->post('menu_link'),
			'position'=>$this->input->post('position'),
			'parent_id'=>$this->input->post('parent_menu')			
			);
		
	    $this->db->update('kh_menu',$data,array('menu_id'=>$menu_id));
	    
           
            if($this->db->affected_rows()>=0){
			    echo "<script>alert('menu Upadated Successfully');</script>";
			    echo"<script>window.location.href='".base_url()."Admin/menu_management'</script>";
		    }else{
			    echo "<script>alert('Menu Upadation Failed');</script>";
			    echo"<script>window.location.href='".base_url()."Admin/menu_management'</script>";
		    }
	    }

	
	function delete_menu()
	{
		$menu_id=$this->input->post("menuId");
		$result=$this->db->delete("kh_menu", array('menu_id'=>$menu_id));
		if($result){
			
				return TRUE;
			}else{
				return FALSE;
			}
		}
	
	//////////////////////////////////End Menu///////////////////////////////


		////////////////////////Emp User //////////////////////////////////////

	public function show_user_list()
	{
		$session_data=$this->session->userdata('login-in');
		if ($session_data['user_type'] ==1) {
			$query=$this->db->query("select u.*,ut.user_name from kh_admin u left outer join kh_user_types ut on u.user_type=ut.id where u.user_type NOT IN(1) ");
			if($query->num_rows()>0){
              return $query->result();
			}
		} else {
			$query=$this->db->query("select u.*,ut.user_name from kh_admin u left outer join kh_user_types ut on u.user_type=ut.id where u.user_type NOT IN(1) And  u.user_type NOT IN(2)");
			if($query->num_rows()>0){
              return $query->result();
			}
		}
		
		
			
				
	}

	public function get_all_customer()
	{
		$query=$this->db->query("select * from kh_admin where user_type=3");
		if($query->num_rows()>0){
              return $query->result();
			}

	}
	public function get_all_supplier()
	{
		$query=$this->db->query("select * from kh_admin where user_type=2");
		if($query->num_rows()>0){
              return $query->result();
			}
	}

	public function show_add_user()
	{	
		$session_data=$this->session->userdata('login-in');
		$logged_user_type=$session_data['user_type'];
		if($logged_user_type==2){
			$query=$this->db->query("select * from kh_user_types where id!=1 and id!=3 and id!=2");
		}else{
			$query=$this->db->query("select * from kh_user_types where id!=1 and id!=3");
		}
		if($query->num_rows()>0){
			return $query->result();
		}
	}

	public function add_user()
	{
		$first_name=trim($this->input->post('first_name'));
		$last_name=trim($this->input->post('last_name'));
		$email=trim($this->input->post('email'));
		$user_type=$this->input->post("user_type");
		$phone=trim($this->input->post('phone'));
		$gender=$this->input->post('gender');
		if($gender=="male"){$gender=1;}else{$gender=2;}
		$address=trim($this->input->post('address'));
		$dob=$this->input->post('dob');
		$dateofb=date("Y-m-d", strtotime($dob));
		$city=$this->input->post('city');
		$password1=trim($this->input->post('password'));

		$category_type=$this->input->post('category_type');

		//$password1=mt_rand(100000,999999);
		$password=md5($password1);
		$created_at=date("Y-m-d h:i:sa");
		$modified_at=date("Y-m-d h:i:sa");

		$data=array(
			'first_name'=>$first_name,
			'last_name'=>$last_name,
			'email'=>$email,
			'user_type'=>$user_type,
			'phone'=>$phone,
			'gender'=>$gender,
			'address'=>$address,
			'dob'=>$dateofb,
			'city'=>$city,
			'password'=>$password,
			'text_password' => $password1,
			'copyright'=>"Rollsking",
			'copyright_url'=>"#",
			'logo_name_url'=>"Rollsking",			
			'status'=>1,
			'category_type' => $category_type,
			'created_at'=>$created_at,
			'modified_at'=>$modified_at
		);
		$check=$this->db->query('select * from kh_admin where email="'.$email.'"');
		if($check->num_rows()==0){
				$this->db->insert('kh_admin',$data);
				if($this->db->insert_id()>0){
		                echo '<script>alert("User Added Successfully");</script>';
		                echo "<script>window.location='".base_url()."Admin/show_user_list';</script>";					
				}else{
					echo '<script>alert("User Registeration Failed");</script>';
					echo "<script>window.loaction='".base_url()."Admin/show_add_user';</script>";
				}
		}else{
			echo '<script>alert("User already exists");</script>';
			echo  "<script>window.location='".base_url()."Admin/show_add_user'</script>";
		}				

	}

	
	public function add_sub_users(){
    		$created_at = date('Y-m-d H:i:sa');
    		$password1 = $this->input->post('password');
		 
		 
			$this->db->set('user_name',$this->input->post('first_name'). " " .$this->input->post('last_name'));
			$this->db->set('user_email',$this->input->post('email'));
			$this->db->set('user_mobile',$this->input->post('phone'));
			$this->db->set('user_outlet',$this->input->post('outletname'));
			$this->db->set('user_gst',$this->input->post('gstnumber'));
			$this->db->set('user_password',md5($password1));
			$this->db->set('user_password_text',$password1);
			$this->db->set('user_city',$this->input->post('city'));
			$this->db->set('user_status',1);
			$this->db->set('user_created',$created_at);

		    $check=$this->db->query('SELECT * FROM kh_user_list Where user_email="'.$this->input->post('email').'"');

			if($check->num_rows()==0){
					$this->db->insert('kh_user_list');
					if($this->db->insert_id()>0){
					        $username="ROK00".$this->db->insert_id();
                			$this->db->set('username',$username);
                			$this->db->where('user_id',$this->db->insert_id());
                			$this->db->update("kh_user_list");
					    
			                echo '<script>alert("Sub User Added Successfully");</script>';
			                echo "<script>window.location='".base_url()."Admin/userlist';</script>";					
					}else{
						echo '<script>alert("Sub User Registeration Failed");</script>';
						echo "<script>window.loaction='".base_url()."Admin/show_add_sub_users';</script>";
					}
			}else{
				echo '<script>alert("Sub User already exists");</script>';
				echo  "<script>window.location='".base_url()."Admin/show_add_sub_users'</script>";
			}	
			//$this->db->insert('kh_user_list1');
		 
		
	}
    public function show_edit_user($user_id)
    {
    	$query=$this->db->get_where("kh_admin",array('id'=>$user_id));
		if($query->num_rows()>0){
			return $query->row();
		}
    }

    public function get_user_type()
    {
    	$query=$this->db->query("select * from kh_user_types where id!=1");
    	if($query->num_rows()>0){
    		return $query->result();
    	}
    }

    public function get_user_type_new()
    {
    	$query=$this->db->query("select * from kh_user_types where id!=1");
    	if($query->num_rows()>0){
    		return $query->result();
    	}
    }

    public function edit_user()
    {
    	$user_id=$this->input->post('user_id');
		$first_name=trim($this->input->post('first_name'));
		$last_name=trim($this->input->post('last_name'));
		$email=trim($this->input->post('email'));
		$user_type=$this->input->post('user_type');

		$phone=trim($this->input->post('phone'));
		$gender=$this->input->post('gender');
		if($gender=="male"){$gender=1;}else{$gender=2;}
		$address=trim($this->input->post('address'));
		$category_type=$this->input->post('category_type');

		$data=array(
			'first_name'=>$first_name,
			'last_name'=>$last_name,
			'user_type'=>$user_type,
			'email'=>$email,
			'phone'=>$phone,
			'gender'=>$gender,
			'address'=>$address,
			'category_type' => $category_type
		);		

		$this->db->update('kh_admin',$data,array('id'=>$user_id));
		if($this->db->affected_rows()>0){
			echo '<script>alert("User details updated successfully");</script>';
			echo "<script>window.location='".base_url()."Admin/show_user_list'</script>";
		}else{
			echo '<script>alert("No modification made");</script>';
			echo "<script>window.location='".base_url()."Admin/show_edit_user/".$user_id."'</script>";
		}
    }

    public function deleteUser()
    {
    	$UserId=$this->input->post('UserId');
    	$result=$this->db->delete('kh_admin',array('id'=>$UserId));
    	if($result){
    		return true;
    	}else{
    		return false;
    	}
    }

    public function DeactivateUser()
    {
    	$UserId=$this->input->post('UserId');
    	$data=array('status'=>0);
    	$result=$this->db->update('kh_admin',$data,array('id'=>$UserId));
    	if($result){
    		return true;
    	}else{
    		return false;
    	}
    }

    public function ActivateUser()
    {
    	$UserId=$this->input->post('UserId');
    	$data=array('status'=>1);
    	$result=$this->db->update('kh_admin',$data,array('id'=>$UserId));
    	if($result){
    		return true;
    	}else{
    		return false;
    	}
    }

    public function get_all_staff_member(){
    	$query=$this->db->query("select u.*,ut.user_name,role.role_id,staff.role_name
		from kh_admin u 
		left outer join kh_user_types ut on u.user_type=ut.id
		left outer join mvs_assigned_role role on u.id=role.member_id
		left outer join mvs_staff_role staff on role.role_id=staff.id
	    where u.user_type =2 ");
			if($query->num_rows()>0){
              return $query->result();
			}

    }


		///////////////////////End Emp User/////////////////////////////////////


    ////////////////////////////////Group /////////////////////////////////////////


    public function get_menu_for_permission()
	{
		$this->db->order_by("position", "asc");
		$query=$this->db->get("kh_menu");
		if($query->num_rows()>0){
			return $query->result();
		}

	}

	public function add_employee_group()
	{
		$created_at=date("Y-m-d h:i:sa");
		$modified_at=date("Y-m-d h:i:sa");
		$employee_group_name=$this->input->post('employee_group');
		$employee_group_permission_menu[]=$this->input->post('menu_id');
		// print_r($employee_group_permission_menu); die();
		$data=array(
			'user_name'=>$employee_group_name,
			'status'=>1,
			'created_at'=>date("Y-m-d h:i:sa"),
			'modified_at'=>date("Y-m-d h:i:sa")
		);
		$this->db->insert("kh_user_types",$data);
		if($this->db->insert_id()>0){
				//$user_group_id=$this->db->insert_id();
				

				//$total_sub_menu=count($employee_group_permission_menu);
				for($i=0;$i<count($employee_group_permission_menu[0]);$i++){

					$role_id=$user_group_id;
					$menu_id=$employee_group_permission_menu[0][$i];
					$created_at=date("Y-m-d h:i:sa");
					$modified_at=date("Y-m-d h:i:sa");

					$data1=array(
						'user_type_id'=>$role_id,
						'menu_id'=>$menu_id,
						'status'=>1,
						'created_at'=>$created_at,
						'updated_at'=>$modified_at
					);
					$this->db->insert("kh_role_menu",$data1);

					
				}
				echo '<script>alert("Group inserted Successfully");</script>';
				echo "<script>window.location.href='".base_url()."Admin/show_add_employee_group_page';</script>";
		}else{
				echo '<script>alert("Group insertion Failed");</script>';
				echo "<script>window.location.href='".base_url()."Admin/show_add_employee_group_page';</script>";
		}

	}

	public function get_all_employee_group()
	{
		$query=$this->db->query("select * from kh_user_types where id!=1");
		if($query->num_rows()>0){
			return $query->result();
		}
	}

	public function get_all_employee_department()
	{
		$query=$this->db->query("select * from b2b_department");
		if($query->num_rows()>0){
			return $query->result();
		}
	}

	public function get_employee_group_specific($employee_group_id)
	{
		$query=$this->db->get_where('kh_user_types',array('id'=>$employee_group_id));
		if($employee_group_id){
			return $query->row();
		}
	}

	public function get_assigned_menu_of_group($employee_group_id)
	{
		// echo $employee_group_id; die();
		$query=$this->db->get_where('kh_role_menu',array('user_type_id'=>$employee_group_id));
			 // print_r($query->result()); die();
		
		if($query->num_rows()>0){
			 // print_r($query->result()); die();
			return $query->result();
		}
	}

	public function edit_employee_group()
	{

		//print_r($_POST);die();
		$employee_group_name=$this->input->post('employee_group');
		$employee_group_id=$this->input->post('employee_group_id');
		$employee_group_permission_menu[]=$this->input->post('menu');

		$data=array(
			'user_name'=>$employee_group_name,
			'status'=>1,
			'modified_at'=>date("Y-m-d h:i:sa")
		);
		$this->db->update("kh_user_types",$data,array('id'=>$employee_group_id));
		if($this->db->affected_rows()>0){
				$query=$this->db->get_where("kh_role_menu",array('user_type_id'=>$employee_group_id));
				if($query->num_rows()>0){
					$this->db->delete("kh_role_menu",array('user_type_id'=>$employee_group_id));
				}

				for($i=0;$i<count($employee_group_permission_menu[0]);$i++){

					$role_id=$employee_group_id;
					$menu_id=$employee_group_permission_menu[0][$i];
					$created_at=date("Y-m-d h:i:sa");
					$modified_at=date("Y-m-d h:i:sa");

					$data1=array(
						'user_type_id'=>$role_id,
						'menu_id'=>$menu_id,
						'status'=>1,
						'created_at'=>$created_at,
						'updated_at'=>$modified_at
					);
					$this->db->insert("kh_role_menu",$data1);
				}
				echo '<script>alert("Group updated Successfully");</script>';
				echo "<script>window.location.href='".base_url()."Admin/show_manage_employee_group';</script>";
		}else{
				echo '<script>alert("Group updation Failed");</script>';
				echo "<script>window.location.href='".base_url()."Admin/show_manage_employee_group';</script>";
		}
	}

	public function DeactivateEmployeeGroup()
	{
		$groupID=$this->input->post('employeegroupid');
    	$data=array('status'=>0);
    	$result=$this->db->update('kh_user_types',$data,array('id'=>$groupID));
    	if($result){
    		return true;
    	}else{
    		return false;
    	}
	}

	public function ActivateEmployeeGroup()
	{
		$groupID=$this->input->post('employeegroupid');
    	$data=array('status'=>1);
    	$result=$this->db->update('kh_user_types',$data,array('id'=>$groupID));
    	if($result){
    		return true;
    	}else{
    		return false;
    	}
	}

	


	public function show_employee_page()
	{
		$sess_data=$this->session->userdata("admin_logged_in");
		$parent_role_id=$sess_data["user_type"];
		$query1=$this->db->query("select child_role_id from b2b_assign_users where parent_role_id='".$parent_role_id."' ");
		$arr=$query1->result_array();
		$newarray=array();
		$i=0;
		foreach($arr as $newarr){	
			foreach ($newarr as $key => $value) {
				$newarray[$i]=$value;
				$i++;
			}					
		}				
		$matches=implode(',',$newarray); 		
		if($matches){
			$query=$this->db->query("select u.*,e.*,ut.user_name from b2b_users u inner join b2b_employee e on u.employee_id=e.id left outer join kh_user_types ut on u.user_type=ut.id where  ut.id IN ( ".$matches." ) ");			
			if($query->num_rows()>0){				
				return $query->result();
			}
		}else{
			return "";
		}
	}

	

	public function DeleteEmployee()
	{
		$employee_id=$this->input->post("GroupId");
		$result=$this->db->delete("kh_user_types",array('id'=>$employee_id));
		if($result){
			
				return TRUE;
			}
			else{
				return FALSE;
			}
		
	}

	//////////////////////////// Function to assign Groups to another Group /////////////////////////////
	public function assign_user()
	{
		$parent_role_id=$this->input->post("parent_role_id");	
			$query1=$this->db->get_where('kh_user_types',array('id'=>$parent_role_id));
			$result1=$query1->row();
		$parent_role_name=$result1->user_name;			
		$child_role_id[]=$this->input->post("child_role_id");		
		
		$query=$this->db->get_where('b2b_assign_users',array('parent_role_id'=>$parent_role_id));
		if($query->num_rows()>0){
			$this->db->delete('b2b_assign_users',array('parent_role_id'=>$parent_role_id));
		}

		$length=count($child_role_id[0]);		
		for($i=0 ;$i<$length ;$i++){

			$query2=$this->db->get_where('kh_user_types',array('id'=>$child_role_id[0][$i]));
			$result2=$query2->row();
			$child_role_name=$result2->user_name;

			$data=array(
				'parent_role_id'=>$parent_role_id,
				'parent_role_name'=>$parent_role_name,
				'child_role_id'=>$child_role_id[0][$i],
				'child_role_name'=>$child_role_name,
				'status'=>1,
				'created_at'=>date("Y-m-d h:i:sa"),
				'updated_at'=>date("Y-m-d h:i:sa")
			);
			$this->db->insert('b2b_assign_users',$data);			
		}
			echo "<script>alert('Group Assigned to  $parent_role_name Group');</script>";
			echo "<script>window.location.href='".base_url()."Admin/show_assign_user';</script>";	
	}

	public function get_assigned_user_group()
	{
		$query=$this->db->get('b2b_assign_users');
		if($query->num_rows()>0){
			return $query->result();
		}
	}

	public function get_assigned_group_by_id()
	{
		$parent_role_id=$this->input->post('parent_role_id');
		// echo $parent_role_id;
		$query=$this->db->get_where('b2b_assign_users',array('parent_role_id'=>$parent_role_id));
		if($query->num_rows()>0){
			 return $query->result();
		}
	}

	/////////////////////////////////////////End Group////////////////////////////////////
    ///////////////////Change password//////////////////////////
    public function changpass()
	{
		$admin_session=$this->session->userdata('login-in'); 
		$this->db->set("password",md5($this->input->post("pass")));
		$this->db->set("text_password",$this->input->post("pass"));
		$this->db->where("id",$admin_session['id']);
		$this->db->update("kh_admin");		
	}
    ////////////////////End Change Password ////////////////////


    ///////////////////////Forget Password///////////////////////
	public function forgetPasswordEmail()
	{
	    $this->db->select('*');
		$this->db->where('email',$this->input->post('email'));
		$query = $this->db->get('kh_admin');
        return $query->row();
	}

    ///////////////////End Forget Password///////////////////////

	///////////////////////////////////////ALL Lab Code//////////////////////////////
	public function getCatName($cat_id)
	{
		$this->db->select("*");
		$this->db->where("category_id",$cat_id);
		$query = $this->db->get('kh_category');
		return $query->row();
	}

	public function countgetAllUserRegistered()
	{
		$search=$this->input->get('email');
		$name=$this->input->get('name');
		$this->db->select('*');
		if($search != null){
		    $this->db->like('user_email',$search);
		}
		if($name != null){
		    $this->db->like('user_name',$name);
		}
		$this->db->order_by('user_id','desc');
		$getResult = $this->db->get('kh_user_list');
        return $getResult->num_rows(); 
	}
	public function getAllUserRegistered($limit,$page)
	{
		$search=$this->input->get('email');
		$name=$this->input->get('name');
		$this->db->select('*');
		if($search != null){
		    $this->db->like('user_email',$search);
		}
		if($name != null){
		    $this->db->like('user_name',$name);
		}
		$this->db->limit($limit,$page);
		$this->db->order_by('user_id','desc');
		$getResult = $this->db->get('kh_user_list');
        return $getResult->result(); 
	}
	
	
	
	public function amount_transaction($userid)
	{
		$this->db->select('*');
		$this->db->where('user_id',$userid);
		$this->db->order_by('transaction_id','desc');
		return $this->db->get('kh_wallet_transaction')->result();
	}
	public function getAllUserRefferUser($refer_id)
	{
		$this->db->select('ref.*,user.*');
		$this->db->where('ref.refer_id',$refer_id);
		$this->db->join('kh_user_list user','user.user_id=ref.user_id');
		$getResult = $this->db->get('kh_referral ref');
        return $getResult->result(); 
	}
	public function getAllCompany()
	{
		return $this->db->select('*')->where('company_status !=',3)->get('kh_company')->result();
	}
	public function addCompany($logoName)
	{
		$data=array(
			'company_name'			=> $this->input->post('company_name'),
			'company_cin' 			=> $this->input->post('company_cin'),
			'company_regis_no'		=> $this->input->post('company_regis_no'),
			'company_gst_no' 		=> $this->input->post('company_gst_no'),
			'company_phone' 		=> $this->input->post('company_phone'),
			'company_email' 		=> $this->input->post('company_email'),
			'company_address' 		=> $this->input->post('company_address'),
			'company_state' 		=> $this->input->post('company_state'),
			'company_city' 			=> $this->input->post('company_city'),
			'company_zip' 			=> $this->input->post('company_zip'),
			'company_logo' 			=> $logoName,
			'company_status	' 		=> 1
			 );
		$this->db->insert('kh_company',$data);
	}
	public function getCompanyForEdit($id)
	{
		return $this->db->select('*')->where('company_id',$id)->get('kh_company')->row();
	}
	public function updateCompany($logoName=null)
	{
	
		$this->db->set('company_name',$this->input->post('company_name'));
		$this->db->set('company_cin',$this->input->post('company_cin'));
		$this->db->set('company_regis_no',$this->input->post('company_regis_no'));
		$this->db->set('company_gst_no',$this->input->post('company_gst_no'));
		$this->db->set('company_phone',$this->input->post('company_phone'));
		$this->db->set('company_email',$this->input->post('company_email'));
		$this->db->set('company_address',$this->input->post('company_address'));
		$this->db->set('company_state',$this->input->post('company_state'));
		$this->db->set('company_city',$this->input->post('company_city'));
		$this->db->set('company_zip',$this->input->post('company_zip'));
		$this->db->set('company_status',1);
		if ($logoName !=NULL) {
			$this->db->set('company_logo',$logoName);
		}
		$this->db->where('company_id',$this->input->post('company_id'));
		$this->db->update('kh_company');
	}
	public function getLabs()
	{
		$this->db->select('*');
		$companyid=$this->input->get('companyid');
		if($companyid !=0){
			$this->db->where('bra_company_id',$companyid);
		}
		$this->db->where('bra_status !=',3);
		return $this->db->get('kh_branch')->result();
	}
	public function getLabData($bra_id)
	{
		$this->db->select('*');
		$this->db->where('bra_id',$bra_id);
		return $this->db->get('kh_branch')->row();
	}
	public function getEditTestInLab($companyid,$bra_id,$testid)
	{
		$this->db->select('*');
		$this->db->where('kh_company_id',$companyid);
		$this->db->where('kh_bra_id',$bra_id);
		$this->db->where('kh_test_id',$testid);
		return $this->db->get('kh_bra_test')->row();
	}
	public function getCompanyDataForlab($id)
	{
		return $this->db->select('*')->where('company_id',$id)->get('kh_company')->row();
	}
	public function getCompanyForLab()
	{
		return $this->db->select('*')->where('company_status',1)->get('kh_company')->result();
	}
	public function addBranch()
	{
		$this->db->set('bra_company_id',$this->input->post('bra_company_id'));
		$this->db->set('bra_name',$this->input->post('bra_name'));
		$this->db->set('bra_address',$this->input->post('bra_address'));
		$this->db->set('bra_state',$this->input->post('company_state'));
		$this->db->set('bra_city',$this->input->post('company_city'));
		$this->db->set('bra_zip',$this->input->post('bra_zip'));
		$this->db->set('bra_lat',$this->input->post('bra_lat'));
		$this->db->set('bra_long',$this->input->post('bra_long'));
		$this->db->set('bra_status',1);
		$this->db->insert('kh_branch');
	}
	public function editBranch()
	{
		$this->db->set('bra_company_id',$this->input->post('bra_company_id'));
		$this->db->set('bra_name',$this->input->post('bra_name'));
		$this->db->set('bra_address',$this->input->post('bra_address'));
		$this->db->set('bra_state',$this->input->post('company_state'));
		$this->db->set('bra_city',$this->input->post('company_city'));
		$this->db->set('bra_zip',$this->input->post('bra_zip'));
		$this->db->set('bra_lat',$this->input->post('bra_lat'));
		$this->db->set('bra_long',$this->input->post('bra_long'));
		$this->db->where('bra_id',$this->input->post('bra_id'));
		$this->db->update('kh_branch');
	}
	public function getState()
	{
		return $this->db->select('*')->where('state_status',1)->get('kh_state')->result();
	}
	public function getStateName($id)
	{
		return $this->db->select('*')->where('state_id',$id)->get('kh_state')->row();
	}
	public function getCityName($id)
	{
		return $this->db->select('*')->where('city_id',$id)->get('kh_city')->row();
	}
	public function getLabForEdit($id)
	{
		return $this->db->select('*')->where('bra_id',$id)->get('kh_branch')->row();
	}
	
	public function getCompanyForAddTest()
	{
		return $this->db->select('*')->where('company_status',1)->get('kh_company')->result();
	}
	
	
	/////////////////////////////////////////////////Category///////////////////////////////
	public function getallotcatgoryType()
	{
		$this->db->select('*');
		$this->db->where('category_type_status',1);
		$getResult = $this->db->get('kh_category_type');
        return $getResult->result(); 
	}
	function getCategory($id)
	{
		$this->db->select('*');
		$this->db->where('category_id',$id);
		$getResult = $this->db->get('kh_category');
        return $getResult->row(); 
	}
	
	
	function addcategry($cover)
	{
		$date = date('Y-m-d h:i:s');
		$this->db->set('category_name',$this->input->post("category_name"));
		$this->db->set('category_url',$this->urlMaker($this->input->post("category_name")));
		$this->db->set('category_desc',$this->input->post("cate_desc"));	
		$this->db->set('category_parent_id',$this->input->post("category_parent"));	
		$this->db->set('meta_title',$this->input->post("meta_title"));	
		$this->db->set('meta_desc',$this->input->post("meta_description"));	
		$this->db->set('meta_keyword',$this->input->post("meta_keyword"));	
		$this->db->set('category_type',$this->input->post("category_type"));
		$this->db->set('category_image',$cover);	
		$this->db->set('category_created',$date);	
		$this->db->set('category_updated',$date);	
		$this->db->set('category_menu_active',$this->input->post("menu_status"));	
		$this->db->set('category_status',$this->input->post("category_status"));	
		$this->db->insert('kh_category');
        
	}		

	function updateCategry($cover=NULL)
	{
		$date = date('Y-m-d h:i:s');
		$this->db->set('category_name',$this->input->post("category_name"));
		$this->db->set('category_url',$this->urlMaker($this->input->post("category_name")));
		$this->db->set('category_desc',$this->input->post("cate_desc"));	
		$this->db->set('category_parent_id',$this->input->post("category_parent"));	
		$this->db->set('category_type',$this->input->post("category_type"));
		$this->db->set('meta_title',$this->input->post("meta_title"));	
		$this->db->set('meta_desc',$this->input->post("meta_description"));	
		$this->db->set('meta_keyword',$this->input->post("meta_keyword"));	
		
		if($cover!=NULL){
			
			$this->db->set('category_image',$cover);
		}
		
		$this->db->set('category_created',$date);	
		$this->db->set('category_updated',$date);	
		$this->db->set('category_menu_active',$this->input->post("menu_status"));	
		$this->db->set('category_status',$this->input->post("category_status"));	
		$this->db->where('category_id',$this->input->post('category_id'));
		$this->db->update('kh_category');
        
	}	
	public function getOrderServces($id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$id);
		$query=$this->db->get('kh_order_items');
		return $query->result();
	}
	public function GetProductImages($id)
	{
	    $this->db->select('*');
		$this->db->where('product_id',$id);
		$getResult = $this->db->get('kh_product');
        return $getResult->row(); 
	}
	function getAllCategory()
	{
		$this->db->select('*');
		$this->db->where('category_status !=',3);
		$this->db->order_by('category_id',"desc");
		$getResult = $this->db->get('kh_category');
        return $getResult->result(); 
	}	
	function getActiveCategory($parent=0)
	{
		$this->db->select('*');
		$this->db->order_by('category_id',"desc");
		$this->db->where('category_parent_id',$parent);
		$getResult = $this->db->get('kh_category');
        return $getResult->result(); 
	}
	function getActiveTestCategory($parent=0)
	{
		$this->db->select('*');
		$this->db->order_by('category_id',"desc");
		$this->db->where('category_parent_id',$parent);
		$this->db->where('category_status',1);
		$getResult = $this->db->get('kh_category');
        return $getResult->result(); 
	}
	
	public function getTestCategoryForAddTestInLab()
	{
		$this->db->select('*');
		$this->db->where('category_status',1);
		$this->db->order_by('category_id',"desc");
		$getResult = $this->db->get('kh_category');
        return $getResult->result(); 
	}
	public function getAllTestCategoryForAddTestInLab($categoryid)
	{
		return $this->db->select('*')->where('cat_id',$categoryid)->where('test_status',1)->get('kh_test')->result();
	}
	public function getAllTestListForAddTestInLab($id)
	{
		return $this->db->select('*')->where('test_id',$id)->where('test_status',1)->get('kh_test')->row();
	}

	function getProductCategory($test_id)
	{
		$this->db->select('cat_id');
		$this->db->where('test_id',$test_id);
		return $this->db->get('kh_category')->result();
	}

	/////////////////////////////////////////////End Category//////////////////////////////

	////////////////////////////////////////////////couponcode//////////////////////////////////////
	public function coupan_list()
	{
		$this->db->select("*");
		return $this->db->get("kh_couponcode")->result();
	}
	public function coponNew()
	{
		$this->db->set("coupon_code",$this->input->post("coupon_code"));
		$this->db->set("coupon_use_type",$this->input->post("coupan_used_type"));
		$this->db->set("coupon_discount_type",$this->input->post("coupan_discount_type"));
		$this->db->set("coupon_discount_value",$this->input->post("coupan_discount_value"));
		$this->db->set("coupon_minimun_limit",$this->input->post("coupon_minimun_limit"));
		
		$this->db->set("coupon_title",$this->input->post("coupon_title"));
		$this->db->set("coupon_description",$this->input->post("coupon_description"));
		
		$this->db->set("coupon_valid_upto",date('Y-m-d 00:00:00',strtotime($this->input->post("coupon_valid_upto"))));
		$this->db->set("coupon_discount_limit",$this->input->post("coupon_discount_limit"));
		
		$this->db->set("coupon_created_date",date("Y-m-d h:i:s"));
		
		$this->db->insert("kh_couponcode");
	}
	
	////////////////////////////////////////////////couponcode//////////////////////////////////////

	/////////////////////////////////////////////Site Setting/////////////////////////////////////
	public function updateSetting()
	{
		$this->db->set("contact_email",$this->input->post("contact_email"));
		$this->db->set("contact_phone",$this->input->post("contact_number"));
		$this->db->set("social_twitter",$this->input->post("twitter"));
		$this->db->set("social_facebook",$this->input->post("facebook"));
		$this->db->set("social_google",$this->input->post("google"));
		$this->db->set("social_instagram",$this->input->post("instagram"));
		
		$this->db->set("social_linkedin",$this->input->post("linkedin"));
		$this->db->set("social_youtube",$this->input->post("youtube"));
		$this->db->set("whatsapp_api",$this->input->post("whatsapp_api"));
		$this->db->set("ga_code",$this->input->post("ga_code"));
		$this->db->set("live_chat",$this->input->post("live_chat"));
		$this->db->set("contact_address",$this->input->post("contact_address"));
		$this->db->set("whatsapp_api_number",$this->input->post("whatsapp_api_number"));
		$this->db->set("delivery_amount",$this->input->post("delivery_amount"));
		$this->db->set("second_delivery_amount",$this->input->post("second_delivery_amount"));
		$this->db->where("setting_id",1);
		
		$this->db->update("kh_site_setting");
	}
	
	public function getSetting()
	{
		$this->db->select("*");
		$this->db->where("setting_id",1);
		return $this->db->get("kh_site_setting")->row();
	}
    ////////////////////////////////////////////End Site Setting/////////////////////////////////////

    //////////////////////////////////////////////Contact List //////////////////////////////////////

	public function getContactQuery()
	{
		$this->db->select('*');
		$getResult = $this->db->get('kh_contact_query');
		return $getResult->result(); 
	}
	public function getContactQueryForAssign($id)
	{
		$this->db->select('*');
		$this->db->where('contact_id',$id);
		$getResult = $this->db->get('kh_contact_query');
		return $getResult->row(); 
	}
    /////////////////////////////////////////////End Contact List////////////////////////////////////

	///////////////////////////////test_collection_user///////////////////////////////////////
	public function getAllCollectionUserRegistered()
	{
		$this->db->select('*');
		$this->db->where('user_status !=',3);
		$getResult = $this->db->get('kh_test_collection_user');
        return $getResult->result(); 
	}
	public function addTestCollectionUser($profileImg)
	{

		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("user_name",$this->input->post("user_name"));
		$this->db->set("user_email",$this->input->post("user_email"));		 
		$this->db->set("user_mobile",$this->input->post("user_mobile"));		 
		$this->db->set("user_password",md5($this->input->post("user_password")));
		$this->db->set("user_password_text",$this->input->post("user_password"));
		$this->db->set("user_state",$this->input->post("user_state"));
		$this->db->set("user_city",$this->input->post("user_city"));
		$this->db->set("user_address",$this->input->post("user_address"));
		$this->db->set("user_zipcode",$this->input->post("user_zipcode"));
		$this->db->set("user_img",$profileImg);
		$source="Web";
		$this->db->set("user_source",$source);
		$this->db->set("user_status",1);
		$this->db->set("user_updated",$todayDate);
		$this->db->set("user_created",$todayDate);
		$this->db->insert("kh_test_collection_user");
	}
	public function getTestCollectionUserData($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		$getResult = $this->db->get('kh_test_collection_user');
        return $getResult->row(); 
	}
	public function eidtTestCollectionUser($profileImg=null)
	{
		$todayDate = date("Y-m-d h:i:s");
		$this->db->set("user_name",$this->input->post("user_name"));
// 		$this->db->set("user_email",$this->input->post("user_email"));		 
		$this->db->set("user_mobile",$this->input->post("user_mobile"));		 
		$this->db->set("user_password",md5($this->input->post("user_password")));
		$this->db->set("user_password_text",$this->input->post("user_password"));
		$this->db->set("user_state",$this->input->post("user_state"));
		$this->db->set("user_city",$this->input->post("user_city"));
		$this->db->set("user_address",$this->input->post("user_address"));
		$this->db->set("user_zipcode",$this->input->post("user_zipcode"));
		if ($profileImg != null) {
			$this->db->set("user_img",$profileImg);
		}
		$this->db->set("user_updated",$todayDate);
		$this->db->where('user_id',$this->input->post('user_id'));
		$this->db->update("kh_test_collection_user");
	}
	public function getPhleboNameData()
	{
		$this->db->select('*');
		$this->db->where('user_status',1);
		return $this->db->get('kh_test_collection_user')->result();
	}
	public function getSlotTimeOrder($phlebo_id,$searchdate)
	{
		$date1 = date('Y-m-d 01:00:00', strtotime($searchdate));
		//$date2 = date('Y-m-d 24:00:00', strtotime($this->input->post('search-date-to')));
 	  	$date3 = date('d/m/Y', strtotime($date1));
 		//$date4 = date('Y-m-d h:i:s', strtotime($date2));
		$this->db->select('*');
		$this->db->where('test_date >=',$date3);
		$this->db->where('collection_user',$phlebo_id);
		return $this->db->get('kh_order_tb')->result();
	}
	///////////////////////////////test_collection_user///////////////////////////////////////

	////////////////////////////////////Order//////////////////////////////////////////
	 public function countorderDatas($fromdate,$todate,$paid_unpaid,$sales)
	{

		$this->db->select('*');


		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}
		if ($sales !="")
		{
			$this->db->where('vendor_id',$sales);
		}

		$state=$this->input->get('state');
		if($state != null){
		    $this->db->where('order_state',$state);
		}

        $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}

        $search=$this->input->get('orderid');
        $name=$this->input->get('name');
		if($search != null){
 		    $this->db->like('order_unique_code',$search);
 		}
 		if($name != null){
 		    $this->db->like('order_firstname',$name);
 		}
 		
 		
 		
        $this->db->order_by('order_unique_code',"desc");
		$query=$this->db->get('kh_order_tb');
		return $query->num_rows();
	}
	public function orderDatas($limit,$page,$fromdate,$todate,$paid_unpaid,$sales)
	{

		$this->db->select('*');


		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}
		if ($sales !="")
		{
			$this->db->where('vendor_id',$sales);
		}
		
		
        $this->db->order_by('order_unique_code',"desc");
        
        $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}
		$state=$this->input->get('state');
		if($state != null){
		    $this->db->where('order_state',$state);
		}

        $search=$this->input->get('orderid');
        $name=$this->input->get('name');
		if($search != null){
 		    $this->db->like('order_unique_code',$search);
 		}
 		if($name != null){
 		    $this->db->like('order_firstname',$name);
 		}
        
        $this->db->limit($limit,$page);
		$query=$this->db->get('kh_order_tb');
		return $query->result();
	}
	public function getAllEmployeeForOrder()
	{
	    $this->db->select('*');
		$this->db->where('user_type',5);
		$query = $this->db->get('kh_admin');
        return $query->result();
	}
	public function orderDatasEmployee($limit,$page,$admin_id,$fromdate,$todate,$paid_unpaid)
	{

		$this->db->select('*');


		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}

		 $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}


		$this->db->where("vendor_id",$admin_id);
        $this->db->order_by('order_unique_code',"desc");
        $this->db->limit($limit,$page);
		$query=$this->db->get('kh_order_tb');
		return $query->result();
	}
	public function countorderDatasEmployee($admin_id,$fromdate,$todate,$paid_unpaid)
	{

		$this->db->select('*');
		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}


		 $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}


		$this->db->where("vendor_id",$admin_id);
        $this->db->order_by('order_unique_code',"desc");
		$query=$this->db->get('kh_order_tb');
		return $query->num_rows();
	}
	public function countorderDatasByUserid($userid)
	{
		$this->db->select('*');
		$this->db->where('order_userid',$userid);
		$query=$this->db->get('kh_order_tb');
		return $query->num_rows();
	}
	public function orderDatasByUserid($limit,$page,$userid)
	{
		$this->db->select('*');
		$this->db->where('order_userid',$userid);
		$this->db->limit($limit,$page);
		$query=$this->db->get('kh_order_tb');
		return $query->result();
	}
	public function getOrderTest($id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$id);
		return $this->db->get('kh_order_items')->result();
	}
	///////////////////////////////End Order///////////////////////////////////////////

    
    
    ////////////////////////////////////////User/////////////////////////////////
    public function getLoginUserName($id)
    {
        $this->db->select('*');
		$this->db->where('user_id',$id);
		$getResult = $this->db->get('kh_user_list');
        return $getResult->row();
    }
    /////////////////////////////////////End User////////////////////////////////


     ////////////////////////////Export/////////////////////////
	 public function orderExportInCSV()
	 {

		$date1 = date('Y-m-d 01:00:00', strtotime($this->input->post('search-date-from')));
		$date2 = date('Y-m-d 24:00:00', strtotime($this->input->post('search-date-to')));
 	  	$date3 = date('Y-m-d h:i:s', strtotime($date1));
 		$date4 = date('Y-m-d h:i:s', strtotime($date2));

 		
		$this->db->select('*');
		$this->db->where('order_created >',$date3);
		$this->db->where('order_created <',$date4);
		$getResult = $this->db->get('kh_order_tb');
		
        return $getResult->result(); 
	 }
	 public function getOrderItemForExport($order_id)
	 {
	 	$this->db->select('o.*,p.test_name');
		$this->db->where('o.order_id',$order_id);
		$this->db->join('kh_test p',"p.test_id=o.id","left");
		$getResult = $this->db->get('kh_order_items o');
        return $getResult->result(); 
	 }
	 public function  getTimeSlotForExport($id)
	 {
	 	$this->db->select('*');
	 	$this->db->where('slot_id',$id);
	 	return $this->db->get('kh_time_slot')->row();
	 }
	public function getForOrderEmployeeDataExprt($id)
	{
		$this->db->select('*');
		$this->db->where('id',$id);
		$getResult = $this->db->get('kh_admin');
        return $getResult->row(); 
	}
    public function getCallectionUserData($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		return $this->db->get('kh_test_collection_user')->row();
	}
	 /////////////////////////End Export///////////////////////////



	public function getlogins($agent_id,$searchdate)
	{
			$this->db->select('*');
			$this->db->where('agent_id',$agent_id);
			$this->db->where('date',$searchdate);
			$this->db->where('status',1);
			$this->db->where('agent_type',3);
			$getResult = $this->db->get('kh_logins');
	        return $getResult->result();
	}
	
	//////////////////Order DAta///////////////////
		public function getOrderData($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_tb")->row();
	}
	public function getOrderItem($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_order_items")->result();
	}
	public function getOrderDatasub($orderid)
	{
		$this->db->select('*');
		$this->db->where('order_id',$orderid);
		return $this->db->get("kh_subscribe_order_tb")->row();
	}
	
	/////////////////End Order ////////////////////////////
	
	/////////////////////////Cart/////////////////////////
	public function getCartItem()
	{
		$this->db->select('*');
		$this->db->where('user_id',$this->session->userdata('activeUserId'));
		$query=$this->db->get('kh_cart');
		return $query->result();
	}
	public function getCouponInfo($couponCode)
	{
		$this->db->select('*');
		$this->db->where('coupon_code',$couponCode);
		$this->db->where('coupon_status',1);
		$this->db->where('coupon_valid_upto >=',date('Y-m-d 00:00:00'));
		$getResult = $this->db->get('kh_couponcode');
		return $getResult->row(); 
	}	
	/////////////////////////End Cart////////////////////
	
	
	
	
    public function getUserDataForExports($id)
    {
        $this->db->select('*');
		$this->db->where('user_id',$id);
		$getResult = $this->db->get('kh_user_list');
        return $getResult->row();
    }

    /////////////////////Product///////////////////////////////////
    public function getproductcount()
	{
	    $search=$this->input->get('product_name');
		$this->db->select('*');
		if($search != null){
		    $this->db->like('product_name',$search);
		}

		$session_data=$this->session->userdata('login-in');
		if ($session_data['user_type'] == 5){
			$this->db->where('vendor_id',$session_data['id']);
		}

		$this->db->where('parent_product',0);
		$this->db->order_by('product_id','desc');
		$getResult = $this->db->get('kh_product');
        return $getResult->num_rows(); 
	}
	public function getproduct($limit,$page)
	{
		 $search=$this->input->get('product_name');
		$this->db->select('*');
		if($search != null){
		    $this->db->like('product_name',$search);
		}
		$session_data=$this->session->userdata('login-in');
		if ($session_data['user_type'] == 5){
			$this->db->where('vendor_id',$session_data['id']);
		}
		$this->db->where('parent_product',0);
		$this->db->order_by('product_id','desc');
		$this->db->limit($limit,$page);
		$getResult = $this->db->get('kh_product');
        return $getResult->result(); 
	}

	public function getActiveProductCategory($parent=0)
	{
		$this->db->select('*');

		$session_data=$this->session->userdata('login-in');
		$admindata=$this->db->select('category_type')->where('id',$session_data['id'])->get('kh_admin')->row();
		if ($session_data['user_type'] == 5){
			$this->db->where('category_type',$admindata->category_type);
		}
		$this->db->order_by('category_id',"desc");
		$this->db->where('category_parent_id',$parent);
		$this->db->where('category_status',1);

		
		$getResult = $this->db->get('kh_category');
        return $getResult->result(); 
	}
	public function getActiveBranch()
	{
		$this->db->select('*');
		$this->db->order_by('bra_id',"desc");
		$this->db->where('bra_status',1);
		$getResult = $this->db->get('kh_branch');
        return $getResult->result(); 
	}
	public function addProductCategory($product_id)
	{
	 
		$cat_list = $this->input->post("product_cat");
		
		if(count($cat_list) && $product_id!=NULL){
			 
			//	$this->db->where('prod_id',$product_id);
			//	$this->db->delete('category_products');
				
			foreach($cat_list as $cat_id){
				$this->db->set('cat_id',$cat_id);
				$this->db->set('prod_id',$product_id);
				$this->db->insert('kh_category_products');
			}
		} 
	}
	public function addProductBranch($product_id)
	{
	 
		$brd_list = $this->input->post("branch_id");
		if(count($brd_list) && $product_id!=NULL){
			//	$this->db->where('prod_id',$product_id);
			//	$this->db->delete('category_products');
			foreach($brd_list as $brd_id){
				$this->db->set('brd_id',$brd_id);
				$this->db->set('prod_id',$product_id);
				$this->db->insert('kh_branch_products');
			}
		}
	}

	public function updateProductCategory()
	{
		
		$product_id = $this->input->post("product_id");
		$cat_list = $this->input->post("product_cat");
		
		if(count($cat_list)){
			
				 
				$this->db->where('prod_id',$product_id);
				$this->db->delete('kh_category_products');
				
			foreach($cat_list as $cat_id){
				
				$this->db->set('cat_id',$cat_id);
				$this->db->set('prod_id',$product_id);
				$this->db->insert('kh_category_products');
		 
			}
		}
		 
	}
	
	public function updateProductBrand()
	{
		
		$product_id = $this->input->post("product_id");
		$branch_id = $this->input->post("branch_id");
		
		if(count($branch_id)){
			
				$this->db->where('prod_id',$product_id);
				$this->db->delete('kh_branch_products');
				
			foreach($branch_id as $brandid){
				
				$this->db->set('brd_id',$brandid);
				$this->db->set('prod_id',$product_id);
				$this->db->insert('kh_branch_products');
		 
			}
		}
	}
	
	public function addProduct($img=null)
	{

		$session_data=$this->session->userdata('login-in');
		//$slabdata = $this->db->query("SELECT * FROM kh_gst_slab");


		$this->db->select('*');
		$this->db->where('id',$this->input->post('gstslab'));
		$slabdata = $this->db->get('kh_gst_slab')->row();
		//print_r($slabdata);die();
		$date = date('Y-m-d h:i:s');
		$this->db->set('product_name',$this->input->post("product_name"));
		$producturl=$this->input->post("product_name")." ".$this->input->post("purchase_qty");
		$this->db->set('product_url',$this->urlMaker($producturl));	
		//$this->db->set('product_code',$this->input->post("product_code"));	
		$this->db->set('purchase_qty',$this->input->post("purchase_qty"));
		$this->db->set('product_qty',$this->input->post("product_qty"));
		$this->db->set('auto_update_qty',$this->input->post("auto_update_qty"));	
		$this->db->set('stock_status',$this->input->post("stock_status"));	
		$this->db->set('featured_status',$this->input->post("featured_status"));	
		$this->db->set('product_desc',$this->input->post("product_description"));	
		$this->db->set('product_price',$this->input->post("product_price"));	
		//$this->db->set('product_mrp',$this->input->post("product_mrp"));	
		//$this->db->set('kh_purchase_price',$this->input->post("kh_purchase_price"));	
		$this->db->set('brand_id',$this->input->post("brand_id"));
		$this->db->set('hsncode',$this->input->post("hsncode"));

		$this->db->set('slab_id',$slabdata->id);	
		$this->db->set('slab',$slabdata->slab);

		//$this->db->set('product_shipping_price',$this->input->post("product_shipping_price"));	
		$this->db->set('product_status',$this->input->post("product_status"));	
		$this->db->set('small_description',$this->input->post("small_description"));	
		$this->db->set('meta_title',$this->input->post("meta_title"));	
		$this->db->set('meta_desc',$this->input->post("meta_description"));	
		$this->db->set('meta_keyword',$this->input->post("meta_keyword"));	
		$this->db->set('product_tags',$this->input->post("product_tag"));	
		if($session_data['user_type'] == 5){
		    $this->db->set('vendor_id',$session_data['id']);
		}
		$this->db->set('subscribe_status',$this->input->post("subscribe_status"));	
		
		$this->db->set('product_img',$img);	
		$this->db->set('product_created',$date);	
		$this->db->set('product_updated',$date);	
 
		$this->db->insert('kh_product');
		
		return $this->db->insert_id();
        
	}
	public	function getCatNameForProduct($product_id)
	{

		$this->db->select('*');
		$this->db->where('prod_id',$product_id);
		$catid=$this->db->get('kh_category_products')->result();
		if($catid){
		    foreach ($catid as $key => $value) {
		    	$cats_id[] = $value->cat_id;
    		}
    
    		$catsid= array_unique($cats_id);
    
    		$this->db->select("category_name");
    		$this->db->where_in("category_id",$catsid);
    		$query = $this->db->get('kh_category');
    		return $query->result();   
		}else{
		    return false;
		}
	}

	public	function getBranchForProduct($product_id)
	{

		$this->db->select('*');
		$this->db->where('prod_id',$product_id);
		$catid=$this->db->get('kh_branch_products')->result();
		foreach ($catid as $key => $value) {
			$cats_id[] = $value->brd_id;
		}

		$catsid= array_unique($cats_id);

		$this->db->select("bra_name");
		$this->db->where_in("bra_id",$catsid);
		$query = $this->db->get('kh_branch');
		return $query->result();
	}
	public function getProductPhoto($id)
	{
		$this->db->select('*');
		$this->db->where('image_product_id',$id);
		$getResult = $this->db->get('kh_product_images');
        return $getResult->result(); 
	}	
	public function insertProductImage($proId,$image)
	{
		$this->db->set('image_product_id',$proId);
		$this->db->set('image_name',$image);
		$this->db->insert('kh_product_images');
       
	}
	public	function getSingleProduct($id)
	{
		$this->db->select('*');
		$this->db->where('product_id',$id);
		$getResult = $this->db->get('kh_product');
        return $getResult->row(); 
	}
	public	function getChildProduct($id)
	{
		$this->db->select('*');
		$this->db->where('parent_product',$id);
		$getResult = $this->db->get('kh_product');
        return $getResult->result(); 
	}
	public function getProductCategorys($product_id)
	{
		$this->db->select('cat_id');
		$this->db->where('prod_id',$product_id);
		return $this->db->get('kh_category_products')->result();
	}
	public function getProductBrand($product_id)
	{
		$this->db->select('brd_id');
		$this->db->where('prod_id',$product_id);
		return $this->db->get('kh_branch_products')->result();
	}
	public function updateProduct($img=NULL)
	{

	    $session_data=$this->session->userdata('login-in');


	    $this->db->select('*');
		$this->db->where('id',$this->input->post('gstslab'));
		$slabdata = $this->db->get('kh_gst_slab')->row();
		//print_r($slabdata->slab);die;


		$date = date('Y-m-d h:i:s');
		$this->db->set('product_name',$this->input->post("product_name"));
		$producturl=$this->input->post("product_name")." ".$this->input->post("purchase_qty");
		$this->db->set('product_url',$this->urlMaker($producturl));	
		//$this->db->set('product_code',$this->input->post("product_code"));	
		$this->db->set('purchase_qty',$this->input->post("purchase_qty"));
		$this->db->set('product_qty',$this->input->post("product_qty"));	
		$this->db->set('auto_update_qty',$this->input->post("auto_update_qty"));

		$this->db->set('slab_id',$this->input->post("gstslab"));
		$this->db->set('slab',$slabdata->slab);
		$this->db->set('hsncode',$this->input->post("hsncode"));
		 

		$this->db->set('stock_status',$this->input->post("stock_status"));	
		$this->db->set('featured_status',$this->input->post("featured_status"));	
		$this->db->set('product_desc',$this->input->post("product_description"));	
		$this->db->set('product_mrp',$this->input->post("product_mrp"));
		$this->db->set('product_price',$this->input->post("product_price"));
		//$this->db->set('kh_purchase_price',$this->input->post("kh_purchase_price"));	
		//$this->db->set('product_shipping_price',$this->input->post("product_shipping_price"));	
		$this->db->set('product_status',$this->input->post("product_status"));	
		$this->db->set('small_description',$this->input->post("small_description"));	
		$this->db->set('meta_title',$this->input->post("meta_title"));	
		$this->db->set('meta_desc',$this->input->post("meta_description"));	
		$this->db->set('meta_keyword',$this->input->post("meta_keyword"));	
		$this->db->set('product_tags',$this->input->post("product_tag"));
		$this->db->set('brand_id',$this->input->post("brand_id"));	
		if($session_data['user_type'] == 5){
		    $this->db->set('vendor_id',$session_data['id']);
		}
		
		if($img!=NULL)
		{
			$this->db->set('product_img',$img);	
		}
		//$this->db->set('subscribe_status',$this->input->post("subscribe_status"));	
		$this->db->set('product_updated',$date);
		
		$this->db->where('product_id',$this->input->post('product_id'));	
 
		$this->db->update('kh_product');
        
	}


	public function addChildProduct()
	{
		$date = date('Y-m-d h:i:s');
		$productdata=$this->db->select('*')->where('product_id',$this->input->post('product_id'))->get('kh_product')->row();
		$this->db->set('product_name',$productdata->product_name);
		$this->db->set('parent_product',$this->input->post('product_id'));
		$producturl=$productdata->product_name." ".$this->input->post("purchase_qty");
		$this->db->set('product_url',$this->urlMaker($producturl));	
		$this->db->set('product_code',$this->input->post("product_code"));	
		$this->db->set('purchase_qty',$this->input->post("purchase_qty"));
		$this->db->set('product_qty',$this->input->post("product_qty"));	
		$this->db->set('stock_status',$this->input->post("stock_status"));	
		$this->db->set('featured_status',0);	
		$this->db->set('product_desc',$productdata->product_desc);	
		$this->db->set('product_price',$this->input->post("product_price"));	
		$this->db->set('product_mrp',$this->input->post("product_mrp"));	
		$this->db->set('kh_purchase_price',$this->input->post("kh_purchase_price"));	
		$this->db->set('product_shipping_price',$this->input->post("product_shipping_price"));	
		$this->db->set('product_status',$this->input->post("product_status"));	
		$this->db->set('small_description',$productdata->small_description);	
		$this->db->set('meta_title',$productdata->meta_title);	
		$this->db->set('meta_desc',$productdata->meta_desc);	
		$this->db->set('meta_keyword',$productdata->meta_keyword);	
		$this->db->set('product_tags',$productdata->product_tags);
		$this->db->set('product_img',$productdata->product_img);	
		$this->db->set('product_created',$date);	
		$this->db->set('product_updated',$date);
		$this->db->insert('kh_product');
		return $this->db->insert_id();
	}


    ///////////////////////End Product////////////////////////////
	///////////////////////Membership//////////////////////////////
	public function getMemberShipStatus($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		$this->db->where('payment_status',1);
		$this->db->where('membership_exp',1);
		return $this->db->get("kh_purchase_membership")->row();
	}
	//////////////////////end Membership///////////////////////////

	/////////////////////////user Lign by Admin//////////////////

	function getSiteLoginAdmin($id)
	{
		$this->db->select('*');
		$this->db->where('user_id',$id);
		$query = $this->db->get('kh_user_list');
        return $query->row();
	}

	///////////////////////end user login by Admin///////////////
	
	
	   /***********************************add_price_by_pin_code.php**************************/

   public function getPinCodeByProductForPrice($prod_id)
   {
        $this->db->select('o.*,b.bra_id,b.bra_zip');
		$this->db->where('o.prod_id',$prod_id);
		$this->db->join('kh_branch b',"b.bra_id=o.brd_id","left");
		$getResult = $this->db->get('kh_branch_products o');
        return $getResult->result(); 

   }
   public function getProductPriceForEditPriceBypincode($bra_id,$product_id)
   {
   		$this->db->select('*');
		$this->db->where('branch_id',$bra_id);
		$this->db->where('product_id',$product_id);
		$query = $this->db->get('kh_product_price_by_pincode');
        return $query->row();
   }
   public function getProductPriceForPincode($product_id)
   {
   		$this->db->select('*');
		$this->db->where('product_id',$product_id);
		$getResult = $this->db->get('kh_product');
        return $getResult->row(); 
   }

	      /***********************************add_price_by_pin_code.php**************************/
	
	      
	/*****************************Order Item Search*******************************************/
	public function getOrderItemByDateSearch()
	 {
	 	$date1 = date('Y-m-d 01:00:00', strtotime($this->input->get('search-date-from')));
		$date2 = date('Y-m-d 00:00:00', strtotime($this->input->get('search-date-to')."1 day"));

	    $this->db->select('*');
		$this->db->where('order_created >=',$date1);
		$this->db->where('order_created <',$date2);
		$this->db->where('payment_type',1);
		$this->db->where('order_status !=',0);
		$this->db->where('order_status !=',6);
		$query=$this->db->get('kh_order_tb')->result();




		$this->db->select('*');
		$this->db->where('order_created >=',$date1);
		$this->db->where('order_created <',$date2);
		$this->db->where('order_payment_status',1);
		$this->db->where('payment_type',2);
		$this->db->where('order_status !=',0);
		$this->db->where('order_status !=',6);
		$query1=$this->db->get('kh_order_tb')->result();
		
		$orderdata=array_merge($query,$query1);
		//print_r($orderdata); die;

		foreach ($orderdata as $key => $orderidforProduct) {
			$orderid[]=$orderidforProduct->order_id;
		}

		$orderids=array_unique($orderid);
		
		if(!empty($orderids)){
		    $this->db->select('*');
    		$this->db->where_in('order_id',$orderids);
    		$this->db->group_by('product_id');
    		$allproduct=$this->db->get('kh_order_items')->result();
    		
    		return $allproduct;
		}else{
		     return false;
		}
	 }
	 public function getordereditembyproductidanddate()
	 {
	 	$date1 = date('Y-m-d 01:00:00', strtotime($this->input->get('search-date-from')));
		$date2 = date('Y-m-d 00:00:00', strtotime($this->input->get('search-date-to')."1 day"));
		$product_id=$this->input->get('product_id');

		$this->db->select('*');
		$this->db->where('created >=',$date1);
		$this->db->where('created <',$date2);
		$this->db->where('product_id',$product_id);
		$allproduct=$this->db->get('kh_order_items')->result();
		
		//print_r($allproduct); die();


		foreach ($allproduct as $key => $ae) {
			
			$this->db->where('order_id',$ae->order_id);
		    $productorder=$this->db->get('kh_order_tb')->row();

		    if ($productorder->order_payment_status == 1 AND  $productorder->payment_type == 2) {
		    	if($productorder->order_status != 0 AND $productorder->order_status  !=6){
		    		$booking[]=$ae->item_id;
			    }else{

			    }
		    } else {
		    	if( $productorder->payment_type == 1){
		    		if($productorder->order_status != 0 AND $productorder->order_status  !=6){
		    			$booking[]=$ae->item_id;
				    }else{

				    }
		    	}
		    	
		    }
		    
		}
		$productitemid=array_unique($booking);
		
		if(!empty($productitemid)){
		    $this->db->select('*');
		    $this->db->where_in('item_id',$productitemid);
		    $itemproduct=$this->db->get('kh_order_items')->result();
		
		    //print_r($itemproduct); die;
		    return $itemproduct;
		}else{
		    return false;
		}
		

		
	 }
	 public function getOrderQtysearch($searchdatefrom,$searchdateto,$productid)
	 {
	 	$date1 = date('Y-m-d 01:00:00', strtotime($searchdatefrom));
		$date2 = date('Y-m-d 00:00:00', strtotime($searchdateto."1 day"));
		$product_id=$productid;

		$this->db->select('*');
		$this->db->where('created >=',$date1);
		$this->db->where('created <',$date2);
		$this->db->where('product_id',$product_id);
		$allproduct=$this->db->get('kh_order_items')->result();


		foreach ($allproduct as $key => $ae) {
			
			$this->db->where('order_id',$ae->order_id);
		    $productorder=$this->db->get('kh_order_tb')->row();

		    if ($productorder->order_payment_status == 1 AND  $productorder->payment_type == 2) {
		    	if($productorder->order_status != 0 AND $productorder->order_status  !=6){
		    		$booking[]=$ae->item_id;
			    }else{

			    }
		    } else {
		    	if( $productorder->payment_type == 1){
		    		if($productorder->order_status != 0 AND $productorder->order_status  !=6){
		    			$booking[]=$ae->item_id;
				    }else{

				    }
		    	}
		    	
		    }
		    
		}
		$productitemid=array_unique($booking);
		
		if(!empty($productitemid)){
		    $this->db->select('*');
    		$this->db->where_in('item_id',$productitemid);
    		$itemproduct=$this->db->get('kh_order_items')->result();
    
    		return $itemproduct;
		}else{
		    return false;
		}
		

		
	 }
	public function getorder_unique_code($id)
	{
		$this->db->where('order_id',$id);
		return $this->db->get('kh_order_tb')->row();
	}
	
	/****************************End Order Item Search***************************************/
	  ////////////////////////////////////Slider///////////////////////////////
	public function getSliderPhoto($section)
	{
		$this->db->select('*');
		$this->db->where('image_section_type',$section);
		$getResult = $this->db->get('kh_app_home_images');
        return $getResult->result(); 
	}	
	public function insertAppHomeImage($image_section_type,$image)
	{
		$this->db->set('image_name',$image);
		$this->db->set('image_section_type',$image_section_type);
		$this->db->insert('kh_app_home_images');
	}
	public function getAppSectionCategorys($image_section_type)
	{
		$this->db->select('*');
		$this->db->where('image_section_type',$image_section_type);
		return $this->db->get('kh_app_home_images')->result();
	}
	public function getActiveCategoryForApp()
	{
		$this->db->select('*');
		$this->db->order_by('category_id',"desc");
		$this->db->where('category_status',1);
		$getResult = $this->db->get('kh_category');
        return $getResult->result(); 
	}
	//////////////////////////////////End Slider////////////////////////////////
	 
	 public function getCheckoutdata($checkout_id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$checkout_id);
		return $this->db->get("kh_order_checkout_tb")->row();
	}

	public function getOrderItemFromCheckout($checkout_id)
	{
		$this->db->select('*');
		$this->db->where('checkout_id',$checkout_id);
		$getorderid=$this->db->get("kh_order_tb")->result();
		foreach ($getorderid as $key => $value) {
			$orderid[]=$value->order_id;
		}
		$order_id=array_unique($orderid);
		$this->db->select('*');
		$this->db->where_in('order_id',$order_id);
		return $this->db->get("kh_order_items")->result();
	} 
	
	 
	 public function getSlotTimeFororder($id)
	{
	    $this->db->select('*');
	    $this->db->where('slot_id',$id);
	    return $this->db->get('kh_time_slot')->row();
	} 





	////////////////////////////////////Order//////////////////////////////////////////
	 public function subcountorderDatas($fromdate,$todate,$paid_unpaid,$sales)
	{

		$this->db->select('*');


		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}
		if ($sales !="")
		{
			$this->db->where('vendor_id',$sales);
		}
		
        $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}

        $search=$this->input->get('orderid');
        $name=$this->input->get('name');
		if($search != null){
 		    $this->db->like('order_unique_code',$search);
 		}
 		if($name != null){
 		    $this->db->like('order_firstname',$name);
 		}
 		
 		
 		
        $this->db->order_by('order_unique_code',"desc");
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->num_rows();
	}
	public function suborderDatas($limit,$page,$fromdate,$todate,$paid_unpaid,$sales)
	{

		$this->db->select('*');


		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}
		if ($sales !="")
		{
			$this->db->where('vendor_id',$sales);
		}
		
		
        $this->db->order_by('order_unique_code',"desc");
        
        $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}

        $search=$this->input->get('orderid');
        $name=$this->input->get('name');
		if($search != null){
 		    $this->db->like('order_unique_code',$search);
 		}
 		if($name != null){
 		    $this->db->like('order_firstname',$name);
 		}
        
        $this->db->limit($limit,$page);
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->result();
	}

	public function suborderDatasEmployee($limit,$page,$admin_id,$fromdate,$todate,$paid_unpaid)
	{

		$this->db->select('*');


		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}

		 $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}


		$this->db->where("vendor_id",$admin_id);
        $this->db->order_by('order_unique_code',"desc");
        $this->db->limit($limit,$page);
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->result();
	}
	public function subcountorderDatasEmployee($admin_id,$fromdate,$todate,$paid_unpaid)
	{

		$this->db->select('*');
		if($fromdate!="" && $todate!="")
		{
		  $this->db->where('order_created >=', $fromdate);
		  $this->db->where('order_created <=', $todate);
		}
		if($fromdate!="" && $todate=="")
		{
		  $this->db->where('order_created >=', $fromdate);
		}
		if ($paid_unpaid !="")
		{
			$this->db->where('order_payment_status',$paid_unpaid);
		}


		 $mobile=$this->input->get('mobile');
		if($mobile != null){
		    $this->db->like('order_phone',$mobile);
		}


		$this->db->where("vendor_id",$admin_id);
        $this->db->order_by('order_unique_code',"desc");
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->num_rows();
	}
	public function subcountorderDatasByUserid($userid)
	{
		$this->db->select('*');
		$this->db->where('order_userid',$userid);
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->num_rows();
	}
	public function suborderDatasByUserid($limit,$page,$userid)
	{
		$this->db->select('*');
		$this->db->where('order_userid',$userid);
		$this->db->limit($limit,$page);
		$query=$this->db->get('kh_subscribe_order_tb');
		return $query->result();
	}
	public function subgetOrderTest($id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$id);
		return $this->db->get('kh_subscribe_order_items')->result();
	}
	public function subgetOrderServces($id)
	{
		$this->db->select('*');
		$this->db->where('order_id',$id);
		$query=$this->db->get('kh_subscribe_order_items');
		return $query->result();
	}
	///////////////////////////////End Order///////////////////////////////////////////
	
	
	
	
	////////////////////////////// Brand /////////////////////////////////////////////
	public function add_brand_list($img){

		$created_at=date("Y-m-d h:i:sa");
		//$img = $this->input->post('img');
		$this->db->set('b_name',$this->input->post('bname'));
		$this->db->set('b_img',$img);
		$this->db->set('status',1);
		$this->db->set('created_date',$created_at);
		$this->db->insert('kh_brand');
		

	}

	public function get_brand_list(){
		//$created_at=date("Y-m-d h:i:sa");
		//$img = $this->input->post('img');
		$this->db->select('*');
		$this->db->order_by('id','DESC');
		return $this->db->get('kh_brand')->result();
		

	}
	public function getActivebrandlist(){
		//$created_at=date("Y-m-d h:i:sa");
		//$img = $this->input->post('img');
		$this->db->select('*');
		$this->db->where('status',1);
		//$this->db->order_by('id','DESC');
		return $this->db->get('kh_brand')->result();
		

	}

	 
	function updatebrandlist($cover= NULL)
	{
		$created_at=date("Y-m-d h:i:sa");
		//$img = $this->input->post('img');
		$this->db->set('b_name',$this->input->post('bname'));
		//$this->db->set('b_img',$cover);
		$this->db->set('created_date',$created_at);
		
		if($cover!=NULL){
			 $this->db->set('b_img',$cover);
		}
		
		$this->db->set('created_date',$created_at); 	
		$this->db->where('id',$this->input->post('Brand_id'));
		$this->db->update('kh_brand');
        
	}	
    
	public function getsave_More_address($id)
	{
		$this->db->where("user_id",$id);
		return $this->db->get("kh_save_address")->result();
	}

	/////////////////////////////End Brand //////////////////////////////////////////


	/////////////////gst salb///////////////////////
	public function getgst_slab(){
		$this->db->select('*');
		return $this->db->get('kh_gst_slab')->result();
	}
	
	public function getstart_date_anddate($orderuserid){

		$this->db->select('*');
		$this->db->select_sum('order_amount');
		$this->db->where('order_userid',$orderuserid);
		$this->db->where('MONTH(order_created)', date('m'));
		$this->db->where('order_payment_status',1);

		return $this->db->get('kh_order_tb')->result();
	}
	public function genrate_list()
	{
		$this->db->select('*');
		return $this->db->get('kh_genrate_inv')->result();
 	}
    public function ViewALLADDRESS_LIST(){
 	    $this->db->select('*');
 	    $this->db->order_by('id','DESC');
 		return $this->db->get('kh_save_address')->result();
 	}
 	
 	public function getInvtypes()
 	{
 	    $this->db->select('*');
 	    $this->db->where('status',1);
 		return $this->db->get('kh_inv_type_list')->result();
 	}
 	public function getInvNameBydb($id)
 	{
 	    $this->db->select('*');
 	    $this->db->where('id',$id);
 		return $this->db->get('kh_inv_type_list')->row();
 	}

}